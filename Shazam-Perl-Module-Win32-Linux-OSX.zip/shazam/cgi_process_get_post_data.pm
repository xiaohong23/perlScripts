package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Grabs cgi keys from existing hash and returns a new formatted and ready to
# save hash.
#
# frm_key = Unmanipulated data as it exists
# trm_key = Trim the value
# cur_key = Format value as currency
#
#-----------------------------------------------------------------------------#
sub cgi_process_get_post_data {
  my ($hash_ref) = @_;
  my (%new_data, $key, $uncleaned_key);

  foreach (keys %$hash_ref) {
    if ($_ =~ m/^frm_/) {
      $key = $_;
      $key =~ s/frm_//;
      $uncleaned_key = $key;
      $key =~ s/_/ /g;
      $new_data{$key} = $$hash_ref{$_};
      $$hash_ref{$uncleaned_key} = $new_data{$key};
    }

    if ($_ =~ m/^trm_/) {
      $key = $_;
      $key =~ s/trm_//;
      $uncleaned_key = $key;
      $key =~ s/_/ /g;
      $new_data{$key} = &shazam::string_trim_ws($$hash_ref{$_});
      $$hash_ref{$uncleaned_key} = $new_data{$key};
    }

    if ($_ =~ m/^num_/) {
      $key = $_;
      $key =~ s/num_//;
      $uncleaned_key = $key;
      $key =~ s/_/ /g;
      $new_data{$key} = &shazam::string_strip_non_numeric('true', $$hash_ref{$_});
      $$hash_ref{$uncleaned_key} = $new_data{$key};
    }

    if ($_ =~ m/^cur_/) {
      $key = $_;
      $key =~ s/cur_//;
      $uncleaned_key = $key;
      $key =~ s/_/ /g;
      $new_data{$key} = &shazam::finance_format_money(&shazam::string_trim_ws($$hash_ref{$_}));
      $$hash_ref{$uncleaned_key} = $new_data{$key};
    }
  }

  return %new_data;
}
1;
