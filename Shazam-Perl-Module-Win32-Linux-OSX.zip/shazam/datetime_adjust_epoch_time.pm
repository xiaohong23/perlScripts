package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Date/Time Calculator
# This internal routine creates an expires time exactly some number of
# hours from the current time.
# format for time can be in any of the forms...
# "now" -- expire immediately
# "+180s" -- in 180 seconds
# "+2m" -- in 2 minutes
# "+12h" -- in 12 hours
# "+1d"  -- in 1 day
# "+3M"  -- in 3 months
# "+2y"  -- in 2 years
# "-3m"  -- 3 minutes ago(!)
#-----------------------------------------------------------------------------#
sub datetime_adjust_epoch_time {

  my($adjust_by, $epoch_time) = @_;

  $epoch_time = time if ($epoch_time eq '');

  my(%mult) = (
  's'=>1, 'm'=>60, 'h'=>60*60, 'd'=>60*60*24, 'M'=>60*60*24*30, 'y'=>60*60*24*365);
  # If you don't supply one of these forms, we assume you are
  # specifying the date yourself
  my($offset);
  if (!$adjust_by || (lc($adjust_by) eq 'now')) {
    $adjust_by = 0;
  } elsif ($adjust_by=~/^\d+/) {
    return $adjust_by;
  } elsif ($adjust_by=~/^([+-]?(?:\d+|\d*\.\d*))([mhdMy]?)/) {
    $offset = ($mult{$2} || 1)*$1;
  } else {
    return $adjust_by;
  }
  return ($epoch_time + $offset);
}
1;
