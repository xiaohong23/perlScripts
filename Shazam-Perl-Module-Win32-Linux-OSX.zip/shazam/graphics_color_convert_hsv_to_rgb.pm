package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub graphics_color_convert_hsv_to_rgb {
  my ($h, $s, $v) = @_;
  my ($r, $g, $b);
  my ($f, $i, $h_temp, $p, $q, $t);

  if ($s == 0) {
    $r = $g = $b = $v;
  } else {
    if ($h == 360) { $h_temp = 0; } else { $h_temp = $h; }
    $h_temp /= 60;

    $i = int($h_temp);
    $f = $h_temp - $i;
    $p = $v * (1 - $s);
    $q = $v * (1 - ($s * $f));
    $t = $v * (1 - ($s * (1 - $f)));

    if ($i == 0) {$r = $v; $g = $t; $b = $p;}
    if ($i == 1) {$r = $q; $g = $v; $b = $p;}
    if ($i == 2) {$r = $p; $g = $v; $b = $t;}
    if ($i == 3) {$r = $p; $g = $q; $b = $v;}
    if ($i == 4) {$r = $t; $g = $p; $b = $v;}
    if ($i > 4) {$r = $v; $g = $p; $b = $q;}
  }
  return (int($r), int($g), int($b));
}
1;
