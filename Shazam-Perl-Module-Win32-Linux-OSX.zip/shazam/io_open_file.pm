package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_open_file {

  my $input = $_[0];
  my $file;

  if (-e $input){
    open (FILE, $input) || &shazam::cgi_error("$!", "[proio_open_file]: Fatal Error opening $input $!");
    local $/ = undef;
    $file = <FILE>;
    close(FILE);
  } else {
    &shazam::cgi_error("Error: File Not Found", "[proio_open_file]: Fatal Error opening file. The following file does not exist: <br><br><br>$input");
  }
  return $file;
}
1;
