package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes data file and assigns a unique key derived from numerically or 
# alphabetically incremented key values. Returns specified values 
# when finished.
#
# Example:
# &shazam::keydb_assign_unique_key("c:/data.kdb", "1", "unique key");
#
# Array is configured like the Following:
# $path          - The full path to the data file
# $key start     - Where shall we start incrementing (1, a, i, etc...) 
# $return_option - Specifies what shall be returned
# $escape_html   - true or false
#   unique key (default)
#   data hash
#   
#-----------------------------------------------------------------------------#
sub keydb_assign_unique_key {

  my ($path, $key_start, $return_option, $escape_html) = @_;
  my %existing_data_file;
  my @split;
  my $new_file;

  #&shazam::keydb_create_file($path) if (!-e $path);
  
  use Fcntl qw(:DEFAULT :flock);
  use strict;

  # If the data file exists load in its values 
  if (-e $path) {
    sysopen(DB, $path, O_RDWR|O_CREAT) or &shazam::keydb_cgi_error("$!", "[keydb_assign_unique_key]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
    eval qq^flock(DB, LOCK_EX)^;
    while (<DB>) {
      chomp($_); # Remove LF 
      chop($_) if (substr($_, -1, 1) eq "\015"); # Remove windows CR if it exists
      @split = split(/\|/, $_);
      if ($split[0]) { $existing_data_file{$split[0]} = $split[1]; }
    }    
  } else {
    &shazam::keydb_cgi_error("$!", "[keydb_assign_unique_key]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
  }
  
  # Find Next Key
  while ( exists($existing_data_file{$key_start}) ) {
    $key_start++;
  }
  
  # Insert New key
  $existing_data_file{$key_start} = "";
  
  # Build the official new data file  
  foreach ( sort keys %existing_data_file ) { 
    $new_file .= "$_|$existing_data_file{$_}\012" if ($_);
  }
  chop($new_file); # remove the last \n
  
  # Save the new file
  seek(DB, 0, 0) or die "can't rewind: $!";
  truncate(DB, 0) or die "can't truncate: $!";
  print DB $new_file;
  eval qq^flock(DB, LOCK_UN)^;
  close(DB);

  &shazam::keydb_escape_html_in_hash_by_ref(\%existing_data_file)  if (($return_option eq 'data hash') && ($escape_html eq 'true'));
  
  if ($return_option eq "unique key" || $return_option eq "") {
    return $key_start;
  }
  if ($return_option eq "data hash") {
    return %existing_data_file;
  }
}
1;
