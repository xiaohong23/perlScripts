package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# $example = &shazam::cgi_determine_browser( $ENV{'HTTP_USER_AGENT'} );
# Returns: Netscape 1-7, Internet Explorer 3-7, Lynx, NCSA Mosaic, AOL,
# MacWeb, IBM WebExplorer
# Need to update
#-----------------------------------------------------------------------------#
sub cgi_determine_browser {

  my $env_user_agent = $_[0];

  return "Internet Explorer 3"   if $env_user_agent =~ /MSIE 3./i;        # Broweser is Internet Explorer 3
  return "Internet Explorer 4"   if $env_user_agent =~ /MSIE 4./i;        # Broweser is Internet Explorer 4
  return "Internet Explorer 5"   if $env_user_agent =~ /MSIE 5./i;        # Broweser is Internet Explorer 5
  return "Internet Explorer 6"   if $env_user_agent =~ /MSIE 6./i;        # Broweser is Internet Explorer 6
  return "Internet Explorer 7"   if $env_user_agent =~ /MSIE 7./i;        # Broweser is Internet Explorer 7
  return "Netscape 1"            if $env_user_agent =~ /Mozilla\/1./;     # Broweser is Netscape 1
  return "Netscape 2"            if $env_user_agent =~ /Mozilla\/2./;     # Broweser is Netscape 2
  return "Netscape 3"            if $env_user_agent =~ /Mozilla\/3./;     # Broweser is Netscape 3
  return "Netscape 4"            if $env_user_agent =~ /Mozilla\/4./;     # Broweser is Netscape 4
  return "Netscape 5"            if $env_user_agent =~ /Mozilla\/5./;     # Broweser is Netscape 5
  return "Netscape 6"            if $env_user_agent =~ /Mozilla\/6./;     # Broweser is Netscape 6
  return "Netscape 7"            if $env_user_agent =~ /Mozilla\/7./;     # Broweser is Netscape 7
  return "Lynx"                  if $env_user_agent =~ /Lynx/i;           # Broweser is Lynx
  return "NCSA Mosaic"           if $env_user_agent =~ /mosaic/;          # Broweser is NCSA Mosaic
  return "AOL"                   if $env_user_agent =~ /aol/i;            # Broweser is AOL's Browser
  return "MacWeb"                if $env_user_agent =~ /MacWeb/i;         # Broweser is MacWeb
  return "IBM WebExplorer"       if $env_user_agent =~ /WebExplorer/i;    # Broweser is IBM WebExplorer
  return '';
}
1;
