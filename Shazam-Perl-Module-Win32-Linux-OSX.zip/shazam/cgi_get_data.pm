package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub cgi_get_data {

  my ($max_bytes) = @_; # Max input size in BYTES
  my($name, $value, $pair, @pairs, $buffer, %data);

  # Check input size if max input size is defined
  if ( $max_bytes && ($ENV{'CONTENT_LENGTH'} || length($ENV{'QUERY_STRING'}) ) > $max_bytes) {
    &shazam::cgi_error("Form Input Exceeds Max. Bytes Allowed", "[procgi_parse_form]: The data sent through the form exceeded the $max_bytes bytes allowed!");
  }

  # Read GET or POST form into $buffer
  if ($ENV{'REQUEST_METHOD'} eq 'POST') { 
    read( STDIN, $buffer, $ENV{'CONTENT_LENGTH'} );
  } 
  elsif ($ENV{'REQUEST_METHOD'} eq 'GET') {
    $buffer = $ENV{'QUERY_STRING'};
  }
  
  @pairs = split(/&/, $buffer);
  foreach $pair (@pairs) {
    ($name, $value) = split(/=/, $pair);
    $name =~ tr/+/ /;
    $value =~ tr/+/ /;
    $name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
    $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
    $data{$name} = $value;
  }
  return %data;
}
1;
