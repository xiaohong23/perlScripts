package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub data_states_hash {

  my %states = (
    AL => 'Alabama', AK => 'Alaska', AZ => 'Arizona',
    AR => 'Arkansas', CA => 'California', CO => 'Colorado',
    CT => 'Connecticut', DE => 'Delaware', FL => 'Florida',
    GA => 'Georgia', HI => 'Hawaii', ID => 'Idaho',
    IL => 'Illinois', IN => 'Indiana', IA => 'Iowa',
    KS => 'Kansas', KY => 'Kentucky',
    LA => 'Louisiana', ME => 'Maine', MD => 'Maryland',
    MA => 'Massachusetts', MI => 'Michigan', MN => 'Minnesota',
    MS => 'Mississippi', MO => 'Missouri', MT => 'Montana',
    NE => 'Nebraska', NJ => 'New Jersey', NH => 'New Hampshire',
    NV => 'Nevada', NM => 'New Mexico', NY => 'New York',
    NC => 'North Carolina', ND => 'North Dakota', OH => 'Ohio',
    OK => 'Oklahoma', OR => 'Oregon', PA => 'Pennsylvania',
    RI => 'Rhode Island', SC => 'South Carolina',
    SD => 'South Dakota', TN => 'Tennessee', TX => 'Texas',
    UT => 'Utah', VT => 'Vermont', VA => 'Virginia',
    WA => 'Washington', WV => 'West Virginia', WI => 'Wisconsin',
    WY => 'Wyoming', AS => 'American Samoa', DC => 'District Of Columbia',
    GU => 'Guam', NI => 'Northern Mariana Islands', PR => 'Puerto Rico',
    VI => 'Virgin Islands');

    return %states;
}
1;
