package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes path with filename and returns array of path and filename.
# Position 0: Filename
# Position 1: Path
#-----------------------------------------------------------------------------#
sub keydb_split_path_and_file {
  my $pathfile = $_[0];
  my @split;
  my @build;

  @split = split ( /\//, $pathfile );

  push( @build, pop(@split) );
  push( @build, join("/", @split) . "/" );
  
  return @build;
}
1;
