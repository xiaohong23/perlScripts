package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Requires array of images with fully qualified path
#
#  AVI Audio/Video Interleave image file
#  AVS AVS X image file
#  BMP Microsoft Windows bitmap image file
#  CGM Computer Graphics Metafile requires ralcgm; read only
#  CMYK Raw cyan, magenta, yellow, and black samples set -size and -depth to specify the image width, height, and depth
#  DCM Digital Imaging and Communications in Medicine image file format read only
#  DCX ZSoft IBM PC multi-page Paintbrush file
#  DIB Microsoft Windows bitmap image file
#  DPX Digital Moving Picture Exchange
#  EPDF Encapsulated Portable Document Format
#  EPI Adobe Encapsulated PostScript Interchange format requires Ghostscript to read
#  EPS Adobe Encapsulated PostScript file requires Ghostscript to read
#  EPS2 Adobe Level II Encapsulated PostScript file requires Ghostscript to read
#  EPSF Adobe Encapsulated PostScript file requires Ghostscript to read
#  EPSI Adobe Encapsulated PostScript Interchange format requires Ghostscript to read
#  EPT Adobe Encapsulated PostScript Interchange format with TIFF preview requires Ghostscript to read
#  FAX Group 3
#  FIG TransFig image format requires TransFig
#  FITS Flexible Image Transport System
#  FPX FlashPix Format requires FlashPix SDK
#  GIF CompuServe graphics interchange format 8-bit color
#  GIF87 CompuServe graphics interchange format 8-bit color (version 87a)
#  GPLT Gnuplot plot files requires gnuplot3.5.tar.Z
#  GRADIENT Gradual passing from one shade to another specify the desired shading as the filename (e.g. gradient:red-blue
#  GRANITE Granite texture.
#  GRAY Raw gray samples set -size and -depth to specify the image width, height, and depth
#  HDF Hierarchical Data Format requires HDF4.1r2.tar.gz
#  HISTOGRAM Histogram of the image
#  HPGL HP-GL plotter language requires hp2xx-3.2.0.tar.gz
#  HTML Hypertext Markup Language with a client-side image map requires html2ps to read
#  ICO Microsoft icon read only
#  ICC International Color Consortium color profile To read, use -profile with convert
#  ILBM Amiga IFF
#  IPTC Newswire profile To read, use -profile with convert
#  JBIG Joint Bi-level Image experts Group file interchange format requires jbigkit-1.0.tar.gz
#  JP2 JPEG-2000 JP2 File Format Syntax requires jasper-1.500.0.zip
#  JPC JPEG-2000 Code Stream Syntax requires jasper-1.500.0.zip
#  JPEG Joint Photographic Experts Group JFIF format requires jpegsrc.v6b.tar.gz
#  LABEL text image format specify the desired text as the filename (e.g. label:This is a label
#  MAP colormap intensities and indices set -depth to set the sample size of the intensities; indices are 16-bit if colors > 256.
#  MAN Unix reference manual pages
#  MIFF Magick image file format
#  MNG Multiple-image Network Graphics requires libpng-1.02.tar.gz
#  MPEG  Motion Picture Experts Group file interchange format requires mpeg2vidcodec_v12.tar.gz
#  M2V  Motion Picture Experts Group file interchange format (version 2) requires mpeg2vidcodec_v12.tar.gz
#  MPC Magick Persistent Cache image file format
#  MTV MTV Raytracing image format
#  MVG Magick Vector Graphics.
#  NETSCAPE Netscape 216 color cube.
#  NULL NULL image useful for creating blank tiles with montage
#  OTB On-the-air Bitmap
#  PBM Portable bitmap format (black and white)
#  PCD Photo CD the maximum resolution written is 768x512 pixels
#  PCDS Photo CD decode with the sRGB color tables
#  PCL Page Control Language write only
#  PCX ZSoft IBM PC Paintbrush file
#  PDB Pilot Image Format read only
#  PDF Portable Document Format requires Ghostscript to read
#  PGM Portable graymap format (gray scale)
#  PICT Apple Macintosh QuickDraw/PICT file
#  PIX Alias/Wavefront RLE image format read only
#  PLASMA plasma fractal image. Specify the base color as the filename (e.g. plasma:blue-yellow). Use fractal to initialize to a random value (e.g. plasma:fractal
#  PNG Portable Network Graphics requires libpng-1.02.tar.gz
#  PNM Portable anymap use +compress to produce ASCII renditions
#  PPM Portable pixmap format (color)
#  PREVIEW show a preview an image enhancement, effect, or f/x specify the desired preview with the -preview option)
#  PRINT Send image to your computer printer
#  PS Adobe PostScript file requires Ghostscript to read
#  PSD  Adobe Photoshop bitmap file
#  PS2 Adobe Level II PostScript file requires Ghostscript to read
#  PS3 Adobe Level III PostScript file requires Ghostscript to read
#  PTIF Pyramid encoded TIFF requires tiff-v3.5.4.tar.gz
#  PWP  Seattle File Works multi-image file
#  P7 Xv's visual schnauzer format
#  RAD Radiance image file
#  RGB Raw red, green, and blue samples set -size and -depth to specify the image width, height, and depth
#  RGBA Raw red, green, blue, and matte samples set -size and -depth to specify the image width, height, and depth
#  RLA Alias/Wavefront image file read only
#  RLE Utah Run length encoded image file read only
#  SCAN Import image from a scanner device requires SANE Specify the device name and path as the filename (e.g. scan:mustek:/dev/scanner
#  SCT  Scitex Continuous Tone Picture image file
#  SFW  Seattle File Works image file
#  SGI Irix RGB image file
#  SHTML Hypertext Markup Language with a client-side image map write only
#  STEGANO Steganographic image use -size command line option to specify width, height, and offset of the steganographic image
#  SUN SUN Rasterfile
#  SVG  Scalable Vector Graphics requires libxml2-2.0.0; affine text transformations requires freetype2-current.tar.gz
#  TGA Truevision Targa image file
#  TIFF Tagged Image File Format requires tiff-v3.5.4.tar.gz
#  TILE Tile image with a texture read only
#  TIM PSX TIM file read only
#  TTF TrueType font file requires freetype-2-beta8.tar.gz
#  TXT Raw text file
#  UIL X-Motif UIL table
#  UYVY Interleaved YUV use -size command line option to specify width and height
#  VICAR   read only
#  VID Visual Image Directory
#  VIFF Khoros Visualization image file
#  WBMP Wireless bitmap image file support for uncompressed monochrome only
#  WIN Select image from or display image to your computer screen
#  WPG Word Perfect Graphic
#  WMF Windows Meta File Requires libwmf.  By default, renders WMF files to the size specified by the metafile header. Use the -density option to adjust the output resolution, and thereby adjust the ouput size. The default output resolution is 72DPI so '-density 144' results in an image twice as large as the default.
#  X Select image from or display image to your X server screen
#  XC Constant image of X server color set -size and -depth to specify the image width, height, and depth
#  XBM X Windows system bitmap, black and white only
#  XPM X Windows system pixmap file (color)
#  XWD X Windows system window dump file (color)
#  YUV CCIR 601 4:1:1 file use -size command line option to specify width and height
#
#-----------------------------------------------------------------------------#
sub image_convert_from_array {
  my ($use_purity_cache, $new_type, @images) = @_;
  my ($image, $background, $file_name, $path);
  my ($extension, $file_without_ext);

  use Image::Magick;

  foreach (@images){
    ($file_name, $path) = &shazam::io_split_path_and_file($_);
    ($extension, $file_without_ext) = &shazam::io_split_filename_and_exsension($file_name);

    $image = Image::Magick->new;

    # If a purity cache image exists open it, if not open the actual
    if ($use_purity_cache eq 'true' && -e $path . $file_without_ext . '_purity_cache.bmp'){
      $image->Read($path . $file_without_ext . '_purity_cache.bmp');
    } else {
      $image->Read($path . $file_name);
    }

    # Do Stuff
    #$image->Resize('geometry' => $size);

    # Write purity cache
    $image->Write($path . $file_without_ext . '_purity_cache.bmp') if ($use_purity_cache eq 'true');

    # Write actual file
    $image->Write($path . $file_without_ext . '.' . $new_type);

    undef $image;
   }
}
1;
