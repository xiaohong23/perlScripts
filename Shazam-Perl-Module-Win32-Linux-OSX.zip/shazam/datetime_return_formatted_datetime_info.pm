package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Date/Time Calculator
#
# $foo = &shazam::datetime_return_formatted_datetime_info('1', '+1d');
#
# Return Options Dates
#   '01'     February 5, 2001
#   '02'     02/05/2001
#   '03'     02/05/01
#   '04'     02-05-2001
#   '05'     02-05-01
#   '06'     Monday, February 5, 2001
#   '07'     Array (02/04/2001, 02/05/2001, 02/06/2001) (Yesterday, Today, Tomorrow)
#   '08'     Array ($full_month_name, $month_num, $day_num, $four_digit_year, $day_name,
#                   $full_month_name_yest, $month_num_yest, $day_num_yest, $four_digit_year_yest, $day_name_yest,
#                   $full_month_name_next, $month_num_next, $day_num_next, $four_digit_year_next, $day_name_next)
#
#
# Return Options Times
#   '30'     11:34:01 AM
#
#
# Return Options Dates & Time
#   '50'     2001-02-28-23-34-01      Good for sorting
#   '51'     20010228233401           Good for sorting
#   '52'     2001/02/28 23:34:01      Good for sorting
#
#
# Offset Format
#   "now" -- expire immediately
#   "+180s" -- in 180 seconds
#   "+2m" -- in 2 minutes
#   "+12h" -- in 12 hours
#   "+1d"  -- in 1 day
#   "+3M"  -- in 3 months
#   "+2y"  -- in 2 years
#   "-3m"  -- 3 minutes ago(!)
#-----------------------------------------------------------------------------#
sub datetime_return_formatted_datetime_info {
  my($return_option, $offset_by) = @_;
  my ($offset, $new_time_with_offset, $previous_day_with_offset, $next_day_with_offset);

  $new_time_with_offset = &shazam::datetime_adjust_epoch_time($offset_by, time);
  $previous_day_with_offset = &shazam::datetime_adjust_epoch_time('-1d', $new_time_with_offset);
  $next_day_with_offset = &shazam::datetime_adjust_epoch_time('+1d', $new_time_with_offset);

  #  $sec   Seconds after each minute (0 - 59)
  #  $min   Minutes after each hour (0 - 59)
  #  $hour  Hour since midnight (0 - 23)
  #  $mday  Numeric day of the month (1 - 31)
  #  $mon   Number of months since January (0 - 11)
  #  $year  Number of years since 1900
  #  $wday  Number of days since Sunday (0 - 6)
  #  $yday  Number of days since January 1 (0 - 365)
  #  $isdl  A flag for daylight savings time

  # Build New Date and Time Vars
  my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdl) = localtime($new_time_with_offset);
  my ($psec, $pmin, $phour, $pmday, $pmon, $pyear, $pwday, $pyday, $pisdl) = localtime($previous_day_with_offset);
  my ($nsec, $nmin, $nhour, $nmday, $nmon, $nyear, $nwday, $nyday, $nisdl) = localtime($next_day_with_offset);

  # Four Digit Year Stuff
  my $four_digit_year = $year; $four_digit_year += 1900;
  my $four_digit_year_previous = $pyear; $four_digit_year_previous += 1900;
  my $four_digit_year_next = $nyear; $four_digit_year_next += 1900;

  my $two_digit_year = substr($four_digit_year, 2, 2);
  my $two_digit_year_previous = substr($four_digit_year_previous, 2, 2);
  my $two_digit_year_next = substr($four_digit_year_next, 2, 2);

  my $AM_PM;
  if ($hour >= 12) {
    $AM_PM = 'PM';
  } else {
    $AM_PM = 'AM';
  }

  my(@full_month) = qw/January February March April May June July August September October November December/;
  my(@three_month) = qw/Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec/;
  my(@full_day) = qw/Sunday Monday Tuesday Wednesday Thursday Friday Saturday/;
  my(@three_day) = qw/Sun Mon Tue Wed Thu Fri Sat/;
  my(@num_hour) = qw/12 1 2 3 4 5 6 7 8 9 10 11 12 1 2 3 4 5 6 7 8 9 10 11/;
  my(@mil_hour) = qw/00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23/;

  my $sec_padded = sprintf("%02s", $sec);
  my $min_padded = sprintf("%02s", $min);

  my $num_hour = $num_hour[$hour];
  my $num_hour_padded = sprintf("%02s", $num_hour);


  # Month Calculations
  my $full_month = $full_month[$mon];
  my $num_month = ($mon + 1);
  my $num_month_padded = sprintf("%02s", ($mon + 1));

  my $full_month_previous = $full_month[$pmon];
  my $num_month_previous = ($pmon + 1);
  my $num_month_padded_previous = sprintf("%02s", ($pmon + 1));

  my $full_month_next = $full_month[$nmon];
  my $num_month_next = ($nmon + 1);
  my $num_month_padded_next = sprintf("%02s", ($nmon + 1));


  # Day Calculations
  my $num_day = $mday;
  my $num_day_padded = sprintf("%02s", $mday);

  my $num_day_previous = $pmday;
  my $num_day_padded_previous = sprintf("%02s", $pmday);

  my $num_day_next = $nmday;
  my $num_day_padded_next = sprintf("%02s", $nmday);


  # Return Options Dates
  return "$full_month[$mon] $mday, $four_digit_year" if ($return_option eq '01');
  return "$num_month_padded/$num_day_padded/$four_digit_year" if ($return_option eq '02');
  return "$num_month_padded/$num_day_padded/$two_digit_year" if ($return_option eq '03');
  return "$num_month_padded-$num_day_padded-$four_digit_year" if ($return_option eq '04');
  return "$num_month_padded-$num_day_padded-$two_digit_year" if ($return_option eq '05');
  return "$full_day[$wday], $full_month[$mon] $mday, $four_digit_year" if ($return_option eq '06');
  return ("$num_month_padded_previous/$num_day_padded_previous/$four_digit_year_previous",
          "$num_month_padded/$num_day_padded/$four_digit_year",
          "$num_month_padded_next/$num_day_padded_next/$four_digit_year_next" ) if ($return_option eq '07');

  return ($full_month[$mon], $num_month, $num_day, $four_digit_year, $full_day[$wday],
          $full_month[$pmon], $num_month_previous, $num_day_previous, $four_digit_year_previous, $full_day[$pwday],
          $full_month[$nmon], $num_month_next, $num_day_next, $four_digit_year_next, $full_day[$nwday]) if ($return_option eq '08');

  # Return Options Times
  return "$num_hour[$hour]:$min_padded:$sec_padded $AM_PM" if ($return_option eq '30');

  # Return Options Dates & Times
  return "$four_digit_year-$num_month_padded-$num_day_padded-$mil_hour[$hour]-$min_padded-$sec_padded" if ($return_option eq '50');
  return "$four_digit_year$num_month_padded$num_day_padded$mil_hour[$hour]$min_padded$sec_padded" if ($return_option eq '51');
  return "$four_digit_year/$num_month_padded/$num_day_padded $mil_hour[$hour]:$min_padded:$sec_padded" if ($return_option eq '52');

}
1;
