package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Day of week starts with Sunday or 0
# return options: normal abreviation, force three abreviation, full word,
#                 number, number padded
#
# eg. print &shazam::datetime::return_day_of_week_for_date($month, $day, $year, 'number');
#
#-----------------------------------------------------------------------------#
sub datetime_return_day_of_week_for_given_date {
  my ($month, $day, $year, $return_as) = @_;
  my ($num_of_day);

  $year-- if $month < 3;
  $num_of_day = ($year+int($year/4)-int($year/100)+int($year/400)+((0,3,2,5,0,3,5,1,4,6,2,4)[$month-1])+$day) % 7;
  return (('Sun','Mon','Tues','Wed','Thurs','Fri','Sat')[$num_of_day]) if ($return_as eq 'normal abreviation');
  return (('Sun','Mon','Tue','Wed','Thu','Fri','Sat')[$num_of_day]) if ($return_as eq 'force three abreviation');
  return (('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday')[$num_of_day]) if ($return_as eq 'full word');
  return $num_of_day if ($return_as eq 'number');
  return '0' . $num_of_day if ($return_as eq 'number padded');
}
1;
