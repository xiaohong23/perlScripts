package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_build_username_from_full_name{
  my ($fname, $mname, $lname, $org, $min_length, $max_length) = @_;
  my ($username);

  $min_length = '6' if ($min_length eq '');
  $max_length = '15' if ($min_length eq '');

  $username = substr(&shazam::string_trim_ws($fname), 0, 1) if ($fname ne '');
  $username .= substr(&shazam::string_trim_ws($mname), 0, 1) if ($mname ne '');
  $username .= substr(&shazam::string_trim_ws($lname), 0, 10) if ($lname ne '');
  $username .= substr(&shazam::string_trim_ws($org), 0, 10) if ($org ne '' && $fname eq '' && $mname eq '' && $lname eq '');
  $username =~ s/\W+//g;
  $username =~ s/-//g;

  # If it is too short make it min length
  if (length($username) < 6) {
    $username .= &shazam::utils_random_alphanumeric(6);
    $username = substr($username, 0, 6);
  }

  # If it is too long make it shorter
  if (length($username) > $max_length) {
    $username = substr($username, 0, $max_length);
  }

  $username = lc($username);

  return &shazam::string_trim_ws($username);
}
1;
