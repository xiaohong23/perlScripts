package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_key_value_csv_to_hash {
  my ($csv_string) = @_;
  my (@parent_split, @child_split, %new_hash, $key, $value);

  @parent_split = split(/:::/, $csv_string);

  foreach (@parent_split) {
    @child_split = split(/;;/, $_);
    $key = $child_split[0];
    $value = $child_split[1];

    $value =~ s/\[NL\]/\n/g;
    $value =~ s/\[CSV1\]/:::/g;
    $value =~ s/\[CSV2\]/;;/g;

    $new_hash{$key} = $value;
  }
  return %new_hash;
}
1;
