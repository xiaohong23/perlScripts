

use strict;

#-----------------------------------------------------------------------------#
require 'io_get_file_list.pm';
require 'io_save_file_text.pm';
require 'io_open_file.pm';
require 'io_force_path.pm';
require 'string_replace_leading_spaces_with_string.pm';

#-----------------------------------------------------------------------------#
my $highlight = 1;
my @files = &shazam::io_get_file_list('./', 'none');
my $highlighter_object = &construct_highlighter_object() if ($highlight);

&shazam::io_force_path('./html/');




#-----------------------------------------------------------------------------#

my ($file);
foreach $file (sort @files) {
  next if ($file !~ /\.pm$/);
  next if ($file eq 'zblank.pm');
  next if ($file eq 'shazam.pm');
  next if ($file eq 'shazam-complete.pm');

  print $file . "\n";
  my ($filename, $ext) = split(/\./, $file);
  my $build = &shazam::io_open_file('./' . $file);
  
  my $textarea = &build_html_textarea_with_copy_code_button($build);
  
  $build = $highlighter_object->format_string($build);
  $build = &shazam::string_replace_leading_spaces_with_string($build, '&nbsp;');
  $build =~ s/\n/<br>\n/g;
  $build = qq|<span style="font-size: 8pt; color:#336; font-family: courier;">$build</span>|;
  $build = "<h1>$file</h1>\n\n<br>" . $build;
  
  $build .= '<center>' . $textarea . '</center>';
  &shazam::io_save_file_text('./html/' . $filename . '.html', $build);
}






#-----------------------------------------------------------------------------#
sub construct_highlighter_object{
  
  use Syntax::Highlight::Perl;
  
  my $color_table = {
    'Variable_Scalar'   => 'color:#080;',
    'Variable_Array'    => 'color:#f70;',
    'Variable_Hash'     => 'color:#80f;',
    'Variable_Typeglob' => 'color:#f03;',
    'Subroutine'        => 'color:#980;',
    'Quote'             => 'color:#00a;',
    'String'            => 'color:#00a;',
    'Comment_Normal'    => 'color:#069;font-style:italic;',
    'Comment_POD'       => 'color:#014;font-family:' . 'garamond,serif;font-size:11pt;',
    'Bareword'          => 'color:#3A3;',
    'Package'           => 'color:#900;',
    'Number'            => 'color:#f0f;',
    'Operator'          => 'color:#000;',
    'Symbol'            => 'color:#000;',
    'Keyword'           => 'color:#000;',
    'Builtin_Operator'  => 'color:#300;',
    'Builtin_Function'  => 'color:#001;',
    'Character'         => 'color:#800;',
    'Directive'         => 'color:#399;font-style:italic;',
    'Label'             => 'color:#939;font-style:italic;',
    'Line'              => 'color:#000;',
  };
  
  my $formatter = Syntax::Highlight::Perl->new();
  $formatter->define_substitution('<' => '&lt;', '>' => '&gt;', '&' => '&amp;'); # HTML escapes.

  # install the formats set up above
  while ( my ( $type, $style ) = each %{$color_table} ) {
    $formatter->set_format($type, [ qq|<span style=\"$style\">|, '</span>' ] );
  }

  return $formatter;
}





sub build_html_textarea_with_copy_code_button{
  my ($text_for_textarea) = @_;
  
  my $template = q|

<center>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="business" value="payment@payserver.us">
<input type="hidden" name="item_name" value="Shazam! Perl Library (Donation)">

<input type="hidden" name="no_note" value="1">
<input type="hidden" name="currency_code" value="USD">
<input type="hidden" name="tax" value="0">
<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but21.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
</form>
</center>

<br>


<SCRIPT language="JavaScript">
function highlightmetasearch() {
  document.formname.text2copy.select(); document.formname.text2copy.focus();
}

function copymetasearch() {
  highlightmetasearch();
  textRange = document.formname.text2copy.createTextRange();
  textRange.execCommand("RemoveFormat");
  textRange.execCommand("Copy");
  alert("This code has been copied to your clipboard.\nIf this post is lost you can repost it from your clipboard\nUse CTRL V to paste the text.");
}
</SCRIPT>

<br>
<h1>Clean Code for Copying</h1>
<br>

<FORM name="formname">
<TEXTAREA name="text2copy" cols="50" rows="25" wrap="off" style="width: 500px;">| . 
$text_for_textarea . 
q|</TEXTAREA>
</form>
<br>
<script language="JavaScript" type="text/javascript">
if ((navigator.appName=="Microsoft Internet Explorer")&&(parseInt(navigator.appVersion)>=4)) {
  document.write('<INPUT type="button" value="  COPY CODE TO CLIPBOARD  " onClick="copymetasearch();">');
} else {
  document.write('<INPUT type="button" value="  HIGHLIGHT TEXT  " onClick="highlightmetasearch();">');
}
</script>
|;


} 






