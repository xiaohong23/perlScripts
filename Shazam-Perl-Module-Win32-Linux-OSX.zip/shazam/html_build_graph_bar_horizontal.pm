package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_build_graph_bar_horizontal {
  my ($bar_style, $item_separator, $scale, $field_top_specifier, $field_left_specifier, $field_right_specifier, $color_mode_array_ref, @dataset) = @_;
  $scale = '' if ($scale <= 0);
  my $build;
  
  my @color_mode_array = (ref($color_mode_array_ref) eq 'ARRAY')?@$color_mode_array_ref:('');
  #print Dumper(@color_mode_array);
  my $color_mode = shift(@color_mode_array);
  my @color_array;
  if ($color_mode eq '' && @color_array < 1) {
    @color_array = ('#888888');
  } elsif ($color_mode eq 'repeat' || $color_mode eq 'normal' || $color_mode eq 'default' || $color_mode eq '') {
    @color_array = @color_mode_array;
  } elsif ($color_mode eq 'fade' || $color_mode eq 'gradient') {
    @color_array = &shazam::graphics_color_return_gradient($color_mode_array[0], $color_mode_array[1], scalar(@dataset));
  }
  
  foreach (@color_array) { $_ = qq^ bgcolor="$_"^ }
  
  while (@color_array < @dataset) {
    my @colors_to_push = @color_array;
    if (@color_array + @colors_to_push > @dataset) {
      @colors_to_push = splice(@colors_to_push, 0, @dataset - @color_array);
    }
    push(@color_array, @colors_to_push);
    if (@color_array < 1) {
      foreach (0..@dataset-1) {
        $color_array[$_] = '';
      }
    }
  }
  
  # Field Specifiers
  #
  # %l = label
  # %v = value
  # %p = percent of total rounded
  # %P = percent of total unrounded
  # %s = percent of scale rounded
  # %S = percent of scale unrounded
  # %m = maximum
  # %t = total
  # %r = rank descending
  # %R = rank ascending

  my $maximum;
  my $total;
  my @values;
  foreach (@dataset) {
    my ($key, $value) = split(/::/, $_);
    $maximum = $value if ($value > $maximum);
    $total += $value;
    push(@values, $value);
  }
  my @order = &shazam::struct_return_array_sort_indicies(@values);
  
  $scale = $maximum if ($scale < $maximum);
  $scale = 1 if ($scale == 0);
  
  my $columns = 1;
  $columns++ if ($field_left_specifier ne '');
  $columns++ if ($field_right_specifier ne '');

  my $index;
  foreach (@dataset) {
    my ($key, $value) = split(/::/, $_);
    my $bar_length = int($value / $scale * 100);
    my $bar_length_complimentary = 100 - $bar_length;
    my $percent = ($total>0)? int($value / $total * 100): 0;
    my $rank_a = $order[$index] + 1;
    my $rank_d = @order - $order[$index];
    
    if ($color_mode eq 'value' || $color_mode eq 'percent' || $color_mode eq 'scale') {
      $color_array[$index] = ' bgcolor="#' . [&shazam::graphics_color_return_gradient($color_mode_array[0], $color_mode_array[1], [$bar_length])]->[0] . '"';
    }

    my %replacements_hash;
    $replacements_hash{'%l'} = $key;
    $replacements_hash{'%v'} = $value;
    $replacements_hash{'%p'} = $percent;
    $replacements_hash{'%P'} = ($total>0)? $value / $total * 100: 0;
    $replacements_hash{'%s'} = $bar_length;
    $replacements_hash{'%S'} = $value / $scale * 100;
    $replacements_hash{'%m'} = $maximum;
    $replacements_hash{'%t'} = $total;
    $replacements_hash{'%r'} = $rank_d;
    $replacements_hash{'%R'} = $rank_a;

    my $field_top = $field_top_specifier;
    my $field_left = $field_left_specifier;
    my $field_right = $field_right_specifier;
    &shazam::string_do_replacements_from_hash_ref(\%replacements_hash, \$field_top, \$field_left, \$field_right);
    
    my $bar = qq^<table width="100%" style="border: inset 1px;" cellspacing="0" cellpadding="0"><tr><td width="$bar_length%" align="right" style="$bar_style"$color_array[$index]><img src="$core::dynamic_vars{'url shared system'}images/transparent.gif" width="1" height="1"></td><td width="$bar_length_complimentary%"><img src="$core::dynamic_vars{'url shared system'}images/transparent.gif" width="1"></td></tr></table>^;

    $build .= qq^<tr><td colspan="$columns" style="padding: 0px; spacing: 0px;">$item_separator</td></tr>\n^ if ($item_separator ne '' && $index == 0);
    $build .= qq^<tr><td colspan="$columns" style="padding-top: 3px; padding-bottom: 0px;">$field_top</td></tr>\n^ if ($field_top_specifier ne '');
    $build .= '<tr>';
    $build .= qq^<td align="right" width="0">$field_left</td>^ if ($field_left_specifier ne '');
    $build .= qq^<td width="100%">$bar</td>^;
    $build .= qq^<td>$field_right</td>^ if ($field_right_specifier ne '');
    $build .= "</tr>\n";
    $build .= qq^<tr><td colspan="$columns" style="padding: 0px; spacing: 0px;">$item_separator</td></tr>\n^ if ($item_separator ne '');
    $index++;
  }

  $build = qq^\n<table width="100%">\n$build</table>\n^;

  #$build = qq^<style>.box_dark{background-color:#888888;} .box_light{background-color:#AAAAAA;}</style>\n$build^;

  return $build;
}
1;
