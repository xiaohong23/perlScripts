

use strict;

#-----------------------------------------------------------------------------#
require 'io_get_file_list.pm';
require 'io_save_file_text.pm';
require 'io_open_file.pm';
require 'io_force_path.pm';
require 'string_replace_leading_spaces_with_string.pm';

#-----------------------------------------------------------------------------#
my $highlight = 1;
my @files = &shazam::io_get_file_list('./', 'none');
my $highlighter_object = &construct_highlighter_object() if ($highlight);

&shazam::io_force_path('./html/');




#-----------------------------------------------------------------------------#

my ($file);
foreach $file (sort @files) {
  next if ($file !~ /\.pm$/);
  next if ($file eq 'zblank.pm');
  next if ($file eq 'shazam.pm');
  next if ($file eq 'shazam-complete.pm');

  print $file . "\n";
  my ($filename, $ext) = split(/\./, $file);
  my $build = &shazam::io_open_file('./' . $file);
  
  my $textarea = &build_html_textarea_with_copy_code_button($build);
  
  $build = $highlighter_object->format_string($build);
  $build = &shazam::string_replace_leading_spaces_with_string($build, '&nbsp;');
  $build =~ s/\n/<br>\n/g;
  $build = qq|<div style="font-size: 10px; color: #ffffff; font-family:  Lucida Console;">$build</div>|;
  
  my $keywords = $file;

  $file =~ s/_/ /g;
  $keywords =~ s/_/, /g;
  $keywords =~ s/\.pm$//g;
  $keywords =~ s/, $//g;


  $build = qq~

  <meta name="keywords" content="perl, $keywords, sub, routine, function, free, library, mongers, cpan, windows, linux, activestate">

  <h1>Free Perl Code Example - $file</h1>\n\n
  
  <br>

  $build
    
  <br>

  <center>
  <a href="http://www.bryantmcgill.com/Shazam_Perl_Module/Subroutines/"><b>More Subroutines</b></a> | <a href="http://www.bryantmcgill.com/Shazam_Perl_Module/"><b>Shazam! Perl Module</b></a> | <a href="http://www.bryantmcgill.com/Shazam_Perl_Module/Download_Now/"><b>Download Complete Module</b></a>
  </center>

  <br><br>
  ~;



  $build .= '<center>' . $textarea . '</center>';
  &shazam::io_save_file_text('./html/' . $filename . '.html', $build);
}






#-----------------------------------------------------------------------------#
sub construct_highlighter_object{
  
  use Syntax::Highlight::Perl;
  
  my $color_table = {
    'Variable_Scalar'   => 'color:#6D9E97;',
    'Variable_Array'    => 'color:#f70;',
    'Variable_Hash'     => 'color:#80f;',
    'Variable_Typeglob' => 'color:#f03;',
    'Subroutine'        => 'color:#980;',
    'Quote'             => 'color:#00a;',
    'String'            => 'color:#899A4B;',
    'Comment_Normal'    => 'color:#A09E64; font-style:italic;',
    'Comment_POD'       => 'color:#D7D6D5;font-family:' . ' Lucida Console, serif; font-size:10pt;',
    'Bareword'          => 'color:#3A3;',
    'Package'           => 'color:#900;',
    'Number'            => 'color:#f0f;',
    'Operator'          => 'color:#fff;',
    'Symbol'            => 'color:#fff;',
    'Keyword'           => 'color:#915151;',
    'Builtin_Operator'  => 'color:#300;',
    'Builtin_Function'  => 'color:#D7D6D5;',
    'Character'         => 'color:#800;',
    'Directive'         => 'color:#399;font-style:italic;',
    'Label'             => 'color:#939;font-style:italic;',
    'Line'              => 'color:#fff;',
  };
  
  my $formatter = Syntax::Highlight::Perl->new();
  $formatter->define_substitution('<' => '&lt;', '>' => '&gt;', '&' => '&amp;'); # HTML escapes.

  # install the formats set up above
  while ( my ( $type, $style ) = each %{$color_table} ) {
    $formatter->set_format($type, [ qq|<span style=\"$style\">|, '</span>' ] );
  }

  return $formatter;
}





sub build_html_textarea_with_copy_code_button{
  my ($text_for_textarea) = @_;
  
  my $template = q|

<SCRIPT language="JavaScript">
function highlightmetasearch() {
  document.formname.text2copy.select(); document.formname.text2copy.focus();
}

function copymetasearch() {
  highlightmetasearch();
  textRange = document.formname.text2copy.createTextRange();
  textRange.execCommand("RemoveFormat");
  textRange.execCommand("Copy");
  alert("This code has been copied to your clipboard.\nIf this post is lost you can repost it from your clipboard\nUse CTRL V to paste the text.");
}
</SCRIPT>


<!-- begin default box -->
<center>
<table width="500" border="0" cellpadding="0" cellspacing="0">
  <tr valign="top">
    <td align="left"><img src="<!--url to template-->box_top_left.gif" width="10" height="10" alt="" border="0"></td>
    <td width="4000" background="<!--url to template-->box_top_mid.gif"><img src="<!--url to template-->box_top_mid.gif" width="1" height="10" alt="" border="0"></td>
    <td align="right"><img src="<!--url to template-->box_top_right.gif" width="10" height="10" alt="" border="0"></td>
  </tr>
  <tr>
    <td background="<!--url to template-->box_left_mid.gif"><img src="<!--url to template-->box_left_mid.gif" width="10" height="1" alt="" border="0"></td>
    <td valign="middle"  bgcolor="#363533">

<h2>Clean Code for Copying</h2>

<center>


<FORM name="formname">
<TEXTAREA name="text2copy" cols="50" rows="25" wrap="off" style="width: 450px; background-color:#C6C5C2; color: #454441; font-size: 9px;">| . 
$text_for_textarea . 
q|</TEXTAREA>
</form>
<br>
<script language="JavaScript" type="text/javascript">
if ((navigator.appName=="Microsoft Internet Explorer")&&(parseInt(navigator.appVersion)>=4)) {
  document.write('<INPUT type="button" value="  COPY CODE TO CLIPBOARD  " onClick="copymetasearch();">');
} else {
  document.write('<INPUT type="button" value="  HIGHLIGHT TEXT  " onClick="highlightmetasearch();">');
}
</script>


</center>
 
 <br>
   </td>   
    <td background="<!--url to template-->box_right_mid.gif"><img src="<!--url to template-->box_right_mid.gif" width="10" height="1" alt="" border="0"></td>
  </tr>
  <tr valign="bottom">
    <td align="left"><img src="<!--url to template-->box_bottom_left.gif" width="10" height="10" alt="" border="0"></td>
    <td width="4000" background="<!--url to template-->box_bottom_mid.gif"><img src="<!--url to template-->box_bottom_mid.gif" width="1" height="10" alt="" border="0"></td>
    <td align="right"><img src="<!--url to template-->box_bottom_right.gif" width="10" height="10" alt="" border="0"></td>
  </tr>
</table>
</center>
<!-- end default box -->


<br><br>


<center><img src="../shazam.jpg" border="0"></center>



|;


} 






