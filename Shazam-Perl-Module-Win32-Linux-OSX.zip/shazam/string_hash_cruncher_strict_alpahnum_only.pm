package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# %foo = &shazam::string_hash_cruncher_strict_alpahnum_only(\%hash, '25', 'true');
#-----------------------------------------------------------------------------#
sub string_hash_cruncher_strict_alpahnum_only{
  my($hash_ref, $max_chars, $trim) = @_;
  my(%new_hash, $work);

  # if it is passed in then Inc it bacause it is 0 based
  $max_chars++ if ($max_chars);

  foreach (keys %$hash_ref){
    $work = $$hash_ref{$_};
    $work =~ s/\s/_/g; # Replace whitespace with _
    $work =~ s/\W//g;  # Delete all non AlphaNum Chars
    $work =~ s/_+/_/g; # Replace more than one _ with one _
    $work =~ s/_/ /g;  # Replace all _ with space
    $work = substr($work, 0, $max_chars) if ($max_chars); # Return a max ov 25 chars
    $work = &shazam::string_trim_ws($work) if ($trim eq 'true');
    $new_hash{$_} = $work if ($work);
  }

  return %new_hash;
}
1;
