package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub wx_widget_get_value {
  my ($widget_object) = @_;
  my $widget_type = ref $widget_object;
  $widget_type =~ s/^Wx:://;
  $widget_type = lc $widget_type;
  my $sub = "wx_widget_get_value_$widget_type";
  my $value = &$sub($widget_object);
  return $value;
}
1;
