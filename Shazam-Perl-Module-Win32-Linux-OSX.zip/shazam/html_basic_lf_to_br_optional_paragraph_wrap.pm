package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_basic_lf_to_br_optional_paragraph_wrap {
  my($text, $wrap_in_paragraph_tags) = @_;
  $text =~ s/\r/\n/g;
  $text =~ s/\n/\<br\>/g;
  $text = qq|<p>$text</p>| if ($wrap_in_paragraph_tags eq 'true' && $text ne '');
  return $text;
}
1;
