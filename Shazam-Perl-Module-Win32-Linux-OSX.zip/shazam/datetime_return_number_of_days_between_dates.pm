package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# eg. print &shazam::datetime_return_number_of_days_between_dates(1, 1, 1996, 12, 31, 1998);
#
# returns the number of days between the two dates.  The value will be negative
# if the second date is earlier than the first date.
#-----------------------------------------------------------------------------#
sub datetime_return_number_of_days_between_dates {
  my ($mon1, $day1, $year1, $mon2, $day2, $year2) = @_;

  use Time::Local;

  return sprintf("%.0f", (timelocal(0, 0, 0, $day2, $mon2 - 1, $year2) - timelocal(0, 0, 0, $day1, $mon1 - 1, $year1)) / (60 * 60 * 24));
}
1;
