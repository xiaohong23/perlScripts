package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub keydb_read_file {
  my ($file, $escape_html) = @_;  
  my %build;
  my @split;
  
  $escape_html = 'false' if (!$escape_html);

  use Fcntl qw(:DEFAULT :flock);
  use strict;

  #&shazam::keydb_create_file($file) if (!-e $file);
  
  if (-e $file) {
    sysopen(DB, $file, O_RDWR|O_CREAT) or &shazam::keydb_cgi_error("$!", "[keydb_read_file]: The data file requested could not be located on this machine at the specified name and path.<br><br>$file");
    eval qq^flock(DB, LOCK_SH)^;
    while (<DB>) {
      chomp($_); # Remove LF 
      chop($_) if (substr($_, -1, 1) eq "\015"); # Remove windows CR if it exists
      @split = split(/\|/, $_);
      if ($split[0]) { $build{$split[0]} = $split[1]; }  
    }
    
    eval qq^flock(DB, LOCK_UN)^; # Unlock
    close(DB);  

    &shazam::keydb_expand_hash_from_storage_by_ref(\%build);
    &shazam::keydb_escape_html_in_hash_by_ref(\%build) if ($escape_html eq 'true');

    return %build;
  } else {
    &shazam::keydb_cgi_error("$!", "[keydb_read_file]: The data file requested could not be located on this machine at the specified name and path.<br><br>$file");
  }
}


1;
