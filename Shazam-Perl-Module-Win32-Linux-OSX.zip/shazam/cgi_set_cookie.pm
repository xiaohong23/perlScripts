package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Cookie : Perl routines for setting/reading browser cookies.
#-----------------------------------------------------------------------------#
  # $name       - cookie name (ie: username)
  # $value      - cookie value (ie: "joe user")
  # $exp        - exp date, cookie will be deleted at this date.
              # Format: Wdy, DD-Mon-YYYY HH:MM:SS GMT
              # "now" -- expire immediately
              # "+180s" -- in 180 seconds
              # "+2m" -- in 2 minutes
              # "+12h" -- in 12 hours
              # "+1d"  -- in 1 day
              # "+3M"  -- in 3 months
              # "+2y"  -- in 2 years
              # "-3m"  -- 3 minutes ago(!)
              # If you don't supply one of these forms, we assume you are
              # specifying the date yourself

  # $path       - Cookie is sent only when this path is accessed   (ie: /);
  # $domain     - Cookie is sent only when this domain is accessed (ie: .edis.org)
  # $secure     - Cookie is sent only with secure https connection

# &shazam::cgi_set_cookie("name", "value", "+5h");
#-----------------------------------------------------------------------------#
sub cgi_set_cookie {
  my($name, $value, $expires, $path, $domain, $secure) = @_;
  my($cookie_info, $exp);
  my $default_domain = $ENV{'SERVER_NAME'};

  # Calculate and Format the Expiration
  $exp = &shazam::cgi_datetime_format( &shazam::datetime_adjust_epoch_time($expires), "cookie");

  unless (defined $name) { die("SetCookie : Cookie name must be specified\n"); }
  if ($exp && $exp !~ /^[A-Z]{3}, \d\d-[A-Z]{3}-\d{4} \d\d:\d\d:\d\d GMT$/i) { die("SetCookie : Exp Dat format isn't: Wdy, DD-Mon-YYYY HH:MM:SS GMT\n"); }

  if ($name)            { $name  = &shazam::cgi_url_encode($name); }
  if ($value)           { $value = &shazam::cgi_url_encode($value); }
  if ($exp)             { $cookie_info .= "expires=$exp; "; }      else {};
  if ($path)            { $cookie_info .= "path=$path; "; }        else { $cookie_info .= "path=/; "; };
  if ($domain)          { $cookie_info .= "domain=$domain; "; }    else { $cookie_info .= "domain=$default_domain; "; };
  if ($secure)          { $cookie_info .= "secure; "; }

  return "Set-Cookie: $name=$value; $cookie_info\n";
}
1;
