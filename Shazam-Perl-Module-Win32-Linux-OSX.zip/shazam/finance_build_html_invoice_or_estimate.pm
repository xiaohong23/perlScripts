package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub finance_build_html_invoice_or_estimate{
  my ($type, $top_center, $logo_url,
      $company_name, $company_address, $company_city_state_zip, $company_phone, $company_email,
      $billto_attention, $billto_company, $billto_address, $billto_city_state_zip, $billto_phone, $billto_email,
      $invoice_number, $date_generated, $due_date, $discount_percentage, $tax, $comments, @details) = @_;


  my ($template, $total_due, $details, $subtotal, $discount_amount);


  # 0 Date
  # 1 Description
  # 2 qty
  # 3 price

  $subtotal = 0;

  my($detail_build, $line_sum);
  foreach(@details) {
   my ($d_date, $d_desc, $d_qty, $d_price) = split(/\|/, $_);

   $d_date = $core::dynamic_vars{'datetime date'} if ($d_date eq '');
   $d_qty = 0 if ($d_qty eq '');
   $d_price = 0.00 if ($d_price eq '');

   $line_sum = ($d_price * $d_qty);
   $subtotal = ($subtotal + $line_sum);
   $discount_amount = ($subtotal * ($discount_percentage /100));
   $total_due = ($subtotal - $discount_amount);

   $d_price = &shazam::finance_format_money($d_price);
   $line_sum = &shazam::finance_format_money($line_sum);
   $subtotal = &shazam::finance_format_money($subtotal);
   $discount_amount = &shazam::finance_format_money($discount_amount);
   $total_due = &shazam::finance_format_money($total_due);

    $detail_build .= qq|
      <TR valign="top">
        <TD valign="top" bgcolor="#FFFFFF" styleID="StyleServiceDate" nowrap>$d_date</TD>
        <TD valign="top" bgcolor="#FFFFFF" styleID="StyleItemDesc">$d_desc</TD>
        <TD align="center" valign="top" bgcolor="#FFFFFF" styleID="StyleItemDesc" nowrap>$d_qty</TD>
        <TD align="right" valign="top" bgcolor="#FFFFFF" styleID="StyleItemDesc" nowrap>\$$d_price</TD>
        <TD align="right" valign="top" bgcolor="#FFFFFF" styleID="StyleItemAmount" nowrap>\$$line_sum</TD>
      </TR>
    |;
  }



$template = qq|

<center>
<table width="95%" border="0" cellpadding="10" cellspacing="0">
  <tr>
    <td bgcolor="#FFFFFF">
      <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" styleID="style_layout">
        <TR>
          <TD>
            <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="row_grouping">
              <TR>
                <TD width="34%" styleID="row_spacing"></TD>
                <TD width="31%" valign="top" styleID="row_field" align="right" bgcolor="#FFFFFF">
                  <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StyleTitle">
                    <TR>
                      <TD align="center" valign="center" nowrap="true" bgcolor="#FFFFFF"><b>&nbsp;$top_center&nbsp;</b></TD>
                    </TR>
                  </TABLE>
                </TD>
                <TD width="34%" styleID="row_spacing"></TD>
              </TR>
            </TABLE>
          </TD>
        </TR>
        <TR>
          <TD>&nbsp;</TD>
        </TR>
        <TR>
          <TD>
            <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="row_grouping">
              <TR>
                <TD width="47%" valign="top" styleID="row_field">
                  <TABLE width="100%" border="0" cellpadding="3" cellspacing="0" styleID="combined">
                    <TR>
                      <TD width="100%" styleID="StyleCompName" align="left" valign="top" bgcolor="#FFFFFF"><b>$company_name</b></TD>
                    </TR>
                    <TR>
                      <TD width="100%" styleID="StyleCompAddress" align="left" valign="top" bgcolor="#FFFFFF">
                        <TABLE border="0" cellpadding="0" cellspacing="0" styleID="format_address">
                          <TR>
                            <TD nowrap="true" bgcolor="#FFFFFF">$company_address</TD>
                          </TR>
                          <TR>
                            <TD bgcolor="#FFFFFF">$company_city_state_zip</TD>
                          </TR>
                          <TR>
                            <TD bgcolor="#FFFFFF">$company_phone</TD>
                          </TR>
                          <TR>
                            <TD bgcolor="#FFFFFF">$company_email</TD>
                          </TR>
                        </TABLE>
                      </TD>
                    </TR>
                  </TABLE>
                </TD>
                <TD width="18%" styleID="row_spacing"></TD>
                <TD width="34%" valign="top" styleID="row_field" align="right">
                  <TABLE width="100%" border="0" cellpadding="3" cellspacing="0" styleID="combined_complex">
                    <TR>
                      <TD>
                        <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="combined_complex_inner">
                          <TR>
                            <TD width="100%" bgcolor="#FFFFFF">
                              <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StyleTitle">
                                <TR>
                                  <TD align="right" valign="center" nowrap="true" bgcolor="#FFFFFF"><b>&nbsp;$type&nbsp;</b></TD>
                                </TR>
                              </TABLE>
                            </TD>
                          </TR>
                        </TABLE>
                      </TD>
                    </TR>
                    <TR>
                      <TD>
                        <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="combined_complex_inner">
                          <TR>
                            <TD width="50%"></TD>
                            <TD width="50%"></TD>
                            <TD width="50%"></TD>
                          </TR>
                        </TABLE>
                      </TD>
                    </TR>
                    <TR>
                      <TD>
                        <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="combined_complex_inner">
                          <TR>
                            <TD width="50%"></TD>
                            <TD width="50%" valign="top">
                              <TABLE width="100%" border="0" cellpadding="3" cellspacing="2" styleID="combined" class="box_dark">
                                <TR>
                                  <TD width="100%" class="box_dark">
                                    <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StyleInvNum">
                                      <TR>
                                        <TD align="center" valign="center" nowrap="true" class="titled_box_title"><b>&nbsp;$type #&nbsp;</b></TD>
                                      </TR>
                                    </TABLE>
                                  </TD>
                                </TR>
                                <TR>
                                  <TD width="100%" styleID="StyleInvNum" align="center" valign="center" nowrap="true" bgcolor="#FFFFFF">
                                    &nbsp;$invoice_number&nbsp;</TD>
                                </TR>
                              </TABLE>
                            </TD>
                            <TD width="50%"></TD>
                          </TR>
                        </TABLE>
                      </TD>
                    </TR>
                  </TABLE>
                </TD>
              </TR>
            </TABLE>
          </TD>
        </TR>
        <TR>
          <TD>&nbsp;</TD>
        </TR>
        <TR>
          <TD>
            <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="row_grouping">
              <TR>
                <TD width="26%" valign="top" styleID="row_field">
                  <TABLE width="100%" border="0" cellpadding="3" cellspacing="2" styleID="combined" class="box_dark">
                    <TR>
                      <TD width="100%">
                        <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StyleBillTo" class="box_dark">
                          <TR>
                            <TD align="left" valign="center" nowrap="true" class="titled_box_title"><b>&nbsp;TO&nbsp;</b></TD>
                          </TR>
                        </TABLE>
                      </TD>
                    </TR>
                    <TR>
                      <TD width="100%" styleID="StyleBillTo" align="left" valign="top" bgcolor="#FFFFFF">
                        <TABLE border="0" cellpadding="0" cellspacing="0" styleID="format_address">
                          <TR>
                            <TD nowrap="true" bgcolor="#FFFFFF">$billto_attention</TD>
                          </TR>
                          <TR>
                            <TD nowrap="true" bgcolor="#FFFFFF">$billto_company</TD>
                          </TR>
                          <TR>
                            <TD nowrap="true" bgcolor="#FFFFFF">$billto_address</TD>
                          </TR>
                          <TR>
                            <TD bgcolor="#FFFFFF">$billto_city_state_zip</TD>
                          </TR>
                          <TR>
                            <TD bgcolor="#FFFFFF">$billto_phone</TD>
                          </TR>
                          <TR>
                            <TD bgcolor="#FFFFFF">$billto_email</TD>
                          </TR>
                        </TABLE>
                      </TD>
                    </TR>
                  </TABLE>
                </TD>
                <TD width="40%" styleID="row_spacing"></TD>
                <TD width="34%" valign="top" styleID="row_field" align="right">
                  <TABLE width="100%" border="0" cellpadding="3" cellspacing="2" styleID="combined" class="box_dark">
                    <TR>
                      <TD width="50%">
                        <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StyleDate" class="box_dark">
                          <TR>
                            <TD align="center" valign="center" nowrap="true" class="titled_box_title"><b>&nbsp;DATE&nbsp;</b></TD>
                          </TR>
                        </TABLE>
                      </TD>
                      <TD width="50%">
                        <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StyleDueDate" class="box_dark">
                          <TR>
                            <TD align="center" valign="center" nowrap="true" class="titled_box_title"><b>&nbsp;DUE DATE&nbsp;</b></TD>
                          </TR>
                        </TABLE>
                      </TD>
                    </TR>
                    <TR>
                      <TD width="50%" styleID="StyleDate" align="center" valign="center" nowrap="true" bgcolor="#FFFFFF">
                        &nbsp;$date_generated&nbsp;</TD>
                      <TD width="50%" styleID="StyleDueDate" align="center" valign="center" nowrap="true" bgcolor="#FFFFFF">&nbsp;$due_date&nbsp;</TD>
                    </TR>
                  </TABLE>
                </TD>
              </TR>
            </TABLE>
          </TD>
        </TR>
        <TR>
          <TD>&nbsp;</TD>
        </TR>
        <TR>
          <TD>
            <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="row_grouping">
              <TR>
                <TD width="65%" styleID="row_spacing"></TD>
                <TD width="34%" valign="top" styleID="row_field" align="right">
                  <TABLE width="100%" border="0" cellpadding="3" cellspacing="2" styleID="combined" class="box_dark">
                    <TR>
                      <TD width="50%" class="box_dark">
                        <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StmtStyleAmountDue">
                          <TR>
                            <TD align="center" valign="center" nowrap="true" class="titled_box_title"><b>&nbsp;AMOUNT DUE&nbsp;</b></TD>
                          </TR>
                        </TABLE>
                      </TD>
                      <TD width="50%" class="box_dark">
                        <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StmtStyleAmountEnclosed">
                          <TR>
                            <TD align="center" valign="center" nowrap="true" class="titled_box_title"><b>&nbsp;ENCLOSED&nbsp;</b></TD>
                          </TR>
                        </TABLE>
                      </TD>
                    </TR>
                    <TR>
                      <TD width="50%" styleID="StmtStyleAmountDue" align="right" valign="center" nowrap="true" bgcolor="#FFFFFF">
                        &nbsp;\$$total_due&nbsp;</TD>
                      <TD width="50%" styleID="StmtStyleAmountEnclosed" align="right" valign="center" nowrap="true" bgcolor="#FFFFFF">
                        &nbsp;&nbsp;&nbsp;</TD>
                    </TR>
                  </TABLE>
                </TD>
              </TR>
            </TABLE>
          </TD>
        </TR>
        <TR>
          <TD>&nbsp;</TD>
        </TR>
        <TR>
          <TD>
            <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="row_grouping">
              <TR>
                <TD width="100%" valign="center" styleID="row_field" align="center" bgcolor="#FFFFFF">
                  <TABLE cellpadding="0" cellspacing="0">
                    <TR>
                      <TD>
                        <hr>
                      </TD>
                      <TD width="1%" nowrap="true" align="center">&nbsp;
                        <i>Clip Here</i>&nbsp;</TD>
                      <TD>
                        <hr>
                      </TD>
                    </TR>
                  </TABLE>
                </TD>
              </TR>
            </TABLE>
          </TD>
        </TR>
        <TR>
          <TD></TD>
        </TR>
        <TR>
          <TD>
            <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="item_table_row">
              <TR>
                <TD width="100%" valign="top">
                  <TABLE width="100%" border="0" class="box_dark" cellpadding="6" cellspacing="2" rules="cols" styleID="item_table">
                    <TR>
                      <TD width="" align="left" valign="center" nowrap="true" class="titled_box_title" styleID="StyleServiceDate"><b>DATE</b></TD>
                      <TD width="100%" align="left" valign="center" nowrap="true" class="titled_box_title" styleID="StyleItemDesc"><b></b></TD>
                      <TD width="" align="center" valign="center" nowrap="true" class="titled_box_title" styleID="StyleItemDesc"><b>QTY</b></TD>
                      <TD width="" align="center" valign="center" nowrap="true" class="titled_box_title" styleID="StyleItemAmount"><b>UNIT</b></TD>
                      <TD width="" align="left" valign="center" nowrap="true" class="titled_box_title" styleID="StyleItemAmount"><b>AMOUNT</b></TD>
                    </TR>

                    $detail_build

                  </TABLE>
                </TD>
              </TR>
            </TABLE>
          </TD>
        </TR>
        <TR>
          <TD></TD>
        </TR>
        <TR>
          <TD>
            <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="row_grouping">
              <TR>
                <TD width="65%" styleID="row_spacing"></TD>
                <TD width="34%" valign="top" styleID="row_field" align="right">
                  <TABLE width="100%" border="0" cellpadding="3" cellspacing="2" styleID="combined" class="box_dark">
                    <TR>
                      <TD width="50%">
                        <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StyleSubtotal">
                          <TR>
                            <TD align="right" valign="center" nowrap="true" class="titled_box_title"><b>&nbsp;SUBTOTAL&nbsp;</b></TD>
                          </TR>
                        </TABLE>
                      </TD>
                      <TD width="50%" styleID="StyleSubtotal" align="right" valign="center" nowrap="true" bgcolor="#FFFFFF"><b>&nbsp;\$$subtotal&nbsp;</b></TD>
                    </TR>
                    <TR>
                      <TD width="50%">
                        <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StyleDiscountAmt">
                          <TR>
                            <TD align="right" valign="center" nowrap="true" class="titled_box_title"><b>&nbsp;DISCOUNT ($discount_percentage\%)&nbsp;</b></TD>
                          </TR>
                        </TABLE>
                      </TD>
                      <TD width="50%" styleID="StyleDiscountAmt" align="right" valign="center" nowrap="true" bgcolor="#FFFFFF"><b>&nbsp;-\$$discount_amount&nbsp;</b></TD>
                    </TR>
                    <TR>
                      <TD width="50%">
                        <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StyleTotalAmount">
                          <TR>
                            <TD align="right" valign="center" nowrap="true" class="titled_box_title"><b>&nbsp;TOTAL&nbsp;</b></TD>
                          </TR>
                        </TABLE>
                      </TD>
                      <TD width="50%" styleID="StyleTotalAmount" align="right" valign="center" nowrap="true" bgcolor="#FFFFFF">
                        <b>&nbsp;\$$total_due&nbsp;</b></TD>
                    </TR>
                  </TABLE>
                </TD>
              </TR>
            </TABLE>
          </TD>
        </TR>
        <TR>
          <TD>&nbsp;</TD>
        </TR>
        <TR>
          <TD>
            <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="row_grouping">
              <TR>
                <TD width="63%" valign="center" styleID="StyleCustMsg" align="left" bgcolor="#FFFFFF">


                </TD>
                <TD width="37%" styleID="row_spacing"></TD>
              </TR>
            </TABLE>
          </TD>
        </TR>
      </TABLE>

    </td>
  </tr>
</table>
</center>
|;

return $template;
}
1;
