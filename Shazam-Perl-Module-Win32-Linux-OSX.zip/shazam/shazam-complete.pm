package shazam;

use strict;
no strict 'refs';

#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.mcgillsoftware.com (Shazam! Perl Library)
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub cgi_auto_checkboxes_from_cgi_to_csv {
  my ($cgi_hash_ref, $unique_id, $sorted_list) = @_;
  my ($build, @tmp);

  $unique_id = 'cb' . $unique_id;

  my (%new_data, $key, $uncleaned_key);
  foreach (keys %$cgi_hash_ref) {
    push(@tmp, $$cgi_hash_ref{$_}) if ($_ =~ m/^$unique_id/);
  }

  @tmp = sort(@tmp) if ($sorted_list ne 'false');
  foreach (@tmp) { $build .= $_ . ';' }

  chop($build) if ($build);
  return $build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# example: &shazam::cgi_checkboxes_from_csv_to_html($csv, $cb_params, @items);
#  $csv = 'Item 1;Item 2;Item 3';
#  $cb_params = 'class="" etc...';
#  @items = array of check boxes
#-----------------------------------------------------------------------------#
sub cgi_auto_checkboxes_from_csv_to_html {
  my ($csv, $cb_params, $unique_id, @items) = @_;
  my (@build, $underscored, @split, %csv_hash);

  $cb_params = ' ' . $cb_params if ($cb_params);

  @split = split(/;/, $csv);
  foreach (@split) { $csv_hash{$_} = ' checked'; }

  foreach (@items){
    $underscored = $_;
    $underscored =~ s/ /_/g;
    push(@build, qq|<input$cb_params type="checkbox" name="cb| .$unique_id . qq|_$underscored" value="$_"$csv_hash{$_}> $_|);
  }

  return @build;
}




# note- make this thing use a referenced hash!
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub cgi_checkboxes_from_cgi_to_csv {
  my (@items) = @_;
  my ($build, $underscored);

  foreach (@items) {
    $underscored = $_;
    $underscored =~ s/ /_/g;
    $build .= $_ . ';' if( $cgi::vars{"cb_$underscored"} );
  }
  chop($build) if ($build);
  return $build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# example: &shazam::cgi_checkboxes_from_csv_to_html($csv, $cb_params, @items);
#  $csv = 'Item 1;Item 2;Item 3';
#  $cb_params = 'class="" etc...';
#  @items = array of check boxes
#-----------------------------------------------------------------------------#
sub cgi_checkboxes_from_csv_to_html {
  my ($csv, $cb_params, @items) = @_;
  my (@build, $underscored, @split, %csv_hash);

  $cb_params = ' ' . $cb_params if ($cb_params);

  @split = split(/;/, $csv);
  foreach (@split) { $csv_hash{$_} = ' checked'; }

  foreach (@items){
    $underscored = $_;
    $underscored =~ s/ /_/g;
    push(@build, qq|<input$cb_params type="checkbox" name="cb_$underscored" value="$underscored"$csv_hash{$_}> $_|);
  }

  return @build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Date/Time Format for Header/Cookie
# This internal routine creates date strings suitable for use in
# cookies and HTTP headers.  (They differ, unfortunately.)
#-----------------------------------------------------------------------------#
sub cgi_datetime_format {

  my($time,$format) = @_;
  $format ||= 'http';

  my(@MON)=qw/Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec/;
  my(@WDAY) = qw/Sun Mon Tue Wed Thu Fri Sat/;

  # pass through preformatted dates for the sake of datetime_adjust_epoch_time()
  $time = &shazam::datetime_adjust_epoch_time($time);
  return $time unless $time =~ /^\d+$/;

  # make HTTP/cookie date string from GMT'ed time
  # (cookies use '-' as date separator, HTTP uses ' ')
  my($sc) = ' ';
  $sc = '-' if $format eq "cookie";
  my($sec,$min,$hour,$mday,$mon,$year,$wday) = gmtime($time);
  $year += 1900;
  return sprintf("%s, %02d$sc%s$sc%04d %02d:%02d:%02d GMT",
    $WDAY[$wday],$mday,$MON[$mon],$year,$hour,$min,$sec);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# $example = &shazam::cgi_determine_browser( $ENV{'HTTP_USER_AGENT'} );
# Returns: Netscape 1-7, Internet Explorer 3-7, Lynx, NCSA Mosaic, AOL,
# MacWeb, IBM WebExplorer
# Need to update
#-----------------------------------------------------------------------------#
sub cgi_determine_browser {

  my $env_user_agent = $_[0];

  return "Internet Explorer 3"   if $env_user_agent =~ /MSIE 3./i;        # Broweser is Internet Explorer 3
  return "Internet Explorer 4"   if $env_user_agent =~ /MSIE 4./i;        # Broweser is Internet Explorer 4
  return "Internet Explorer 5"   if $env_user_agent =~ /MSIE 5./i;        # Broweser is Internet Explorer 5
  return "Internet Explorer 6"   if $env_user_agent =~ /MSIE 6./i;        # Broweser is Internet Explorer 6
  return "Internet Explorer 7"   if $env_user_agent =~ /MSIE 7./i;        # Broweser is Internet Explorer 7
  return "Netscape 1"            if $env_user_agent =~ /Mozilla\/1./;     # Broweser is Netscape 1
  return "Netscape 2"            if $env_user_agent =~ /Mozilla\/2./;     # Broweser is Netscape 2
  return "Netscape 3"            if $env_user_agent =~ /Mozilla\/3./;     # Broweser is Netscape 3
  return "Netscape 4"            if $env_user_agent =~ /Mozilla\/4./;     # Broweser is Netscape 4
  return "Netscape 5"            if $env_user_agent =~ /Mozilla\/5./;     # Broweser is Netscape 5
  return "Netscape 6"            if $env_user_agent =~ /Mozilla\/6./;     # Broweser is Netscape 6
  return "Netscape 7"            if $env_user_agent =~ /Mozilla\/7./;     # Broweser is Netscape 7
  return "Lynx"                  if $env_user_agent =~ /Lynx/i;           # Broweser is Lynx
  return "NCSA Mosaic"           if $env_user_agent =~ /mosaic/;          # Broweser is NCSA Mosaic
  return "AOL"                   if $env_user_agent =~ /aol/i;            # Broweser is AOL's Browser
  return "MacWeb"                if $env_user_agent =~ /MacWeb/i;         # Broweser is MacWeb
  return "IBM WebExplorer"       if $env_user_agent =~ /WebExplorer/i;    # Broweser is IBM WebExplorer
  return '';
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub cgi_error{

  print "Content-type: text/html\n\n";
  print qq|

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
        <title>$_[0]</title>
</head>

<body bgcolor="#E2E2DC">
<p>&nbsp;</p>

<center><font size="+2" color="maroon"><b><blink>Critical Error in Shazam Library!</blink></b></font></center>
<center>
<table width="65%" border="3" bordercolor="black" cellpadding="15">
<tr>
        <td bgcolor="#DAD9B8">
    <b>$_[0]:</b>
    <br><br>
    $_[1]  <p>Please contact the system administrator and report this problem. If you could make a note of your browser, browser version, and what you were doing when this error occurred it will be helpful. We are sorry for any inconvenience this error may have caused you, and once we have been notified our engineers will look into it immediately.
    </td>
</tr>
</table>

</center>

</body>
</html>
|;
exit;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub cgi_get_cookie {

  my($cookie, $name, $value, %jar);

  foreach $cookie (split(/; /,$ENV{'HTTP_COOKIE'})) {           # for each cookie sent
    ($name,$value) = split(/=/,$cookie);                        # split into name/value
    foreach($name,$value) { $_ = &shazam::cgi_url_decode($_); }              # URL decode strings
    $jar{$name}=$value;                                         # and put into %jar hash
  }
  return %jar;                                                 # return %jar hash
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub cgi_get_data {

  my ($max_bytes) = @_; # Max input size in BYTES
  my($name, $value, $pair, @pairs, $buffer, %data);

  # Check input size if max input size is defined
  if ( $max_bytes && ($ENV{'CONTENT_LENGTH'} || length($ENV{'QUERY_STRING'}) ) > $max_bytes) {
    &shazam::cgi_error("Form Input Exceeds Max. Bytes Allowed", "[procgi_parse_form]: The data sent through the form exceeded the $max_bytes bytes allowed!");
  }

  # Read GET or POST form into $buffer
  if ($ENV{'REQUEST_METHOD'} eq 'POST') { 
    read( STDIN, $buffer, $ENV{'CONTENT_LENGTH'} );
  } 
  elsif ($ENV{'REQUEST_METHOD'} eq 'GET') {
    $buffer = $ENV{'QUERY_STRING'};
  }
  
  @pairs = split(/&/, $buffer);
  foreach $pair (@pairs) {
    ($name, $value) = split(/=/, $pair);
    $name =~ tr/+/ /;
    $value =~ tr/+/ /;
    $name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
    $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
    $data{$name} = $value;
  }
  return %data;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub cgi_print_array {

  print "Content-type: text/html\n\n";
  foreach (@_) { print $_ . "\n<br>"; }
  exit;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub cgi_print_hash {
 my ($hash_ref) = @_;
 print "Content-type: text/html\n\n";
 foreach (sort keys %$hash_ref) { print $_ . '=' . $$hash_ref{$_} . "\n<br>"; }
 exit;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub cgi_print_string {

 my $input = shift;

  print "Content-type: text/html\n\n";
  print $input;
  exit;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Grabs cgi keys from existing hash and returns a new formatted and ready to
# save hash.
#
# frm_key = Unmanipulated data as it exists
# trm_key = Trim the value
# cur_key = Format value as currency
#
#-----------------------------------------------------------------------------#
sub cgi_process_get_post_data {
  my ($hash_ref) = @_;
  my (%new_data, $key, $uncleaned_key);

  foreach (keys %$hash_ref) {
    if ($_ =~ m/^frm_/) {
      $key = $_;
      $key =~ s/frm_//;
      $uncleaned_key = $key;
      $key =~ s/_/ /g;
      $new_data{$key} = $$hash_ref{$_};
      $$hash_ref{$uncleaned_key} = $new_data{$key};
    }

    if ($_ =~ m/^trm_/) {
      $key = $_;
      $key =~ s/trm_//;
      $uncleaned_key = $key;
      $key =~ s/_/ /g;
      $new_data{$key} = &shazam::string_trim_ws($$hash_ref{$_});
      $$hash_ref{$uncleaned_key} = $new_data{$key};
    }

    if ($_ =~ m/^num_/) {
      $key = $_;
      $key =~ s/num_//;
      $uncleaned_key = $key;
      $key =~ s/_/ /g;
      $new_data{$key} = &shazam::string_strip_non_numeric('true', $$hash_ref{$_});
      $$hash_ref{$uncleaned_key} = $new_data{$key};
    }

    if ($_ =~ m/^cur_/) {
      $key = $_;
      $key =~ s/cur_//;
      $uncleaned_key = $key;
      $key =~ s/_/ /g;
      $new_data{$key} = &shazam::finance_format_money(&shazam::string_trim_ws($$hash_ref{$_}));
      $$hash_ref{$uncleaned_key} = $new_data{$key};
    }
  }

  return %new_data;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Cookie : Perl routines for setting/reading browser cookies.
#-----------------------------------------------------------------------------#
  # $name       - cookie name (ie: username)
  # $value      - cookie value (ie: "joe user")
  # $exp        - exp date, cookie will be deleted at this date.
              # Format: Wdy, DD-Mon-YYYY HH:MM:SS GMT
              # "now" -- expire immediately
              # "+180s" -- in 180 seconds
              # "+2m" -- in 2 minutes
              # "+12h" -- in 12 hours
              # "+1d"  -- in 1 day
              # "+3M"  -- in 3 months
              # "+2y"  -- in 2 years
              # "-3m"  -- 3 minutes ago(!)
              # If you don't supply one of these forms, we assume you are
              # specifying the date yourself

  # $path       - Cookie is sent only when this path is accessed   (ie: /);
  # $domain     - Cookie is sent only when this domain is accessed (ie: .edis.org)
  # $secure     - Cookie is sent only with secure https connection

# &shazam::cgi_set_cookie("name", "value", "+5h");
#-----------------------------------------------------------------------------#
sub cgi_set_cookie {
  my($name, $value, $expires, $path, $domain, $secure) = @_;
  my($cookie_info, $exp);
  my $default_domain = $ENV{'SERVER_NAME'};

  # Calculate and Format the Expiration
  $exp = &shazam::cgi_datetime_format( &shazam::datetime_adjust_epoch_time($expires), "cookie");

  unless (defined $name) { die("SetCookie : Cookie name must be specified\n"); }
  if ($exp && $exp !~ /^[A-Z]{3}, \d\d-[A-Z]{3}-\d{4} \d\d:\d\d:\d\d GMT$/i) { die("SetCookie : Exp Dat format isn't: Wdy, DD-Mon-YYYY HH:MM:SS GMT\n"); }

  if ($name)            { $name  = &shazam::cgi_url_encode($name); }
  if ($value)           { $value = &shazam::cgi_url_encode($value); }
  if ($exp)             { $cookie_info .= "expires=$exp; "; }      else {};
  if ($path)            { $cookie_info .= "path=$path; "; }        else { $cookie_info .= "path=/; "; };
  if ($domain)          { $cookie_info .= "domain=$domain; "; }    else { $cookie_info .= "domain=$default_domain; "; };
  if ($secure)          { $cookie_info .= "secure; "; }

  return "Set-Cookie: $name=$value; $cookie_info\n";
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub cgi_get_cookies {
 my %cookies = (); # initialize to empty list
 my @cookie_split = split(/; /, $ENV{'HTTP_COOKIE'});

 foreach (@cookie_split){
   my($name, $value) = split(/=/, $_);
   $cookies{$name} = $value;
 } 
 return %cookies; 
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub cgi_url_decode {
  shift() if ref($_[0]);
  my $todecode = shift;
  return undef unless defined($todecode);
  $todecode =~ tr/+/ /;  # pluses become spaces
  $todecode =~ s/%([0-9a-fA-F]{2})/pack("c",hex($1))/ge;
  return $todecode;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub cgi_url_encode {
  my $toencode = shift;
  return undef unless defined($toencode);
  $toencode=~s/([^a-zA-Z0-9_.-])/uc sprintf("%%%02x",ord($1))/eg;
  $toencode=~s/\%20/\+/g; # spaces become pluses
  return $toencode;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Warn Only (Passive)
# req            Required Field
# alpha          Text Only
# num            Numeric Only
# alphanum       Must contain both Alpha & Num
# low25          Lowest 25
# high120        Highest 120
# phone          phone number
# zip            zip code
# email          Valid Email
# visa?
# ssn
# ip


# Actions (Active)
# trim           Trim Whitespace
# lc             Lower Case
# uc             Upper Case
# tc             Title Case
# sc             Sentence Case
# striphtml      Strip All Html
#
#
#  $cgi_hash_ref       This is your CGI Hash
#  $return             What to return? (Leave blank)
#  $pre_warning        What to place before individual warning Placements
#  $warning_marker     Markers to indicate items that need attention (<+zf__title_mark+>)
#  $bulk_warn_header
#  $bulk_warn_footer
#  $form               The Form to be checked
#
#-----------------------------------------------------------------------------#
sub cgi_zform_intelligent_cgi_post_processor_two {
  my ($cgi_hash_ref, $return, $pre_warning, $warning_marker, $bulk_warn_header, $bulk_warn_footer, $confirm_template, $collected_template, $form) = @_;
  my (%new_data, %instructions, %messages, %warnings, %form_data, $key,
      $uncleaned_key, $cleaned_key, $instruct, $title, $msg, %titles, %bulk_warnings);

  # Checkbox Parser and maintainer
   my ($cbs_current_box, @cbs_split_group_from_items, $cbs_group, @cbs_items,
       $cbs_cleaned_group, $cbs_inc, $cbs_current_item, $cbs_checked, $cbs_build_cb,
       @cbs_checkboxes_build_array,$cbs_final_group_production, $cbs_cols, $cbs_td_width,
       $cbs_current_item_name, $cbs_group_no_sort_numbers);

   while ($form =~ s,\[checkboxes(\d) (.*?)\],83jshs4403kdsue83jdd983ks9,si){
     $cbs_cols = $1;
     $cbs_current_box = $2;
     $cbs_current_box =~ s/\n//g;

     $cbs_cols = 6 if ($cbs_cols > 6);

     @cbs_split_group_from_items = split(/:/, $cbs_current_box);
     $cbs_group = &shazam::string_trim_ws($cbs_split_group_from_items[0]);
     @cbs_items = split(/,/, $cbs_split_group_from_items[1]);

    # $titles{$cleaned_key}

     $cbs_cleaned_group = lc($cbs_group);
     $cbs_cleaned_group =~ s/ /_/g;

     $cbs_inc = 0;
     $cbs_build_cb = '';
     @cbs_checkboxes_build_array = ();

     foreach (@cbs_items){
       $cbs_current_item = &shazam::string_trim_ws($_);
       $cbs_current_item_name = 'zf__' . $cbs_cleaned_group . '_cb' . $cbs_inc;

       $cbs_checked = '';
       $cbs_checked = ' checked' if ($$cgi_hash_ref{"$cbs_current_item_name"} ne '');

       $cbs_build_cb = qq|<input type="checkbox" name="$cbs_current_item_name" value="$cbs_current_item"$cbs_checked> $cbs_current_item|;
       push(@cbs_checkboxes_build_array, $cbs_build_cb);

       # If this form is being posted and not just constructed
       if ($$cgi_hash_ref{'zf__general_form_processor'} eq 'run') {
         $$cgi_hash_ref{"zf__$cbs_cleaned_group"} = $$cgi_hash_ref{"zf__$cbs_cleaned_group"} . ', ' if ($$cgi_hash_ref{"zf__$cbs_cleaned_group"} ne '' && $$cgi_hash_ref{$cbs_current_item_name} ne '');
         $$cgi_hash_ref{"zf__$cbs_cleaned_group"} = $$cgi_hash_ref{"zf__$cbs_cleaned_group"} . $cbs_current_item if ($$cgi_hash_ref{$cbs_current_item_name} ne '');
         $cbs_group_no_sort_numbers = substr($cbs_group, 4);
         $titles{"zf__$cbs_cleaned_group"} = $cbs_group_no_sort_numbers;
         delete($$cgi_hash_ref{"$cbs_current_item_name"});
       }

       $cbs_inc++;
     }


     $cbs_td_width = '100%' if ($cbs_cols == 1);
     $cbs_td_width = '50%' if ($cbs_cols == 2);
     $cbs_td_width = '33%' if ($cbs_cols == 3);
     $cbs_td_width = '25%' if ($cbs_cols == 4);
     $cbs_td_width = '20%' if ($cbs_cols == 5);
     $cbs_td_width = '16%' if ($cbs_cols == 6);

     $cbs_final_group_production = &shazam::html_build_table($cbs_cols, 'cellpadding="10" border="0"', '', "width=$cbs_td_width nowrap", @cbs_checkboxes_build_array);
     $form =~ s/83jshs4403kdsue83jdd983ks9/$cbs_final_group_production/;
   }







  # First process the instrucstions and the messages
  foreach (keys %$cgi_hash_ref) {
    if ($_ =~ m/^zf__zinst_/) {
      ($title, $instruct, $msg) = split(/::/, $$cgi_hash_ref{$_});
      $uncleaned_key = $_;
      $cleaned_key = $uncleaned_key;
      $cleaned_key =~ s/zf__zinst_//;
      $cleaned_key = 'zf__' . $cleaned_key;

      $instructions{$cleaned_key} = $instruct;
      $messages{$cleaned_key} = $msg;
      $titles{$cleaned_key} = $title;

      #$bulk_messages($cleaned_key) = "$title|$msg";

      delete($$cgi_hash_ref{$_});
    }

  }

  # Next process the actual data
  foreach (keys %$cgi_hash_ref) {
    if ($_ =~ m/^zf__/) {
      $uncleaned_key = $_;
      $cleaned_key = $uncleaned_key;
      $cleaned_key =~ s/zf__//;
      $cleaned_key = 'zf__' . $cleaned_key;
      $form_data{$cleaned_key} = $$cgi_hash_ref{$_};
    }
  }


  # Now do tests on retrieved data in the %form_data hash to see
  # if the data complies to passive instructions (if any) and to
  # apply any Active instructions (if any)
  my($current_object, $inst, %inst_hash, @split_inst);
  foreach (keys %instructions){
    $current_object = $_;
    @split_inst = split(/\|/, $instructions{$current_object});
    foreach $inst (@split_inst){ $inst_hash{$inst} = ''; }

    if (1 < 2){
   # if (exists($form_data{$current_object})){
    #  &shazam::cgi_print_hash(\%inst_hash);

      #First take care of Actions
      foreach $inst (@split_inst){
        if ($inst eq 'lc') { $form_data{$current_object} = lc($form_data{$current_object}); delete($inst_hash{$inst});} # Lower Case
        if ($inst eq 'uc') { $form_data{$current_object} = uc($form_data{$current_object}); delete($inst_hash{$inst});} # Upper Case
      }


      # Next see if it is required and check complience
      if (exists($inst_hash{'req'})){
        if ($form_data{$current_object} eq '' || !exists($form_data{$current_object})){
          $warnings{$current_object} = 'This is a required field. Please complete this field and resubmit your form.';
          $warnings{$current_object} = $messages{$current_object} if (exists($messages{$current_object}) && $messages{$current_object} ne '');
          $bulk_warnings{$titles{$current_object}} = $warnings{$current_object};
        }
        delete($inst_hash{'req'});
      }


      # Now Remaining elements in %inst_hash should be ckecked for
      # complience and warnings ONLY IF A WARNING DOES NOT ALREADY
      # EXIST FOR IT. Once a warning exists then stop testing because we
      # only give the user one warning at a time per field.
      my ($current_inst_key, $test_data);
      foreach (keys %inst_hash){
        $current_inst_key = $_;
        $test_data = $form_data{$current_object};


        # &shazam::cgi_print($test_data);

        if (!exists($warnings{$current_object})){
        ###############################################

          # numeric only
          if (($current_inst_key eq 'num') && ($test_data =~ /.*\D/g)) {
            $warnings{$current_object} = 'This field requires a NUMERIC only response. NUMERIC only would be 0-9 characters only.';
            $bulk_warnings{$titles{$current_object}} = $warnings{$current_object};
          }

          # email only
          if (($current_inst_key eq 'email') && ($test_data ne '' && &shazam::string_is_valid_email_address($test_data) ne 'true')) {
            $warnings{$current_object} = 'This field requires a valid email address. The address you have entered does not seem to conform to the RFC 822 standards. It is suspected that this may not be a valid E-mail address. Please try again.';
            $bulk_warnings{$titles{$current_object}} = $warnings{$current_object};
          }



        ###############################################
        }

      }




    }
    %inst_hash = ();
  }




  delete($form_data{'zf__general_form_processor'});



  # Build Bulk Warnnings
  my $bulk;
  foreach (sort keys %bulk_warnings){ $bulk .= "<li><b>$_</b><br>" . $bulk_warnings{$_} . "<br><br>\n"; }
  $bulk = $bulk_warn_header . "\n<ol>\n" . $bulk . "</ol>\n" . $bulk_warn_footer . "\n" if ($bulk ne '');


  # Insert any and all warnings
  my($nkey, $nvalue, $nraw);
  foreach (keys %warnings){
    $nkey = '<+' . $_ . '_help+>';
    $nkey = quotemeta($nkey);
    $nvalue = $pre_warning . $warnings{$_};
    $form =~ s/$nkey/$nvalue/g;
  }


  # Insert any Warning Notice Markers
  foreach (keys %warnings){
    $nkey = '<+' . $_ . '_mark+>';
    $nkey = quotemeta($nkey);
    $nvalue = $warning_marker;
    $form =~ s/$nkey/$nvalue/g;
  }


  # Replace all insert form value tags
  foreach (keys %form_data){
    $nraw = $_;
    $nkey = '<+' . $_ . '+>';
    $nkey = quotemeta($nkey);
    $nvalue = &shazam::html_escape_html($form_data{$nraw});
    $form =~ s/$nkey/$nvalue/g;
    $confirm_template =~ s/$nkey/$nvalue/g;
    $collected_template =~ s/$nkey/$nvalue/g;
  }

  # Stuff the origional cgi hash with keys and values
  # without sort number prefix
  my($key, $cleaned_key);
  foreach (keys %form_data){
    $key = substr($_, 8);
    $key =~ s/_/ /g;
    $key = 'zf ' . $key;
    $$cgi_hash_ref{$key} = $form_data{$_};
  }





  # Build Confirmation Stuff
  my $default_collected_data = "\n\n";
  foreach (sort keys %form_data){
    $default_collected_data .=  '[' . uc($titles{$_}) . "]\n" . $form_data{$_} . "\n\n\n" if ($form_data{$_} ne '');
  }

  # Enforce select box State
  my %select_box_hash = &shazam::html_get_select_boxes_selected_options($form);
  foreach (keys %select_box_hash) { $select_box_hash{$_} = $$cgi_hash_ref{$_} if (exists($$cgi_hash_ref{$_})); }
  $form = &shazam::html_reset_select_boxes_with_selected_options_from_hash($form, %select_box_hash);


  # remove any leftover zf tags such as warning insert tags not used
  $form =~ s/<\+zf__[^+>]*\+>//gs;

  # Do bulk warning placement
  $form =~ s/<\+bulk warnings\+>/$bulk/gs;


  my $approved = 'false';
  $approved = 'true' if ($bulk eq '' && $$cgi_hash_ref{'zf__general_form_processor'} eq 'run');


#  &shazam::cgi_print('<pre>'. $default_collected_data . '</pre>');


  return ($approved, $form, $confirm_template, $collected_template, $default_collected_data);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub data_file_ext_definitions {

  my %file_ext_definitions = (
  'ACE' => 'ACE Archiver File',
  'AIF' => 'Audio Interchange File',
  'ANI' => 'Animated Cursor',
  'API' => 'Application Program Interface',
  'ART' => 'Clipart File',
  'ASC' => 'ASCII Text File',
  'ASM' => 'Assembler Code',
  'ASP' => 'Active Server Page',
  'AVI' => 'Audio/Video Interleaved Movie',
  'BAK' => 'Backup Files',
  'BAS' => 'BASIC Source Code',
  'BAT' => 'DOS Batch File',
  'BFC' => 'Briefcase Document',
  'BIN' => 'Binary File',
  'BMP' => 'Bitmap Image',
  'BUD' => 'Quicken Backup',
  'BZ2' => 'Bzip2 Archive',
  'C' => 'C Source Code',
  'CAT' => 'Security Catalog File',
  'CBL' => 'Cobol Source Code',
  'CBT' => 'Computer Based Training File',
  'CDA' => 'Compact Disc Audio',
  'CDT' => 'Corel Draw Template',
  'CFML' => 'ColdFusion Markup Language File',
  'CGI' => 'Common Gateway Interface',
  'CHM' => 'Compiled HTML Help',
  'CLP' => 'Windows Clipboard File',
  'CMD' => 'DOS Command File',
  'COM' => 'Command Executable',
  'CPL' => 'Control Panel Applet',
  'CPP' => 'C++ Source Code',
  'CSS' => 'Cascading Style Sheet',
  'CSV' => 'Comma Separated Value File',
  'CMF' => 'Corel Metafile',
  'CUR' => 'Cursor File',
  'DAO' => 'Registry Backup File',
  'DAT' => 'Data File',
  'DD' => 'DiskDoubler Archive',
  'DEB' => 'Debian Package',
  'DEV' => 'Device Driver',
  'DIC' => 'Dictionary File',
  'DIR' => 'Macromedia Director File',
  'DLL' => 'Dynamic Linked Library',
  'DOC' => 'Word Document',
  'DOT' => 'Word Template',
  'DRV' => 'Device Driver',
  'DS' => 'TWAIN Data Source File',
  'DUN' => 'Dial-Up Networking File',
  'DWG' => 'AutoCAD Drawing',
  'DXF' => 'AutoCAD Exchange Format',
  'EMF' => 'Enhanced Metafile',
  'EML' => 'E-Mail Message',
  'EPS' => 'Encapsulated PostScript',
  'EPS2' => 'Encapsulated Postscript',
  'EXE' => 'Executable File',
  'FAX' => 'Fax Document',
  'FFL' => 'Microsoft Fast Find File',
  'FFO' => 'Microsoft Fast Find File',
  'FLA' => 'Macromedia Flash Movie',
  'FNT' => 'Font File',
  'GIF' => 'GIF Image',
  'GID' => 'Global Index File',
  'GRP' => 'Windows Program Manager Group',
  'GZ' => 'GZip Archive',
  'HEX' => 'Hexadecimal Data',
  'HLP' => 'Help File',
  'HT' => 'HyperTerminal File',
  'HQX' => 'Hexadeecimal Data',
  'HTM' => 'HTML Document',
  'HTML' => 'HTML Document',
  'ICL' => 'Icon Library',
  'ICM' => 'Image Color Matching File',
  'ICO' => 'Icon Image',
  'INF' => 'Information File',
  'INI' => 'Initialization File',
  'JAR' => 'Java Archive',
  'JPEG' => 'JPEG Image',
  'JPG' => 'JPEG Image',
  'JS' => 'JavaScript Source Code',
  'KDB' => 'KeyDB Database',
  'LAB' => 'Excel Mailing Label Document',
  'LIT' => 'Reader eBook Document',
  'LNK' => 'Shortcut File',
  'LOG' => 'Log File',
  'LSP' => 'LISP Source Code',
  'MAQ' => 'Access Database Query',
  'MAR' => 'Access Database Report',
  'MDB' => 'Access Database',
  'MDL' => 'Rose Model File',
  'MID' => 'MIDI Song',
  'MOV' => 'QuickTime Movie',
  'MP3' => 'MPEG Audio File',
  'MPEG' => 'MPEG Movie',
  'MPP' => 'Microsoft Project File',
  'MSG' => 'Message File',
  'NCF' => 'Netware Command File',
  'NLM' => 'Netware Loadable Module',
  'O' => 'Object File',
  'OCX' => 'ActiveX Control',
  'OGG' => 'Ogg Vorbis Audio File',
  'OST' => 'Outlook Offline File',
  'PAK' => 'iD Archive',
  'PCL' => 'Printer Control Language File',
  'PICT' => 'QuickDraw Image',
  'PCX' => 'Paintbrush Image',
  'PDF' => 'Portable Document File',
  'PDR' => 'Port Driver',
  'PHP' => 'PHP Source Code',
  'PIF' => 'Program Information File',
  'PL' => 'Perl Source Code',
  'PM' => 'Perl Module',
  'PM3' => 'PageMaker 3 Document',
  'PM4' => 'PageMaker 4 Document',
  'PM5' => 'PageMaker 5 Document',
  'PM6' => 'PageMaker 6 Document',
  'PNG' => 'Portable Network Graphic',
  'POL' => 'Policy File',
  'POT' => 'PowerPoint Template',
  'PPD' => 'PostScript Printer Description',
  'PPS' => 'PowerPoint Presentation',
  'PPT' => 'PowerPoint Presentation',
  'PRN' => 'Raw Printer Data File',
  'PS' => 'PostScript Document',
  'PSD' => 'Photoshop Image',
  'PSP' => 'Paint Shop Pro Image',
  'PST' => 'Personal Folder File',
  'PUB' => 'Publisher Document',
  'PWL' => 'Password List',
  'QIF' => 'Quicken Import File',
  'RAM' => 'RealAudio Metafile',
  'RAR' => 'RAR Archive',
  'RAW' => 'Raw File Format',
  'RDO' => 'Raster Document Object',
  'REG' => 'Registry File',
  'RM' => 'RealMedia File',
  'RPM' => 'RedHat Package',
  'RSC' => 'Resource File',
  'RTF' => 'Rich Text Document',
  'SCR' => 'Screen Saver',
  'SEA' => 'Self-Extracting Stuffit Archive',
  'SH' => 'Shell Script',
  'SHTML' => 'SSI HTML Document',
  'SIT' => 'Stuffit Archive',
  'SMD' => 'SEGA Mega Drive ROM File',
  'SVG' => 'Scalable Vector Graphic',
  'SWF' => 'Shockwave Flash Document',
  'SWP' => 'Swap file',
  'SYS' => 'System File',
  'TAR' => 'TAR Archive',
  'TEXT' => 'Text Document',
  'TGA' => 'Targa Bitmap Image',
  'TIF' => 'Tagged Image File Format',
  'TIFF' => 'Tagged Image File Format',
  'TMP' => 'Temporary File',
  'TTF' => 'True Type Font',
  'TXT' => 'Text Document',
  'UDF' => 'Uniqueness Definition File',
  'UUE' => 'UU-Encoded File',
  'VBX' => 'Visual Basic Extension',
  'VM' => 'Virtual Memory File',
  'VXD' => 'Virtual Device Driver',
  'WAV' => 'Waveform Audio File',
  'WMF' => 'Windows Metafile Image',
  'WRI' => 'Write Document',
  'WSZ' => 'Winamp Skin',
  'XCF' => 'GIMP Image',
  'XIF' => 'Xerox Image File',
  'XLS' => 'Excel Spreadsheet',
  'XLT' => 'Excel Template',
  'XML' => 'eXtensible Markup Language',
  'XSL' => 'XML Style Sheet',
  'ZIP' => 'Zip Archive'
  );
  return %file_ext_definitions;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Html Code Hash
#-----------------------------------------------------------------------------#
sub data_html_code_hash {

  my %html_codes = (
  '�'   =>      '&Ccedil;',        '�'  =>      '&uuml;',        '�'    =>      '&egrave;',
  '�'   =>      '&circ;',          '�'  =>      '&auml;',        '�'    =>      '&agrave;',
  '�'   =>      '&aring;',         '�'  =>      '&ccedil;',      '�'    =>      '&ecirc;',
  '�'   =>      '&euml;',          '�'  =>      '&egrave;',      '�'    =>      '&iuml;',
  '�'   =>      '&icirc;',         '�'  =>      '&igrave;',      '�'    =>      '&Auml;',
  '�'   =>      '&Aring;',         '�'  =>      '&Egrave;',      '�'    =>      '&aelig;',
  '�'   =>      '&AElig;',         '�'  =>      '&ocirc;',       '�'    =>      '&ograve;',
  '�'   =>      '&ouml;',          '�'  =>      '&ugrave;',      '�'    =>      '&yuml;',
  '�'   =>      '&Ouml;',          '�'  =>      '&Uuml;',        '�'    =>      '&oslash;',
  '�'   =>      '&Oslash;',        '�'  =>      '&aacute;',      '�'    =>      '&iacute;',
  '�'   =>      '&oacute;',        '�'  =>      '&uacute;',      '�'    =>      '&ntilde;',
  '�'   =>      '&Ntilde;',        '�'  =>      '&Aacute;',      '�'    =>      '&Acirc;',
  '�'   =>      '&Agrave;',        '�'  =>      '&atilde;',      '�'    =>      '&Atilde;',
  '�'   =>      '&eth;',           '�'  =>      '&ETH;',         '�'    =>      '&Ecirc;',
  '�'   =>      '&Euml;',          '�'  =>      '&Egrave;',      '�'    =>      '&Iacute;',
  '�'   =>      '&Icirc;',         '�'  =>      '&Iuml;',        '�'    =>      '&Igrave;',
  '�'   =>      '&Oacute;',        '�'  =>      '&szlig;',       '�'    =>      '&Ocirc;',
  '�'   =>      '&Oacute;',        '�'  =>      '&otilde;',      '�'    =>      '&Otilde;',
  '�'   =>      '&thorn;',         '�'  =>      '&THORN;',       '�'    =>      '&Uacute;',
  '�'   =>      '&Ucirc;',         '�'  =>      '&Ugrave;',      '�'    =>      '&yacute;');

  return %html_codes;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub data_states_hash {

  my %states = (
    AL => 'Alabama', AK => 'Alaska', AZ => 'Arizona',
    AR => 'Arkansas', CA => 'California', CO => 'Colorado',
    CT => 'Connecticut', DE => 'Delaware', FL => 'Florida',
    GA => 'Georgia', HI => 'Hawaii', ID => 'Idaho',
    IL => 'Illinois', IN => 'Indiana', IA => 'Iowa',
    KS => 'Kansas', KY => 'Kentucky',
    LA => 'Louisiana', ME => 'Maine', MD => 'Maryland',
    MA => 'Massachusetts', MI => 'Michigan', MN => 'Minnesota',
    MS => 'Mississippi', MO => 'Missouri', MT => 'Montana',
    NE => 'Nebraska', NJ => 'New Jersey', NH => 'New Hampshire',
    NV => 'Nevada', NM => 'New Mexico', NY => 'New York',
    NC => 'North Carolina', ND => 'North Dakota', OH => 'Ohio',
    OK => 'Oklahoma', OR => 'Oregon', PA => 'Pennsylvania',
    RI => 'Rhode Island', SC => 'South Carolina',
    SD => 'South Dakota', TN => 'Tennessee', TX => 'Texas',
    UT => 'Utah', VT => 'Vermont', VA => 'Virginia',
    WA => 'Washington', WV => 'West Virginia', WI => 'Wisconsin',
    WY => 'Wyoming', AS => 'American Samoa', DC => 'District Of Columbia',
    GU => 'Guam', NI => 'Northern Mariana Islands', PR => 'Puerto Rico',
    VI => 'Virgin Islands');

    return %states;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Date/Time Calculator
# This internal routine creates an expires time exactly some number of
# hours from the current time.
# format for time can be in any of the forms...
# "now" -- expire immediately
# "+180s" -- in 180 seconds
# "+2m" -- in 2 minutes
# "+12h" -- in 12 hours
# "+1d"  -- in 1 day
# "+3M"  -- in 3 months
# "+2y"  -- in 2 years
# "-3m"  -- 3 minutes ago(!)
#-----------------------------------------------------------------------------#
sub datetime_adjust_epoch_time {

  my($adjust_by, $epoch_time) = @_;

  $epoch_time = time if ($epoch_time eq '');

  my(%mult) = (
  's'=>1, 'm'=>60, 'h'=>60*60, 'd'=>60*60*24, 'M'=>60*60*24*30, 'y'=>60*60*24*365);
  # If you don't supply one of these forms, we assume you are
  # specifying the date yourself
  my($offset);
  if (!$adjust_by || (lc($adjust_by) eq 'now')) {
    $adjust_by = 0;
  } elsif ($adjust_by=~/^\d+/) {
    return $adjust_by;
  } elsif ($adjust_by=~/^([+-]?(?:\d+|\d*\.\d*))([mhdMy]?)/) {
    $offset = ($mult{$2} || 1)*$1;
  } else {
    return $adjust_by;
  }
  return ($epoch_time + $offset);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Returns string greeting Good morning, Good afternoon, Good evening according
# to the server based time of the day.
#-----------------------------------------------------------------------------#
sub datetime_get_greeting {
  my @time = split /[\s:]/, localtime;
  return "Good morning" if ($time[3] < 12 );
  return "Good afternoon" if ($time[3] > 12 && $time[3] < 18 );
  return "Good evening" if ($time[3] >= 18 );
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# eg. print &shazam::datetime_get_number_of_days_in_given_year_and_month($month, $year);
#-----------------------------------------------------------------------------#
sub datetime_get_number_of_days_in_given_year_and_month {
  my ($month, $year) = @_;
  my ($next_year, $next_month, $days);

  use Time::Local;

  if ($month <= 12 or $month >= 1){
    $next_year = ($month == 12) ? $year + 1 : $year;
    $next_month = timelocal(0, 0, 0, 1, $month % 12, $next_year);
    $days = (localtime($next_month - 86_400))[3];
    return $days;
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Returns morning, afternoon, or evening according
# to the server based time of the day.
#-----------------------------------------------------------------------------#
sub datetime_part_of_day {
  my @time = split /[\s:]/, localtime;
  return "morning" if ($time[3] < 12 );
  return "afternoon" if ($time[3] > 12 && $time[3] < 18 );
  return "evening" if ($time[3] >= 18 );
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Day of week starts with Sunday or 0
# return options: normal abreviation, force three abreviation, full word,
#                 number, number padded
#
# eg. print &shazam::datetime::return_day_of_week_for_date($month, $day, $year, 'number');
#
#-----------------------------------------------------------------------------#
sub datetime_return_day_of_week_for_given_date {
  my ($month, $day, $year, $return_as) = @_;
  my ($num_of_day);

  $year-- if $month < 3;
  $num_of_day = ($year+int($year/4)-int($year/100)+int($year/400)+((0,3,2,5,0,3,5,1,4,6,2,4)[$month-1])+$day) % 7;
  return (('Sun','Mon','Tues','Wed','Thurs','Fri','Sat')[$num_of_day]) if ($return_as eq 'normal abreviation');
  return (('Sun','Mon','Tue','Wed','Thu','Fri','Sat')[$num_of_day]) if ($return_as eq 'force three abreviation');
  return (('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday')[$num_of_day]) if ($return_as eq 'full word');
  return $num_of_day if ($return_as eq 'number');
  return '0' . $num_of_day if ($return_as eq 'number padded');
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Date/Time Calculator
#
# $foo = &shazam::datetime_return_formatted_datetime_info('1', '+1d');
#
# Return Options Dates
#   '01'     February 5, 2001
#   '02'     02/05/2001
#   '03'     02/05/01
#   '04'     02-05-2001
#   '05'     02-05-01
#   '06'     Monday, February 5, 2001
#   '07'     Array (02/04/2001, 02/05/2001, 02/06/2001) (Yesterday, Today, Tomorrow)
#   '08'     Array ($full_month_name, $month_num, $day_num, $four_digit_year, $day_name,
#                   $full_month_name_yest, $month_num_yest, $day_num_yest, $four_digit_year_yest, $day_name_yest,
#                   $full_month_name_next, $month_num_next, $day_num_next, $four_digit_year_next, $day_name_next)
#
#
# Return Options Times
#   '30'     11:34:01 AM
#
#
# Return Options Dates & Time
#   '50'     2001-02-28-23-34-01      Good for sorting
#   '51'     20010228233401           Good for sorting
#   '52'     2001/02/28 23:34:01      Good for sorting
#
#
# Offset Format
#   "now" -- expire immediately
#   "+180s" -- in 180 seconds
#   "+2m" -- in 2 minutes
#   "+12h" -- in 12 hours
#   "+1d"  -- in 1 day
#   "+3M"  -- in 3 months
#   "+2y"  -- in 2 years
#   "-3m"  -- 3 minutes ago(!)
#-----------------------------------------------------------------------------#
sub datetime_return_formatted_datetime_info {
  my($return_option, $offset_by) = @_;
  my ($offset, $new_time_with_offset, $previous_day_with_offset, $next_day_with_offset);

  $new_time_with_offset = &shazam::datetime_adjust_epoch_time($offset_by, time);
  $previous_day_with_offset = &shazam::datetime_adjust_epoch_time('-1d', $new_time_with_offset);
  $next_day_with_offset = &shazam::datetime_adjust_epoch_time('+1d', $new_time_with_offset);

  #  $sec   Seconds after each minute (0 - 59)
  #  $min   Minutes after each hour (0 - 59)
  #  $hour  Hour since midnight (0 - 23)
  #  $mday  Numeric day of the month (1 - 31)
  #  $mon   Number of months since January (0 - 11)
  #  $year  Number of years since 1900
  #  $wday  Number of days since Sunday (0 - 6)
  #  $yday  Number of days since January 1 (0 - 365)
  #  $isdl  A flag for daylight savings time

  # Build New Date and Time Vars
  my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdl) = localtime($new_time_with_offset);
  my ($psec, $pmin, $phour, $pmday, $pmon, $pyear, $pwday, $pyday, $pisdl) = localtime($previous_day_with_offset);
  my ($nsec, $nmin, $nhour, $nmday, $nmon, $nyear, $nwday, $nyday, $nisdl) = localtime($next_day_with_offset);

  # Four Digit Year Stuff
  my $four_digit_year = $year; $four_digit_year += 1900;
  my $four_digit_year_previous = $pyear; $four_digit_year_previous += 1900;
  my $four_digit_year_next = $nyear; $four_digit_year_next += 1900;

  my $two_digit_year = substr($four_digit_year, 2, 2);
  my $two_digit_year_previous = substr($four_digit_year_previous, 2, 2);
  my $two_digit_year_next = substr($four_digit_year_next, 2, 2);

  my $AM_PM;
  if ($hour >= 12) {
    $AM_PM = 'PM';
  } else {
    $AM_PM = 'AM';
  }

  my(@full_month) = qw/January February March April May June July August September October November December/;
  my(@three_month) = qw/Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec/;
  my(@full_day) = qw/Sunday Monday Tuesday Wednesday Thursday Friday Saturday/;
  my(@three_day) = qw/Sun Mon Tue Wed Thu Fri Sat/;
  my(@num_hour) = qw/12 1 2 3 4 5 6 7 8 9 10 11 12 1 2 3 4 5 6 7 8 9 10 11/;
  my(@mil_hour) = qw/00 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23/;

  my $sec_padded = sprintf("%02s", $sec);
  my $min_padded = sprintf("%02s", $min);

  my $num_hour = $num_hour[$hour];
  my $num_hour_padded = sprintf("%02s", $num_hour);


  # Month Calculations
  my $full_month = $full_month[$mon];
  my $num_month = ($mon + 1);
  my $num_month_padded = sprintf("%02s", ($mon + 1));

  my $full_month_previous = $full_month[$pmon];
  my $num_month_previous = ($pmon + 1);
  my $num_month_padded_previous = sprintf("%02s", ($pmon + 1));

  my $full_month_next = $full_month[$nmon];
  my $num_month_next = ($nmon + 1);
  my $num_month_padded_next = sprintf("%02s", ($nmon + 1));


  # Day Calculations
  my $num_day = $mday;
  my $num_day_padded = sprintf("%02s", $mday);

  my $num_day_previous = $pmday;
  my $num_day_padded_previous = sprintf("%02s", $pmday);

  my $num_day_next = $nmday;
  my $num_day_padded_next = sprintf("%02s", $nmday);


  # Return Options Dates
  return "$full_month[$mon] $mday, $four_digit_year" if ($return_option eq '01');
  return "$num_month_padded/$num_day_padded/$four_digit_year" if ($return_option eq '02');
  return "$num_month_padded/$num_day_padded/$two_digit_year" if ($return_option eq '03');
  return "$num_month_padded-$num_day_padded-$four_digit_year" if ($return_option eq '04');
  return "$num_month_padded-$num_day_padded-$two_digit_year" if ($return_option eq '05');
  return "$full_day[$wday], $full_month[$mon] $mday, $four_digit_year" if ($return_option eq '06');
  return ("$num_month_padded_previous/$num_day_padded_previous/$four_digit_year_previous",
          "$num_month_padded/$num_day_padded/$four_digit_year",
          "$num_month_padded_next/$num_day_padded_next/$four_digit_year_next" ) if ($return_option eq '07');

  return ($full_month[$mon], $num_month, $num_day, $four_digit_year, $full_day[$wday],
          $full_month[$pmon], $num_month_previous, $num_day_previous, $four_digit_year_previous, $full_day[$pwday],
          $full_month[$nmon], $num_month_next, $num_day_next, $four_digit_year_next, $full_day[$nwday]) if ($return_option eq '08');

  # Return Options Times
  return "$num_hour[$hour]:$min_padded:$sec_padded $AM_PM" if ($return_option eq '30');

  # Return Options Dates & Times
  return "$four_digit_year-$num_month_padded-$num_day_padded-$mil_hour[$hour]-$min_padded-$sec_padded" if ($return_option eq '50');
  return "$four_digit_year$num_month_padded$num_day_padded$mil_hour[$hour]$min_padded$sec_padded" if ($return_option eq '51');
  return "$four_digit_year/$num_month_padded/$num_day_padded $mil_hour[$hour]:$min_padded:$sec_padded" if ($return_option eq '52');

}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# eg. print &shazam::datetime_return_number_of_days_between_dates(1, 1, 1996, 12, 31, 1998);
#
# returns the number of days between the two dates.  The value will be negative
# if the second date is earlier than the first date.
#-----------------------------------------------------------------------------#
sub datetime_return_number_of_days_between_dates {
  my ($mon1, $day1, $year1, $mon2, $day2, $year2) = @_;

  use Time::Local;

  return sprintf("%.0f", (timelocal(0, 0, 0, $day2, $mon2 - 1, $year2) - timelocal(0, 0, 0, $day1, $mon1 - 1, $year1)) / (60 * 60 * 24));
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Decide what to do with this!
#-----------------------------------------------------------------------------#
sub datetime_unix_to_date {
  my $time   = shift;
  my ($sec, $min, $hour, $day, $mon, $year, $dweek, $dyear, $tz) = localtime $time;
  my @months = qw!01 02 03 04 05 06 07 08 09 10 11 12!;
  return "$months[$mon]/$day/$year";
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub finance_build_html_invoice_or_estimate{
  my ($type, $top_center, $logo_url,
      $company_name, $company_address, $company_city_state_zip, $company_phone, $company_email,
      $billto_attention, $billto_company, $billto_address, $billto_city_state_zip, $billto_phone, $billto_email,
      $invoice_number, $date_generated, $due_date, $discount_percentage, $tax, $comments, @details) = @_;


  my ($template, $total_due, $details, $subtotal, $discount_amount);


  # 0 Date
  # 1 Description
  # 2 qty
  # 3 price

  $subtotal = 0;

  my($detail_build, $line_sum);
  foreach(@details) {
   my ($d_date, $d_desc, $d_qty, $d_price) = split(/\|/, $_);

   $d_date = $core::dynamic_vars{'datetime date'} if ($d_date eq '');
   $d_qty = 0 if ($d_qty eq '');
   $d_price = 0.00 if ($d_price eq '');

   $line_sum = ($d_price * $d_qty);
   $subtotal = ($subtotal + $line_sum);
   $discount_amount = ($subtotal * ($discount_percentage /100));
   $total_due = ($subtotal - $discount_amount);

   $d_price = &shazam::finance_format_money($d_price);
   $line_sum = &shazam::finance_format_money($line_sum);
   $subtotal = &shazam::finance_format_money($subtotal);
   $discount_amount = &shazam::finance_format_money($discount_amount);
   $total_due = &shazam::finance_format_money($total_due);

    $detail_build .= qq|
      <TR valign="top">
        <TD valign="top" bgcolor="#FFFFFF" styleID="StyleServiceDate" nowrap>$d_date</TD>
        <TD valign="top" bgcolor="#FFFFFF" styleID="StyleItemDesc">$d_desc</TD>
        <TD align="center" valign="top" bgcolor="#FFFFFF" styleID="StyleItemDesc" nowrap>$d_qty</TD>
        <TD align="right" valign="top" bgcolor="#FFFFFF" styleID="StyleItemDesc" nowrap>\$$d_price</TD>
        <TD align="right" valign="top" bgcolor="#FFFFFF" styleID="StyleItemAmount" nowrap>\$$line_sum</TD>
      </TR>
    |;
  }



$template = qq|

<center>
<table width="95%" border="0" cellpadding="10" cellspacing="0">
  <tr>
    <td bgcolor="#FFFFFF">
      <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" styleID="style_layout">
        <TR>
          <TD>
            <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="row_grouping">
              <TR>
                <TD width="34%" styleID="row_spacing"></TD>
                <TD width="31%" valign="top" styleID="row_field" align="right" bgcolor="#FFFFFF">
                  <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StyleTitle">
                    <TR>
                      <TD align="center" valign="center" nowrap="true" bgcolor="#FFFFFF"><b>&nbsp;$top_center&nbsp;</b></TD>
                    </TR>
                  </TABLE>
                </TD>
                <TD width="34%" styleID="row_spacing"></TD>
              </TR>
            </TABLE>
          </TD>
        </TR>
        <TR>
          <TD>&nbsp;</TD>
        </TR>
        <TR>
          <TD>
            <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="row_grouping">
              <TR>
                <TD width="47%" valign="top" styleID="row_field">
                  <TABLE width="100%" border="0" cellpadding="3" cellspacing="0" styleID="combined">
                    <TR>
                      <TD width="100%" styleID="StyleCompName" align="left" valign="top" bgcolor="#FFFFFF"><b>$company_name</b></TD>
                    </TR>
                    <TR>
                      <TD width="100%" styleID="StyleCompAddress" align="left" valign="top" bgcolor="#FFFFFF">
                        <TABLE border="0" cellpadding="0" cellspacing="0" styleID="format_address">
                          <TR>
                            <TD nowrap="true" bgcolor="#FFFFFF">$company_address</TD>
                          </TR>
                          <TR>
                            <TD bgcolor="#FFFFFF">$company_city_state_zip</TD>
                          </TR>
                          <TR>
                            <TD bgcolor="#FFFFFF">$company_phone</TD>
                          </TR>
                          <TR>
                            <TD bgcolor="#FFFFFF">$company_email</TD>
                          </TR>
                        </TABLE>
                      </TD>
                    </TR>
                  </TABLE>
                </TD>
                <TD width="18%" styleID="row_spacing"></TD>
                <TD width="34%" valign="top" styleID="row_field" align="right">
                  <TABLE width="100%" border="0" cellpadding="3" cellspacing="0" styleID="combined_complex">
                    <TR>
                      <TD>
                        <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="combined_complex_inner">
                          <TR>
                            <TD width="100%" bgcolor="#FFFFFF">
                              <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StyleTitle">
                                <TR>
                                  <TD align="right" valign="center" nowrap="true" bgcolor="#FFFFFF"><b>&nbsp;$type&nbsp;</b></TD>
                                </TR>
                              </TABLE>
                            </TD>
                          </TR>
                        </TABLE>
                      </TD>
                    </TR>
                    <TR>
                      <TD>
                        <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="combined_complex_inner">
                          <TR>
                            <TD width="50%"></TD>
                            <TD width="50%"></TD>
                            <TD width="50%"></TD>
                          </TR>
                        </TABLE>
                      </TD>
                    </TR>
                    <TR>
                      <TD>
                        <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="combined_complex_inner">
                          <TR>
                            <TD width="50%"></TD>
                            <TD width="50%" valign="top">
                              <TABLE width="100%" border="0" cellpadding="3" cellspacing="2" styleID="combined" class="box_dark">
                                <TR>
                                  <TD width="100%" class="box_dark">
                                    <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StyleInvNum">
                                      <TR>
                                        <TD align="center" valign="center" nowrap="true" class="titled_box_title"><b>&nbsp;$type #&nbsp;</b></TD>
                                      </TR>
                                    </TABLE>
                                  </TD>
                                </TR>
                                <TR>
                                  <TD width="100%" styleID="StyleInvNum" align="center" valign="center" nowrap="true" bgcolor="#FFFFFF">
                                    &nbsp;$invoice_number&nbsp;</TD>
                                </TR>
                              </TABLE>
                            </TD>
                            <TD width="50%"></TD>
                          </TR>
                        </TABLE>
                      </TD>
                    </TR>
                  </TABLE>
                </TD>
              </TR>
            </TABLE>
          </TD>
        </TR>
        <TR>
          <TD>&nbsp;</TD>
        </TR>
        <TR>
          <TD>
            <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="row_grouping">
              <TR>
                <TD width="26%" valign="top" styleID="row_field">
                  <TABLE width="100%" border="0" cellpadding="3" cellspacing="2" styleID="combined" class="box_dark">
                    <TR>
                      <TD width="100%">
                        <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StyleBillTo" class="box_dark">
                          <TR>
                            <TD align="left" valign="center" nowrap="true" class="titled_box_title"><b>&nbsp;TO&nbsp;</b></TD>
                          </TR>
                        </TABLE>
                      </TD>
                    </TR>
                    <TR>
                      <TD width="100%" styleID="StyleBillTo" align="left" valign="top" bgcolor="#FFFFFF">
                        <TABLE border="0" cellpadding="0" cellspacing="0" styleID="format_address">
                          <TR>
                            <TD nowrap="true" bgcolor="#FFFFFF">$billto_attention</TD>
                          </TR>
                          <TR>
                            <TD nowrap="true" bgcolor="#FFFFFF">$billto_company</TD>
                          </TR>
                          <TR>
                            <TD nowrap="true" bgcolor="#FFFFFF">$billto_address</TD>
                          </TR>
                          <TR>
                            <TD bgcolor="#FFFFFF">$billto_city_state_zip</TD>
                          </TR>
                          <TR>
                            <TD bgcolor="#FFFFFF">$billto_phone</TD>
                          </TR>
                          <TR>
                            <TD bgcolor="#FFFFFF">$billto_email</TD>
                          </TR>
                        </TABLE>
                      </TD>
                    </TR>
                  </TABLE>
                </TD>
                <TD width="40%" styleID="row_spacing"></TD>
                <TD width="34%" valign="top" styleID="row_field" align="right">
                  <TABLE width="100%" border="0" cellpadding="3" cellspacing="2" styleID="combined" class="box_dark">
                    <TR>
                      <TD width="50%">
                        <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StyleDate" class="box_dark">
                          <TR>
                            <TD align="center" valign="center" nowrap="true" class="titled_box_title"><b>&nbsp;DATE&nbsp;</b></TD>
                          </TR>
                        </TABLE>
                      </TD>
                      <TD width="50%">
                        <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StyleDueDate" class="box_dark">
                          <TR>
                            <TD align="center" valign="center" nowrap="true" class="titled_box_title"><b>&nbsp;DUE DATE&nbsp;</b></TD>
                          </TR>
                        </TABLE>
                      </TD>
                    </TR>
                    <TR>
                      <TD width="50%" styleID="StyleDate" align="center" valign="center" nowrap="true" bgcolor="#FFFFFF">
                        &nbsp;$date_generated&nbsp;</TD>
                      <TD width="50%" styleID="StyleDueDate" align="center" valign="center" nowrap="true" bgcolor="#FFFFFF">&nbsp;$due_date&nbsp;</TD>
                    </TR>
                  </TABLE>
                </TD>
              </TR>
            </TABLE>
          </TD>
        </TR>
        <TR>
          <TD>&nbsp;</TD>
        </TR>
        <TR>
          <TD>
            <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="row_grouping">
              <TR>
                <TD width="65%" styleID="row_spacing"></TD>
                <TD width="34%" valign="top" styleID="row_field" align="right">
                  <TABLE width="100%" border="0" cellpadding="3" cellspacing="2" styleID="combined" class="box_dark">
                    <TR>
                      <TD width="50%" class="box_dark">
                        <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StmtStyleAmountDue">
                          <TR>
                            <TD align="center" valign="center" nowrap="true" class="titled_box_title"><b>&nbsp;AMOUNT DUE&nbsp;</b></TD>
                          </TR>
                        </TABLE>
                      </TD>
                      <TD width="50%" class="box_dark">
                        <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StmtStyleAmountEnclosed">
                          <TR>
                            <TD align="center" valign="center" nowrap="true" class="titled_box_title"><b>&nbsp;ENCLOSED&nbsp;</b></TD>
                          </TR>
                        </TABLE>
                      </TD>
                    </TR>
                    <TR>
                      <TD width="50%" styleID="StmtStyleAmountDue" align="right" valign="center" nowrap="true" bgcolor="#FFFFFF">
                        &nbsp;\$$total_due&nbsp;</TD>
                      <TD width="50%" styleID="StmtStyleAmountEnclosed" align="right" valign="center" nowrap="true" bgcolor="#FFFFFF">
                        &nbsp;&nbsp;&nbsp;</TD>
                    </TR>
                  </TABLE>
                </TD>
              </TR>
            </TABLE>
          </TD>
        </TR>
        <TR>
          <TD>&nbsp;</TD>
        </TR>
        <TR>
          <TD>
            <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="row_grouping">
              <TR>
                <TD width="100%" valign="center" styleID="row_field" align="center" bgcolor="#FFFFFF">
                  <TABLE cellpadding="0" cellspacing="0">
                    <TR>
                      <TD>
                        <hr>
                      </TD>
                      <TD width="1%" nowrap="true" align="center">&nbsp;
                        <i>Clip Here</i>&nbsp;</TD>
                      <TD>
                        <hr>
                      </TD>
                    </TR>
                  </TABLE>
                </TD>
              </TR>
            </TABLE>
          </TD>
        </TR>
        <TR>
          <TD></TD>
        </TR>
        <TR>
          <TD>
            <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="item_table_row">
              <TR>
                <TD width="100%" valign="top">
                  <TABLE width="100%" border="0" class="box_dark" cellpadding="6" cellspacing="2" rules="cols" styleID="item_table">
                    <TR>
                      <TD width="" align="left" valign="center" nowrap="true" class="titled_box_title" styleID="StyleServiceDate"><b>DATE</b></TD>
                      <TD width="100%" align="left" valign="center" nowrap="true" class="titled_box_title" styleID="StyleItemDesc"><b></b></TD>
                      <TD width="" align="center" valign="center" nowrap="true" class="titled_box_title" styleID="StyleItemDesc"><b>QTY</b></TD>
                      <TD width="" align="center" valign="center" nowrap="true" class="titled_box_title" styleID="StyleItemAmount"><b>UNIT</b></TD>
                      <TD width="" align="left" valign="center" nowrap="true" class="titled_box_title" styleID="StyleItemAmount"><b>AMOUNT</b></TD>
                    </TR>

                    $detail_build

                  </TABLE>
                </TD>
              </TR>
            </TABLE>
          </TD>
        </TR>
        <TR>
          <TD></TD>
        </TR>
        <TR>
          <TD>
            <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="row_grouping">
              <TR>
                <TD width="65%" styleID="row_spacing"></TD>
                <TD width="34%" valign="top" styleID="row_field" align="right">
                  <TABLE width="100%" border="0" cellpadding="3" cellspacing="2" styleID="combined" class="box_dark">
                    <TR>
                      <TD width="50%">
                        <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StyleSubtotal">
                          <TR>
                            <TD align="right" valign="center" nowrap="true" class="titled_box_title"><b>&nbsp;SUBTOTAL&nbsp;</b></TD>
                          </TR>
                        </TABLE>
                      </TD>
                      <TD width="50%" styleID="StyleSubtotal" align="right" valign="center" nowrap="true" bgcolor="#FFFFFF"><b>&nbsp;\$$subtotal&nbsp;</b></TD>
                    </TR>
                    <TR>
                      <TD width="50%">
                        <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StyleDiscountAmt">
                          <TR>
                            <TD align="right" valign="center" nowrap="true" class="titled_box_title"><b>&nbsp;DISCOUNT ($discount_percentage\%)&nbsp;</b></TD>
                          </TR>
                        </TABLE>
                      </TD>
                      <TD width="50%" styleID="StyleDiscountAmt" align="right" valign="center" nowrap="true" bgcolor="#FFFFFF"><b>&nbsp;-\$$discount_amount&nbsp;</b></TD>
                    </TR>
                    <TR>
                      <TD width="50%">
                        <TABLE width="100%" cellpadding="0" cellspacing="0" border="0" styleID="StyleTotalAmount">
                          <TR>
                            <TD align="right" valign="center" nowrap="true" class="titled_box_title"><b>&nbsp;TOTAL&nbsp;</b></TD>
                          </TR>
                        </TABLE>
                      </TD>
                      <TD width="50%" styleID="StyleTotalAmount" align="right" valign="center" nowrap="true" bgcolor="#FFFFFF">
                        <b>&nbsp;\$$total_due&nbsp;</b></TD>
                    </TR>
                  </TABLE>
                </TD>
              </TR>
            </TABLE>
          </TD>
        </TR>
        <TR>
          <TD>&nbsp;</TD>
        </TR>
        <TR>
          <TD>
            <TABLE width="100%" border="0" cellpadding="0" cellspacing="0" styleID="row_grouping">
              <TR>
                <TD width="63%" valign="center" styleID="StyleCustMsg" align="left" bgcolor="#FFFFFF">


                </TD>
                <TD width="37%" styleID="row_spacing"></TD>
              </TR>
            </TABLE>
          </TD>
        </TR>
      </TABLE>

    </td>
  </tr>
</table>
</center>
|;

return $template;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub finance_calculate_savings{
  my ($retail, $price) = @_;
  my ($amount, $percentage);
  return ('0', '0.00') if ($retail == 0);
  $amount = &shazam::finance_format_money($retail - $price);
  $percentage = $amount / $retail * 100;
  $percentage = sprintf("%.0f", $percentage);
  return ($percentage, $amount);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub finance_format_commify {
  my $text = reverse $_[0];
  if ($text) {
    $text =~ s/(\d\d\d)(?=\d)(?!\d*\.)/$1,/g;
    return scalar reverse $text;
  } else {
    return '';
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub finance_format_commify_dollar_sign {
  my $text = reverse $_[0];
  if ($text ne '') {
    $text =~ s/(\d\d\d)(?=\d)(?!\d*\.)/$1,/g;
    return scalar reverse $text . "\$";
  } else {
    return '';
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub finance_format_money{
  my ($str) = @_;
#  $str =~ s/\D//g;
  return sprintf("%.2f", $str);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub graphics_color_convert_hex6_to_rgb {
  my ($hex_code) = @_;
  $hex_code = uc($hex_code);
  $hex_code =~ s/[^0-9A-F]//g;
  if ($hex_code =~ /^([0-9A-F]{2})([0-9A-F]{2})([0-9A-F]{2})$/) {
    return (hex($1), hex($2), hex($3));
  } else {
    return (0, 0, 0);
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub graphics_color_convert_hsv_to_rgb {
  my ($h, $s, $v) = @_;
  my ($r, $g, $b);
  my ($f, $i, $h_temp, $p, $q, $t);

  if ($s == 0) {
    $r = $g = $b = $v;
  } else {
    if ($h == 360) { $h_temp = 0; } else { $h_temp = $h; }
    $h_temp /= 60;

    $i = int($h_temp);
    $f = $h_temp - $i;
    $p = $v * (1 - $s);
    $q = $v * (1 - ($s * $f));
    $t = $v * (1 - ($s * (1 - $f)));

    if ($i == 0) {$r = $v; $g = $t; $b = $p;}
    if ($i == 1) {$r = $q; $g = $v; $b = $p;}
    if ($i == 2) {$r = $p; $g = $v; $b = $t;}
    if ($i == 3) {$r = $p; $g = $q; $b = $v;}
    if ($i == 4) {$r = $t; $g = $p; $b = $v;}
    if ($i > 4) {$r = $v; $g = $p; $b = $q;}
  }
  return (int($r), int($g), int($b));
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub graphics_color_convert_rgb_to_hex6 {
  my ($r, $g, $b, $include_hash_mark) = @_;
  my $hash;
  $hash = '#' if ($include_hash_mark eq 'true');
  foreach ($r, $g, $b) { $_ = ($_<0) ? 0 : ( ($_>255) ? 255 : $_+0 ) };
  return(sprintf("$hash%2.2X%2.2X%2.2X",$r,$g,$b));
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub graphics_color_convert_rgb_to_hsv {
  my ($r, $g, $b2) = @_;
  my ($h, $s, $v, $delta, $min);

  $min = [sort {$a <=> $b} ($r, $g, $b2)] -> [0];
  $v   = [sort {$b <=> $a} ($r, $g, $b2)] -> [0];
  $delta = $v - $min;

  if ($v == 0 || $delta == 0) { $s = 0; $h = 0; }
  else {
    if    ($r == $v)  { $h =       60 * ($g  - $b2) / $delta; }
    elsif ($g == $v)  { $h = 120 + 60 * ($b2 - $r ) / $delta; }
    else              { $h = 240 + 60 * ($r  - $g ) / $delta; }
    $h = $h + 360 if ($h < 0);
  }
  
  return ($h, $s, $v);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub graphics_color_return_gradient {
  my ($hex_code_1, $hex_code_2, $num_colors_or_point_array_ref) = @_;

  my @points;
  if (ref($num_colors_or_point_array_ref) eq 'ARRAY') {
    @points = @$num_colors_or_point_array_ref;
  } else {
    return if ($num_colors_or_point_array_ref < 1);
    foreach (0..$num_colors_or_point_array_ref - 1) {
      push(@points, 100 / ($num_colors_or_point_array_ref - 1) * $_);
    }
  }
  
  my @start_point = &shazam::graphics_color_convert_hex6_to_rgb($hex_code_1);
  my @end_point = &shazam::graphics_color_convert_hex6_to_rgb($hex_code_2);
  my @difference;
  
  foreach (0..2) {
    $difference[$_] = $end_point[$_] - $start_point[$_];
  }

  my @colors;
  foreach (@points) {
    my @this_color;
    foreach my $color_element (0..2) {
      $this_color[$color_element] = $start_point[$color_element] + $_ / 100 * $difference[$color_element];
    }
    push(@colors, [@this_color]);
  }
  
  foreach (@colors) {
    $_ = &shazam::graphics_color_convert_rgb_to_hex6(@$_);
  }
  
  return @colors;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub graphics_color_return_matching_analagous {
  my ($hex, $hue_arc, $number_of_colors) = @_;
  $hue_arc = 60 if ($hue_arc eq '');
  $number_of_colors = 6 if ($number_of_colors eq '');
  my ($h, $s, $v) = &shazam::graphics_color_convert_rgb_to_hsv(&shazam::graphics_color_convert_hex6_to_rgb($hex));
  my @colors;
  my $hue_step = $hue_arc / $number_of_colors;
  for (my $new_hue = $h - $hue_arc/2; $new_hue < $h + $hue_arc/2; $new_hue += $hue_step) {
        my $hue_to_push = $new_hue;
        $hue_to_push += 360 if ($hue_to_push < 0);
    $hue_to_push -= 360 if ($hue_to_push >= 360);
        push (@colors, $hue_to_push);
  }

  foreach (@colors) {
    $_ = &shazam::graphics_color_convert_rgb_to_hex6(&graphics_color_convert_hsv_to_rgb($_, $s, $v), 'true');
  }
  return @colors;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub graphics_color_return_matching_complimentary {
  my ($h, $s, $v) = &shazam::graphics_color_convert_rgb_to_hsv( &shazam::graphics_color_convert_hex6_to_rgb($_[0]) );
  return (&shazam::graphics_color_convert_rgb_to_hex6( &shazam::graphics_color_convert_hex6_to_rgb($_[0]), 'true' ), &shazam::graphics_color_convert_rgb_to_hex6(&shazam::graphics_color_convert_hsv_to_rgb($h + 180, $s, $v), 'true'));
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub graphics_color_return_matching_monochromatic {
  my ($hex, $value_range, $number_of_colors) = @_;
  $value_range = 50 if ($value_range eq '');
  $number_of_colors = 6 if ($number_of_colors eq '');
  my ($h, $s, $v) = &shazam::graphics_color_convert_rgb_to_hsv(&shazam::graphics_color_convert_hex6_to_rgb($hex));
  
  $v = 100 - $value_range / 2 if ($v > 100 - $value_range / 2);
  $v = $value_range / 2 if ($v < $value_range / 2);
  my @colors;
  my $value_step = $value_range / $number_of_colors;
  for (my $new_value = $v - $value_range/2; $new_value < $v + $value_range/2; $new_value += $value_step) {
    my $value_to_push = $new_value;
    push (@colors, $value_to_push);
  }
  foreach (@colors) {
    $_ = &shazam::graphics_color_convert_rgb_to_hex6(&shazam::graphics_color_convert_hsv_to_rgb($h, $s, $v), 'true');
  }
  
  return @colors;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub graphics_color_return_matching_triadic {
  my ($hex, $hue_arc) = @_;
  $hue_arc = 15 if ($hue_arc eq '');
  my ($h, $s, $v) = &shazam::graphics_color_convert_rgb_to_hsv(&shazam::color_convert_hex6_to_rgb($hex));
  my @colors;
  foreach ($h-120, $h, $h+120) {
    foreach my $hue_to_push ($_-$hue_arc/2, $_, $_+$hue_arc/2) {
      $hue_to_push += 360 if ($hue_to_push < 0);
      $hue_to_push -= 360 if ($hue_to_push >= 360);
      push (@colors, $hue_to_push);
    }
  }

  foreach (@colors) {
    $_ = &shazam::graphics_color_convert_rgb_to_hex6(&shazam::graphics_color_convert_hsv_to_rgb($_, $s, $v), 'true');
  }
  return @colors;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_auto_paragraph {
  my($work) = shift;

  $work = &shazam::string_trim_ws($work);
  $work =~ s/\r/\n/g;
  $work =~ s/\n+/\n/g;
  $work =~ s/\n/\<\/p\>\n\<p\>/g;
  $work = '<p>' . $work . '</p>' if ($work);

  return $work;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_auto_paragraph_with_breaks_and_no_linefeeds {
  my($work) = shift;
  $work = &shazam::html_auto_paragraph($work);
  $work =~ s/\n//g;
  $work =~ s/\<p\>//g;
  $work =~ s/\<\/p\>/\<br\>\<br\>/g;
  $work =~ s/\<br\>$//g; # Remove all breaks from end
  return $work;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_basic_lf_to_br_breaks {
  my($work) = shift;
  $work =~ s/\n/<br>/g;
  return $work;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_basic_lf_to_br_optional_paragraph_wrap {
  my($text, $wrap_in_paragraph_tags) = @_;
  $text =~ s/\r/\n/g;
  $text =~ s/\n/\<br\>/g;
  $text = qq|<p>$text</p>| if ($wrap_in_paragraph_tags eq 'true' && $text ne '');
  return $text;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_build_a_href {
  my($actual_link, $in_the_a, $force_http_in_actual_link, $open_in_new_window, $params) = @_;
  my($target, $proto);

  $params = ' ' . $params if ($params ne '');
  $in_the_a = $actual_link if ($in_the_a eq '');
  $actual_link =~ /()/;
  $actual_link =~ s/^(https):\/\///i if ($force_http_in_actual_link eq 'true');
  $actual_link =~ s/^(http):\/\///i if ($force_http_in_actual_link eq 'true');
  $proto = $1;
  $proto = 'http' if ($proto eq '');
  $actual_link = "$proto://" . $actual_link if ($force_http_in_actual_link eq 'true');

  $target = ' target="_blank"' if ($open_in_new_window eq 'true');

  return qq|<a$target href="$actual_link"$params>$in_the_a</a>|
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_build_a_mailto {
  my($email_address, $in_the_a, $from, $cc, $subject, $body, $params) = @_;
  my($target, $proto);

  $params = ' ' . $params if ($params ne '');
  $in_the_a = $email_address if ($in_the_a eq '');

  return qq|<a href="mailto:$email_address?from=$from&cc=$cc&subject=$subject&body=$body"$params>$in_the_a</a>|
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_build_graph_bar_horizontal {
  my ($bar_style, $item_separator, $scale, $field_top_specifier, $field_left_specifier, $field_right_specifier, $color_mode_array_ref, @dataset) = @_;
  $scale = '' if ($scale <= 0);
  my $build;
  
  my @color_mode_array = (ref($color_mode_array_ref) eq 'ARRAY')?@$color_mode_array_ref:('');
  #print Dumper(@color_mode_array);
  my $color_mode = shift(@color_mode_array);
  my @color_array;
  if ($color_mode eq '' && @color_array < 1) {
    @color_array = ('#888888');
  } elsif ($color_mode eq 'repeat' || $color_mode eq 'normal' || $color_mode eq 'default' || $color_mode eq '') {
    @color_array = @color_mode_array;
  } elsif ($color_mode eq 'fade' || $color_mode eq 'gradient') {
    @color_array = &shazam::graphics_color_return_gradient($color_mode_array[0], $color_mode_array[1], scalar(@dataset));
  }
  
  foreach (@color_array) { $_ = qq^ bgcolor="$_"^ }
  
  while (@color_array < @dataset) {
    my @colors_to_push = @color_array;
    if (@color_array + @colors_to_push > @dataset) {
      @colors_to_push = splice(@colors_to_push, 0, @dataset - @color_array);
    }
    push(@color_array, @colors_to_push);
    if (@color_array < 1) {
      foreach (0..@dataset-1) {
        $color_array[$_] = '';
      }
    }
  }
  
  # Field Specifiers
  #
  # %l = label
  # %v = value
  # %p = percent of total rounded
  # %P = percent of total unrounded
  # %s = percent of scale rounded
  # %S = percent of scale unrounded
  # %m = maximum
  # %t = total
  # %r = rank descending
  # %R = rank ascending

  my $maximum;
  my $total;
  my @values;
  foreach (@dataset) {
    my ($key, $value) = split(/::/, $_);
    $maximum = $value if ($value > $maximum);
    $total += $value;
    push(@values, $value);
  }
  my @order = &shazam::struct_return_array_sort_indicies(@values);
  
  $scale = $maximum if ($scale < $maximum);
  $scale = 1 if ($scale == 0);
  
  my $columns = 1;
  $columns++ if ($field_left_specifier ne '');
  $columns++ if ($field_right_specifier ne '');

  my $index;
  foreach (@dataset) {
    my ($key, $value) = split(/::/, $_);
    my $bar_length = int($value / $scale * 100);
    my $bar_length_complimentary = 100 - $bar_length;
    my $percent = ($total>0)? int($value / $total * 100): 0;
    my $rank_a = $order[$index] + 1;
    my $rank_d = @order - $order[$index];
    
    if ($color_mode eq 'value' || $color_mode eq 'percent' || $color_mode eq 'scale') {
      $color_array[$index] = ' bgcolor="#' . [&shazam::graphics_color_return_gradient($color_mode_array[0], $color_mode_array[1], [$bar_length])]->[0] . '"';
    }

    my %replacements_hash;
    $replacements_hash{'%l'} = $key;
    $replacements_hash{'%v'} = $value;
    $replacements_hash{'%p'} = $percent;
    $replacements_hash{'%P'} = ($total>0)? $value / $total * 100: 0;
    $replacements_hash{'%s'} = $bar_length;
    $replacements_hash{'%S'} = $value / $scale * 100;
    $replacements_hash{'%m'} = $maximum;
    $replacements_hash{'%t'} = $total;
    $replacements_hash{'%r'} = $rank_d;
    $replacements_hash{'%R'} = $rank_a;

    my $field_top = $field_top_specifier;
    my $field_left = $field_left_specifier;
    my $field_right = $field_right_specifier;
    &shazam::string_do_replacements_from_hash_ref(\%replacements_hash, \$field_top, \$field_left, \$field_right);
    
    my $bar = qq^<table width="100%" style="border: inset 1px;" cellspacing="0" cellpadding="0"><tr><td width="$bar_length%" align="right" style="$bar_style"$color_array[$index]><img src="$core::dynamic_vars{'url shared system'}images/transparent.gif" width="1" height="1"></td><td width="$bar_length_complimentary%"><img src="$core::dynamic_vars{'url shared system'}images/transparent.gif" width="1"></td></tr></table>^;

    $build .= qq^<tr><td colspan="$columns" style="padding: 0px; spacing: 0px;">$item_separator</td></tr>\n^ if ($item_separator ne '' && $index == 0);
    $build .= qq^<tr><td colspan="$columns" style="padding-top: 3px; padding-bottom: 0px;">$field_top</td></tr>\n^ if ($field_top_specifier ne '');
    $build .= '<tr>';
    $build .= qq^<td align="right" width="0">$field_left</td>^ if ($field_left_specifier ne '');
    $build .= qq^<td width="100%">$bar</td>^;
    $build .= qq^<td>$field_right</td>^ if ($field_right_specifier ne '');
    $build .= "</tr>\n";
    $build .= qq^<tr><td colspan="$columns" style="padding: 0px; spacing: 0px;">$item_separator</td></tr>\n^ if ($item_separator ne '');
    $index++;
  }

  $build = qq^\n<table width="100%">\n$build</table>\n^;

  #$build = qq^<style>.box_dark{background-color:#888888;} .box_light{background-color:#AAAAAA;}</style>\n$build^;

  return $build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# example: &shazam::html_build_select_box($name, $selected, @options)
# name
# selected
# value|Name
# value|Name
#-----------------------------------------------------------------------------#
sub html_build_select_box {
  my($name, $selected, @options) = @_;
  my (@split, $build, $value);

  foreach $value (@options) {
    @split = split(/\|/, $value);
    $build .= qq|  <option value="$split[0]">$split[1]</option>| . "\n" if ($split[0] ne $selected);
    $build .= qq|  <option value="$split[0]" selected>$split[1]</option>| . "\n" if ($split[0] eq $selected);
  }
  $build = qq|<select class="form_element" name="$name">| . "\n" . $build . "</select>";
  return $build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# example: &shazam::html_build_select_box($name, $selected, @options)
# name
# selected
# value|Name
# value|Name
#-----------------------------------------------------------------------------#
sub html_build_select_box_class {
  my($name, $class, $selected, @options) = @_;
  my (@split, $build, $value);

  foreach $value (@options) {
    @split = split(/\|/, $value);
    $build .= qq|  <option value="$split[0]">$split[1]</option>| . "\n" if ($split[0] ne $selected);
    $build .= qq|  <option value="$split[0]" selected>$split[1]</option>| . "\n" if ($split[0] eq $selected);
  }
  $build = qq|<select class="$class" name="$name">| . "\n" . $build . "</select>";
  return $build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# example: &shazam::html_build_select_box($name, $selected, @options)
# name
# selected
# value|Name
# value|Name
#-----------------------------------------------------------------------------#
sub html_build_select_box_params {
  my($name, $params, $selected, @options) = @_;
  my (@split, $build, $value);

  foreach $value (@options) {
    @split = split(/\|/, $value);
    $build .= qq|  <option value="$split[0]">$split[1]</option>| . "\n" if ($split[0] ne $selected);
    $build .= qq|  <option value="$split[0]" selected>$split[1]</option>| . "\n" if ($split[0] eq $selected);
  }
  $build = qq|<select $params name="$name">| . "\n" . $build . "</select>";
  return $build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# example: &shazam::html_build_select_box($name, $selected, @options)
# name
# selected
# value|Name
# value|Name
#-----------------------------------------------------------------------------#
sub html_build_select_box_params_flat {
  my($name, $params, $selected, @options) = @_;
  my (@split, $build, $value);

  foreach $value (@options) {
    @split = split(/\|/, $value);
    $build .= qq|  <option value="$split[0]">$split[1]</option>| . "\n" if ($split[0] ne $selected);
    $build .= qq|  <option value="$split[0]" selected>$split[1]</option>| . "\n" if ($split[0] eq $selected);
  }
  $build = qq|<select $params name="$name">| . "\n" . $build . "</select>";
  $build =~ s/\n/ /g;
  return $build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# example: &shazam::html_build_table($cols, $table_params, $tr_params, $td_params, @data);
#-----------------------------------------------------------------------------#
sub html_build_table{
  my($cols, $table_params, $tr_params, $td_params, @data) = @_;
  my($i, $work);

  return '' if (@data < 1);

  my $mod = (@data % $cols);

  $table_params = ' ' . $table_params if ($table_params);
  $tr_params = ' ' . $tr_params if ($tr_params);
  $td_params = ' ' . $td_params if ($td_params);

  for ($i = 0; $i < @data; $i++){
    $work .= "  <td$td_params>$data[$i]</td>\n";
    $work .= "</tr>\n<tr$tr_params>\n" if (((($i + 1) % $cols) == 0) && (($i + 1) != @data));
    $work .= "  <td$td_params>&nbsp;</td>\n" x ($cols - $mod) if ((($i + 1) == @data) && ($mod != 0));
  }
  $work = "<table$table_params>\n<tr$tr_params>\n$work\n</tr>\n</table>";

  return $work;
}




# Attention - need to fix these
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# description: Builds an aligned, balanced HTML table, sorted in rows
# example: &shazam::html_build_table_balanced($params_table_outer, $params_tr_outer, $params_td_outer, $params_table_inner, $params_tr_inner, $params_td_inner, $columns, $auto_reduce_columns, @data);
# parameters: table, tr, and td params for outer and inner tables respectively;
#             number of columns; whether columns reduce if data is too small; data
#-----------------------------------------------------------------------------#
sub html_build_table_balanced {
  my ($params_table_outer, $params_tr_outer, $params_td_outer, $params_table_inner, $params_tr_inner, $params_td_inner, $columns, $auto_reduce_columns, @data) = @_;

  return '' if (@data < 1);

  $columns = scalar(@data) if ($columns > scalar(@data) && $auto_reduce_columns eq 'true');

  my (@temp_array, @built_data, $iter0, $iter1);
  for ($iter1 = 0; $iter1 < $columns; $iter1++) {
    @temp_array = ();
          for ($iter0 = 0; $iter0 < scalar(@data); $iter0 += $columns) {
      push(@temp_array, $data[$iter0 + $iter1]);
          }
          push(@built_data, &shazam::html_build_table(1,$params_table_inner,$params_tr_inner,$params_td_inner,@temp_array));
  }
  return &shazam::html_build_table($columns,$params_table_outer,$params_tr_outer,$params_td_outer,@built_data);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# example: &shazam::html_build_table_force_rows($rows, $table_params, $tr_params, $td_params, @data);
#-----------------------------------------------------------------------------#
sub html_build_table_force_rows{
  my($rows, $table_params, $tr_params, $td_params, @data) = @_;
  my(%new_data, $insert_position, $i, $work, %new_data_entry_count);

  return '' if (@data < 1);

  $rows = 1 if (!$rows);
  $table_params = ' ' . $table_params if ($table_params);
  $tr_params = ' ' . $tr_params if ($tr_params);
  $td_params = ' ' . $td_params if ($td_params);

  %new_data = ();
  %new_data_entry_count = 0;
  $insert_position = 1;

  for ($i = 0; $i < @data; $i++){
    $insert_position = 1 if ($insert_position > $rows);
    $new_data{$insert_position} .= "  <td$td_params>" . $data[$i] . '</td>' . "\n";
    $new_data_entry_count{$insert_position}++;
    $insert_position++;
  }

  # Insert empty <td>'s
  foreach (keys %new_data_entry_count) {
    $new_data{$_} .= '  <td>&nbsp;</td>' . "\n" x ($new_data_entry_count{1} - $new_data_entry_count{$_}) if ($new_data_entry_count{$_} < $new_data_entry_count{1} && $_ != 0);
  }

  # Output new construct
  foreach (sort {$a <=> $b} keys %new_data) {
    $work .= "<tr$tr_params>\n" . $new_data{$_} . '</tr>' . "\n";
  }

  $work = "<table$table_params>\n$work</table>";

  return $work;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# example: &shazam::html_build_table_top_to_bottom($cols, $table_params, $tr_params, $td_params, @data);
#-----------------------------------------------------------------------------#
sub html_build_table_top_to_bottom{
  my($cols, $table_params, $tr_params, $td_params, @data) = @_;
  my(%new_data, $insert_position, $i, $work, $empty_cells, $lines);

  return '' if (@data < 1);

  $cols = 1 if (!$cols);
  $table_params = ' ' . $table_params if ($table_params);
  $tr_params = ' ' . $tr_params if ($tr_params);
  $td_params = ' ' . $td_params if ($td_params);

  %new_data = ();
  $insert_position = 1;

  $lines = (@data / $cols);
  $lines = $lines + (1 - ($lines - int($lines))) if ($lines - int($lines) ne 0);
  $empty_cells = ($lines * $cols) - @data;

  while ($empty_cells > 0) {
    push(@data, '&nbsp;');
    $empty_cells--;
  }

  for ($i = 0; $i < @data; $i++){
    $insert_position = 1 if ($insert_position > $lines);
    $new_data{$insert_position} .= "  <td$td_params>" . $data[$i] . '</td>' . "\n";
    #$new_data_entry_count{$insert_position}++;
    $insert_position++;
  }

  # Output new construct
  foreach (sort {$a <=> $b} keys %new_data) {
    $work .= "<tr$tr_params>\n" . $new_data{$_} . '</tr>' . "\n";
  }

  $work = "<table$table_params>\n$work</table>";

  return $work;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# description: Builds an aligned, balanced HTML table, sorted in columns
# example: &shazam::html_build_table_top_to_bottom_balanced($params_table_outer, $params_tr_outer, $params_td_outer, $params_table_inner, $params_tr_inner, $params_td_inner, $columns, $auto_reduce_columns, @data);
# parameters: table, tr, and td params for outer and inner tables respectively;
#             number of columns; whether columns reduce if data is too small; data
#-----------------------------------------------------------------------------#
sub html_build_table_top_to_bottom_balanced {
  my ($params_table_outer, $params_tr_outer, $params_td_outer, $params_table_inner, $params_tr_inner, $params_td_inner, $columns, $auto_reduce_columns, @data) = @_;

  return '' if (@data < 1);

  $columns = scalar(@data) if ($columns > scalar(@data) && $auto_reduce_columns eq 'true');

  my (@temp_array, @built_data, $iter0, $iter1);
  my ($column_size) = sprintf("%.0f", scalar(@data) / $columns) + 1;
  $column_size-- until (($column_size - 1) * $columns - scalar(@data) < 0);
  for ($iter0 = 0; $iter0 < scalar(@data); $iter0++) {
    $iter1++;
    push(@temp_array, $data[$iter0]);
    if ($iter1 >= $column_size || $iter0 == scalar(@data) - 1) {
      push(@built_data, &shazam::html_build_table(1,$params_table_inner,$params_tr_inner,$params_td_inner,@temp_array));
      @temp_array = ();
      $iter1 = 0;
          }
  }
  return &shazam::html_build_table($columns,$params_table_outer,$params_tr_outer,$params_td_outer,@built_data);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# example: &shazam::html_build_text($name, $size, $data)
# name
# size
# data
#-----------------------------------------------------------------------------#
sub html_build_text {
  my($name, $size, $data) = @_;
  my $build = qq|<input class="form_element" type="text" name="$name" value="$data" size="$size">|;
  return $build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# example: &shazam::html_build_textarea($name, $columns, $rows, $wrap, $data)
# name
# columns
# rows
# wrap
# data
#-----------------------------------------------------------------------------#
sub html_build_textarea {
  my($name, $columns, $rows, $wrap, $data) = @_;
  my $build = qq|<textarea class="form_element" name="$name" cols="$columns" rows="$rows" wrap="$wrap">$data</textarea>|;
  return $build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_escape_html {
  my $toencode = shift;
  $toencode=~s/&/&amp;/g;
  $toencode=~s/\"/&quot;/g; # "
  $toencode=~s/>/&gt;/g;
  $toencode=~s/</&lt;/g;

  $toencode=~s/\[/&#91;/g;
  $toencode=~s/\]/&#93;/g;

  return $toencode;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_escape_html_in_hash_by_ref {
  my ($hash_ref) = @_;
  foreach (keys %$hash_ref) {
    $$hash_ref{$_} =~ s/&/&amp;/g;
    $$hash_ref{$_} =~ s/\"/&quot;/g; # "
    $$hash_ref{$_} =~ s/>/&gt;/g;
    $$hash_ref{$_} =~ s/</&lt;/g;

    $$hash_ref{$_} =~ s/\[/&#91;/g;
    $$hash_ref{$_} =~ s/\]/&#93;/g;
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Strip HTML, Markup **Bold - URL's - __Underlines, Auto Paragraph
# $newline_type: p = <p> [default]
#                b = <br>
#-----------------------------------------------------------------------------#
sub html_from_text {
  my ($text_input, $allow_html_in_source, $newline_type) = @_;
  $text_input = &shazam::html_quickstrip_html_and_insert_tags($text_input) if ($allow_html_in_source ne 'true');
  $text_input = &shazam::html_markup_urls_bolding_underlines('true', 'true', 'true', $text_input);
  $text_input = &shazam::html_auto_paragraph($text_input) if ($newline_type eq 'p' || $newline_type eq '');
  $text_input = &shazam::html_auto_paragraph_with_breaks_and_no_linefeeds($text_input) if ($newline_type eq 'b');
  $text_input = &shazam::html_basic_lf_to_br_optional_paragraph_wrap($text_input, 'true') if ($newline_type eq 'binp');
  return $text_input;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_get_metadata {
  my ($html_document) = @_;
  my %metadata = ();

  $html_document =~ /<head[^>]*>(.*?)<\/head[^>]*>/is;
  
  while ($html_document =~ s/<\s*meta\s+name\s*=\s*"([^">]*)"\s+content\s*=\s*"([^">]*)"\s*>//is) {
    $metadata{lc($1)} = $2;
  }

  return \%metadata;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_get_select_boxes_selected_options{
  my($data) = @_;
  my($tmp, %values, $select_box, $name_found, $option_found, $name, $option);

  $tmp = $data;

  while ($tmp =~ m,<select (.*?)/select>,sgi){

    $select_box = $1;

    $name_found = 'false';
    $option_found = 'false';

    # Get select name
    if ($select_box =~ m/name=['"](.*?)['"]/i){
      $name = $1;
      $name_found = 'true';
    }

     # &shazam::cgi_print($name);

    # Get select option
    if ($select_box =~ m/option value="(.*?)" selected/i){
      $option = $1;
      $option_found = 'true';
    }

    $values{$name} = $option if ($name_found && $option_found);
  }

  return %values;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_get_title {
  my ($html_document) = @_;
  my $title = '';

  $html_document =~ /<title[^>]*>(.*?)<\/title[^>]*>/is;
  #$title =~ s/\n//gs;
  $title = &shazam::string_trim_ws($1);

  return $title;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_insert_text_after_first_close_paragraph_tag {
  my($html, $text_to_insert) = @_;
  $html =~ s/<\/p>/<\/p>\n$text_to_insert/i;
  return $html;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_make_javascript_safe_string {
  my $toencode = shift;
  $toencode =~ s{"}{&quot;}gso;
  $toencode =~ s{'}{&#39;}gso;
  return $toencode;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_markup_urls_bolding_underlines {
  my ($urls, $bolding, $underlines, $text) = @_;
  my $protocol = join '|', qw(afs cid ftp gopher http https mid news nntp prospero telnet wais);

  # URLS: mark up URLs as links
  $text =~ s|\b((?:$protocol):\S+[\w/])|<A HREF="$1">$1</A>|g if ($urls eq 'true');

  # BOLD: mark up words in *asterisks* as bold.
  $text =~   s#(^|\s)\*([^*]+)\*(?=\s|$)#$1<B>$2</B>#g if ($bolding eq 'true');

  # UNDERLINE: mark up words in _underscores_ as underlined.
  $text =~ s#(^|\s)_([^_]+?)_(?=\s|$)#$1<U>$2</U>#g if ($underlines eq 'true');

  return $text;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_newline_to_break {
  my $temp = shift;
  $temp =~ s/\n/<br>\n/g;
  return $temp;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0 - Contributed
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_quick_check {
  my %Pair = (
              'A', 1,
         'ADDRESS',1,
               'B',1,
           'BLINK',1,  # mozilla
      'BLOCKQUOTE',1,
              'BQ',1,
          'CENTER',1,  # mozilla
            'CITE',1,
            'CODE',1,
             'DFN',1,
             'DIR',1,
              'DL',1,
              'EM',1,
             'FIG',1,
            'FONT',1,  # mozilla
            'FORM',1,
              'H1',1,
              'H2',1,
              'H3',1,
              'H4',1,
              'H5',1,
              'H6',1,
            'HEAD',1,
            'HTML',1,
               'I',1,
             'KBD',1,
         'LISTING',1,
            'MATH',1,
            'MENU',1,
              'OL',1,
             'PRE',1,
               'S',1,
            'SAMP',1,
          'SELECT',1,
          'STRONG',1,
           'STYLE',1,
           'TABLE',1,
        'TEXTAREA',1,
           'TITLE',1,
              'TT',1,
               'U',1,
              'UL',1,
             'VAR',1,
             'XMP',1,);

# Nestable elements
my %Nestable = (
      'BLOCKQUOTE',1,
              'DL',1,
            'MENU',1,
              'OL',1,
           'TABLE',1,
              'UL',1,);


  local($_) = @_;
  local($*) = 0;

  my($tag, $isendtag, @tags, %tags, $tag1, $Error);

  $Error = "";

  for $tag (/<\s*([^\s>]+)[^>]*>/g) {
    $tag =~ y/a-z/A-Z/;
    $isendtag = $tag =~ s!^/!!;
    next unless $Pair{$tag};

    if ($isendtag) {
      if ($tag1 = pop @tags) {
        $tag1 eq $tag || ($Error .=  "<$tag1> does not match </$tag>\n");
      } else {
        $Error .=  "</$tag> appears without matching <$tag>\n";
      }

      $tags{$tag1} -= 1;
    } else {
      push(@tags, $tag);
      $tags{$tag} += 1;
      $tags{$tag} <=1 || $Nestable{$tag} || ($Error .=  "<$tag> cannot be nested\n");
    }
  }

  for $tag (@tags) {
    $Error .= "missing required </$tag> for <$tag>\n";
  }

  return $Error;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Strips HTML tags from a string
#-----------------------------------------------------------------------------#
sub html_quickstrip_html{
  my $process = shift;
  
  #$process =~ s/<[^>]*>//gs; # sloppy get rid of any html tags
  my $old_length = length($process) + 1;
  while (length($process) < $old_length) {
    $old_length = length($process);
    $process =~ s/<[^+][^<>]*>//gs;
  }
  
  return $process;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Strips HTML tags from a string
#-----------------------------------------------------------------------------#
sub html_quickstrip_html_and_insert_tags{
  my $process = shift;
  
  #$process =~ s/<[^>]*>//gs; # sloppy get rid of any html tags
  #$process =~ s/<\+[^\+>]*\+>//gs; # sloppy get rid of any insert tags
  my $old_length = length($process) + 1;
  while (length($process) < $old_length) {
    $old_length = length($process);
    $process =~ s/<[^<>]*>//gs;
  }
  
  return $process;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_reset_select_boxes_with_selected_options_from_hash{
  my ($form, %options) = @_;
  my ($key, $value);


# This works but is so slow that it is hard to believe
#  use Benchmark; my $t0 = new Benchmark;
#
#  # Remove "selected" from any we will reset
#  foreach (keys %options){
#    $key = $_;
#    $value = $options{$_};
#    $form =~ s,(<select .*?name="$key".*?<option .*?) selected(>.*?/select>),$1$2,sgi;
#  }
#
#  my $t1 = new Benchmark; my $td = timediff($t1, $t0); &shazam::cgi_print( timestr($td) );


  # This will remove the selected status from ALL select boxes even ones not in the options hash
  # But it is faster
  $form =~ s/ selected>/>/gi;


  # Set selected option for any select boxes in our hash
  foreach (keys %options){
    $key = $_;
    $value = $options{$_};
    $form =~ s,(<select .*?name="$key".*?<option value="$value".*?)(>.*?/select>),$1 selected$2,sgi;
  }


  return $form;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_unescape_html {
    my $string = shift;

    $string =~ s[&(.*?);]{
        local $_ = $1;
        /^amp$/i        ? "&" :
        /^quot$/i       ? '"' :
        /^gt$/i         ? ">" :
        /^lt$/i         ? "<" :
        /^#(\d+)$/      ? chr($1) :
        /^#x([0-9a-f]+)$/i ? chr(hex($1)) :
        $_
        }gex;
    return $string;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub image_adjust_brightness_from_array {
  my ($use_purity_cache, $percentage, @images) = @_;
  my ($image, $background, $file_name, $path);
  my ($extension, $file_without_ext);

  use Image::Magick;

  foreach (@images){
    ($file_name, $path) = &shazam::io_split_path_and_file($_);
    ($extension, $file_without_ext) = &shazam::io_split_filename_and_exsension($file_name);

    $image = Image::Magick->new;

    # If a purity cache image exists open it, if not open the actual
    if ($use_purity_cache eq 'true' && -e $path . $file_without_ext . '_purity_cache.bmp'){
      $image->Read($path . $file_without_ext . '_purity_cache.bmp');
    } else {
      $image->Read($path . $file_name);
    }

    # Do Stuff
    $image->Modulate('brightness' => $percentage);

    # Write purity cache
    $image->Write($path . $file_without_ext . '_purity_cache.bmp') if ($use_purity_cache eq 'true');

    # Write actual file
    $image->Write($path . $file_without_ext . '.' . $extension);

    undef $image;
   }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub image_adjust_saturation_from_array {
  my ($use_purity_cache, $percentage, @images) = @_;
  my ($image, $background, $file_name, $path);
  my ($extension, $file_without_ext);

  use Image::Magick;

  foreach (@images){
    ($file_name, $path) = &shazam::io_split_path_and_file($_);
    ($extension, $file_without_ext) = &shazam::io_split_filename_and_exsension($file_name);

    $image = Image::Magick->new;

    # If a purity cache image exists open it, if not open the actual
    if ($use_purity_cache eq 'true' && -e $path . $file_without_ext . '_purity_cache.bmp'){
      $image->Read($path . $file_without_ext . '_purity_cache.bmp');
    } else {
      $image->Read($path . $file_name);
    }

    # Do Stuff
    $image->Modulate('saturation' => $percentage);

    # Write purity cache
    $image->Write($path . $file_without_ext . '_purity_cache.bmp') if ($use_purity_cache eq 'true');

    # Write actual file
    $image->Write($path . $file_without_ext . '.' . $extension);

    undef $image;
   }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Requires array of images with fully qualified path
#
#  AVI Audio/Video Interleave image file
#  AVS AVS X image file
#  BMP Microsoft Windows bitmap image file
#  CGM Computer Graphics Metafile requires ralcgm; read only
#  CMYK Raw cyan, magenta, yellow, and black samples set -size and -depth to specify the image width, height, and depth
#  DCM Digital Imaging and Communications in Medicine image file format read only
#  DCX ZSoft IBM PC multi-page Paintbrush file
#  DIB Microsoft Windows bitmap image file
#  DPX Digital Moving Picture Exchange
#  EPDF Encapsulated Portable Document Format
#  EPI Adobe Encapsulated PostScript Interchange format requires Ghostscript to read
#  EPS Adobe Encapsulated PostScript file requires Ghostscript to read
#  EPS2 Adobe Level II Encapsulated PostScript file requires Ghostscript to read
#  EPSF Adobe Encapsulated PostScript file requires Ghostscript to read
#  EPSI Adobe Encapsulated PostScript Interchange format requires Ghostscript to read
#  EPT Adobe Encapsulated PostScript Interchange format with TIFF preview requires Ghostscript to read
#  FAX Group 3
#  FIG TransFig image format requires TransFig
#  FITS Flexible Image Transport System
#  FPX FlashPix Format requires FlashPix SDK
#  GIF CompuServe graphics interchange format 8-bit color
#  GIF87 CompuServe graphics interchange format 8-bit color (version 87a)
#  GPLT Gnuplot plot files requires gnuplot3.5.tar.Z
#  GRADIENT Gradual passing from one shade to another specify the desired shading as the filename (e.g. gradient:red-blue
#  GRANITE Granite texture.
#  GRAY Raw gray samples set -size and -depth to specify the image width, height, and depth
#  HDF Hierarchical Data Format requires HDF4.1r2.tar.gz
#  HISTOGRAM Histogram of the image
#  HPGL HP-GL plotter language requires hp2xx-3.2.0.tar.gz
#  HTML Hypertext Markup Language with a client-side image map requires html2ps to read
#  ICO Microsoft icon read only
#  ICC International Color Consortium color profile To read, use -profile with convert
#  ILBM Amiga IFF
#  IPTC Newswire profile To read, use -profile with convert
#  JBIG Joint Bi-level Image experts Group file interchange format requires jbigkit-1.0.tar.gz
#  JP2 JPEG-2000 JP2 File Format Syntax requires jasper-1.500.0.zip
#  JPC JPEG-2000 Code Stream Syntax requires jasper-1.500.0.zip
#  JPEG Joint Photographic Experts Group JFIF format requires jpegsrc.v6b.tar.gz
#  LABEL text image format specify the desired text as the filename (e.g. label:This is a label
#  MAP colormap intensities and indices set -depth to set the sample size of the intensities; indices are 16-bit if colors > 256.
#  MAN Unix reference manual pages
#  MIFF Magick image file format
#  MNG Multiple-image Network Graphics requires libpng-1.02.tar.gz
#  MPEG  Motion Picture Experts Group file interchange format requires mpeg2vidcodec_v12.tar.gz
#  M2V  Motion Picture Experts Group file interchange format (version 2) requires mpeg2vidcodec_v12.tar.gz
#  MPC Magick Persistent Cache image file format
#  MTV MTV Raytracing image format
#  MVG Magick Vector Graphics.
#  NETSCAPE Netscape 216 color cube.
#  NULL NULL image useful for creating blank tiles with montage
#  OTB On-the-air Bitmap
#  PBM Portable bitmap format (black and white)
#  PCD Photo CD the maximum resolution written is 768x512 pixels
#  PCDS Photo CD decode with the sRGB color tables
#  PCL Page Control Language write only
#  PCX ZSoft IBM PC Paintbrush file
#  PDB Pilot Image Format read only
#  PDF Portable Document Format requires Ghostscript to read
#  PGM Portable graymap format (gray scale)
#  PICT Apple Macintosh QuickDraw/PICT file
#  PIX Alias/Wavefront RLE image format read only
#  PLASMA plasma fractal image. Specify the base color as the filename (e.g. plasma:blue-yellow). Use fractal to initialize to a random value (e.g. plasma:fractal
#  PNG Portable Network Graphics requires libpng-1.02.tar.gz
#  PNM Portable anymap use +compress to produce ASCII renditions
#  PPM Portable pixmap format (color)
#  PREVIEW show a preview an image enhancement, effect, or f/x specify the desired preview with the -preview option)
#  PRINT Send image to your computer printer
#  PS Adobe PostScript file requires Ghostscript to read
#  PSD  Adobe Photoshop bitmap file
#  PS2 Adobe Level II PostScript file requires Ghostscript to read
#  PS3 Adobe Level III PostScript file requires Ghostscript to read
#  PTIF Pyramid encoded TIFF requires tiff-v3.5.4.tar.gz
#  PWP  Seattle File Works multi-image file
#  P7 Xv's visual schnauzer format
#  RAD Radiance image file
#  RGB Raw red, green, and blue samples set -size and -depth to specify the image width, height, and depth
#  RGBA Raw red, green, blue, and matte samples set -size and -depth to specify the image width, height, and depth
#  RLA Alias/Wavefront image file read only
#  RLE Utah Run length encoded image file read only
#  SCAN Import image from a scanner device requires SANE Specify the device name and path as the filename (e.g. scan:mustek:/dev/scanner
#  SCT  Scitex Continuous Tone Picture image file
#  SFW  Seattle File Works image file
#  SGI Irix RGB image file
#  SHTML Hypertext Markup Language with a client-side image map write only
#  STEGANO Steganographic image use -size command line option to specify width, height, and offset of the steganographic image
#  SUN SUN Rasterfile
#  SVG  Scalable Vector Graphics requires libxml2-2.0.0; affine text transformations requires freetype2-current.tar.gz
#  TGA Truevision Targa image file
#  TIFF Tagged Image File Format requires tiff-v3.5.4.tar.gz
#  TILE Tile image with a texture read only
#  TIM PSX TIM file read only
#  TTF TrueType font file requires freetype-2-beta8.tar.gz
#  TXT Raw text file
#  UIL X-Motif UIL table
#  UYVY Interleaved YUV use -size command line option to specify width and height
#  VICAR   read only
#  VID Visual Image Directory
#  VIFF Khoros Visualization image file
#  WBMP Wireless bitmap image file support for uncompressed monochrome only
#  WIN Select image from or display image to your computer screen
#  WPG Word Perfect Graphic
#  WMF Windows Meta File Requires libwmf.  By default, renders WMF files to the size specified by the metafile header. Use the -density option to adjust the output resolution, and thereby adjust the ouput size. The default output resolution is 72DPI so '-density 144' results in an image twice as large as the default.
#  X Select image from or display image to your X server screen
#  XC Constant image of X server color set -size and -depth to specify the image width, height, and depth
#  XBM X Windows system bitmap, black and white only
#  XPM X Windows system pixmap file (color)
#  XWD X Windows system window dump file (color)
#  YUV CCIR 601 4:1:1 file use -size command line option to specify width and height
#
#-----------------------------------------------------------------------------#
sub image_convert_from_array {
  my ($use_purity_cache, $new_type, @images) = @_;
  my ($image, $background, $file_name, $path);
  my ($extension, $file_without_ext);

  use Image::Magick;

  foreach (@images){
    ($file_name, $path) = &shazam::io_split_path_and_file($_);
    ($extension, $file_without_ext) = &shazam::io_split_filename_and_exsension($file_name);

    $image = Image::Magick->new;

    # If a purity cache image exists open it, if not open the actual
    if ($use_purity_cache eq 'true' && -e $path . $file_without_ext . '_purity_cache.bmp'){
      $image->Read($path . $file_without_ext . '_purity_cache.bmp');
    } else {
      $image->Read($path . $file_name);
    }

    # Do Stuff
    #$image->Resize('geometry' => $size);

    # Write purity cache
    $image->Write($path . $file_without_ext . '_purity_cache.bmp') if ($use_purity_cache eq 'true');

    # Write actual file
    $image->Write($path . $file_without_ext . '.' . $new_type);

    undef $image;
   }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub image_convert_to_purity_cache_name {
  my ($file_name) = @_;
  my ($extension, $file_without_ext) = &shazam::io_split_filename_and_exsension($file_name);
  return $file_without_ext . '_purity_cache.bmp';
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub image_crop_from_array {
  my ($use_purity_cache, $rectangle_width, $rectangle_height, $position_x, $position_y, @images) = @_;
  my ($image, $background, $file_name, $path);
  my ($extension, $file_without_ext);

  use Image::Magick;

  foreach (@images){
    ($file_name, $path) = &shazam::io_split_path_and_file($_);
    ($extension, $file_without_ext) = &shazam::io_split_filename_and_exsension($file_name);

    $image = Image::Magick->new;

    # If a purity cache image exists open it, if not open the actual
    if ($use_purity_cache eq 'true' && -e $path . $file_without_ext . '_purity_cache.bmp'){
      $image->Read($path . $file_without_ext . '_purity_cache.bmp');
    } else {
      $image->Read($path . $file_name);
    }

    # Do Stuff
    $image->Crop('width' => $rectangle_width, 'height' => $rectangle_height, 'x' => $position_x, 'y' => $position_y);

    # Write purity cache
    $image->Write($path . $file_without_ext . '_purity_cache.bmp') if ($use_purity_cache eq 'true');

    # Write actual file
    $image->Write($path . $file_without_ext . '.' . $extension);

    undef $image;
   }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# create a mirror image by reflecting the image scanlines in the
# vertical direction
#-----------------------------------------------------------------------------#
sub image_flip_from_array {
  my ($use_purity_cache, @images) = @_;
  my ($image, $background, $file_name, $path);
  my ($extension, $file_without_ext);

  use Image::Magick;

  foreach (@images){
    ($file_name, $path) = &shazam::io_split_path_and_file($_);
    ($extension, $file_without_ext) = &shazam::io_split_filename_and_exsension($file_name) if ($use_purity_cache eq 'true');

    $image = Image::Magick->new;

    # If a purity cache image exists open it, if not open the actual
    if ($use_purity_cache eq 'true' && -e $path . $file_without_ext . '_purity_cache.bmp'){
      $image->Read($path . $file_without_ext . '_purity_cache.bmp');
    } else {
      $image->Read($path . $file_name);
    }

    # Do Stuff
    $image->Flip;

    # Write purity cache
    $image->Write($path . $file_without_ext . '_purity_cache.bmp') if ($use_purity_cache eq 'true');

    # Write actual file
    $image->Write($path . $file_without_ext . '.' . $extension);

    undef $image;
   }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# create a mirror image by reflecting the image scanlines in the
# horizontal direction
#-----------------------------------------------------------------------------#
sub image_flop_from_array {
  my ($use_purity_cache, @images) = @_;
  my ($image, $background, $file_name, $path);
  my ($extension, $file_without_ext);

  use Image::Magick;

  foreach (@images){
    ($file_name, $path) = &shazam::io_split_path_and_file($_);
    ($extension, $file_without_ext) = &shazam::io_split_filename_and_exsension($file_name) if ($use_purity_cache eq 'true');

    $image = Image::Magick->new;

    # If a purity cache image exists open it, if not open the actual
    if ($use_purity_cache eq 'true' && -e $path . $file_without_ext . '_purity_cache.bmp'){
      $image->Read($path . $file_without_ext . '_purity_cache.bmp');
    } else {
      $image->Read($path . $file_name);
    }

    # Do Stuff
    $image->Flop;

    # Write purity cache
    $image->Write($path . $file_without_ext . '_purity_cache.bmp') if ($use_purity_cache eq 'true');

    # Write actual file
    $image->Write($path . $file_without_ext . '.' . $extension);

    undef $image;
   }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# base-columns   integer   base image width (before transformations)
# base-filename  string    base image filename (before transformations)
# base-rows      integer   base image height (before transformations)
# class          {Direct, Pseudo} image class
# colors         integer   number of unique colors in the image
# comment        string    get the image comment
# columns        integer   image width
# depth          integer   image depth
# directory      string    tile names from within an image montage
# elapsed-time   double    elapsed time in seconds since the image was created
# error          double    the mean error per pixel computed with methods Compare() or Quantize()
# filesize       integer   number of bytes of the image on disk
# format         string    get the descriptive image format
# geometry       string    image geometry
# height         integer   the number of rows or height of an image
# id             integer   ImageMagick registry id
# label          string    image label
# maximum-error  double    the normalized max error per pixel computed with methods Compare() or Quantize()
# mean-error     double    the normalized mean error per pixel computed with methods Compare() or Quantize()
# montage        geometry  tile size and offset within an image montage
# rows           integer   the number of rows or height of an image
# signature      string    SHA-256 message digest associated with the image pixel stream
# taint          {True, False} True if the image has been modified
# user-time      double    user time in seconds since the image was created
# width          integer   the number of columns or width of an image
# x-resolution   integer   x resolution of the image
# y-resolution   integer   y resolution of the image
#
#-----------------------------------------------------------------------------#
sub image_get_image_info {
  my ($path_to_image, @info) = @_;
  my (@return_info, $image, $file_name, $path);

  use Image::Magick;

  ($file_name, $path) = &shazam::io_split_path_and_file($_);

  $image = new Image::Magick;
  $image->Read($path_to_image);

  foreach (@info) {
    push(@return_info, $image->Get($_));
  }

  undef $image;

  return @return_info;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Requires array of images with fully qualified path
#-----------------------------------------------------------------------------#
sub image_make_thumbnails_from_array {
  my ($thumb_prefix, @images) = @_;
  my ($image, $background, $file_name, $path);

  use Image::Magick;

  foreach (@images){

    ($file_name, $path) = &shazam::io_split_path_and_file($_);

    $image = Image::Magick->new;
    $background = Image::Magick->new;

    $background->Set(size=>'100x100');
    $background->ReadImage('xc:white');

    $image->Read($path . $file_name);
    $image->Scale(geometry =>'90x90');

    $background->Composite(image => $image, gravity => 'center');
    $background->Write($path . $thumb_prefix . $file_name);

     undef $image;
     undef $background;
   }

}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# transform image to span the full range of color values
#-----------------------------------------------------------------------------#
sub image_normalize_from_array {
  my ($use_purity_cache, @images) = @_;
  my ($image, $background, $file_name, $path);
  my ($extension, $file_without_ext);

  use Image::Magick;

  foreach (@images){
    ($file_name, $path) = &shazam::io_split_path_and_file($_);
    ($extension, $file_without_ext) = &shazam::io_split_filename_and_exsension($file_name) if ($use_purity_cache eq 'true');

    $image = Image::Magick->new;

    # If a purity cache image exists open it, if not open the actual
    if ($use_purity_cache eq 'true' && -e $path . $file_without_ext . '_purity_cache.bmp'){
      $image->Read($path . $file_without_ext . '_purity_cache.bmp');
    } else {
      $image->Read($path . $file_name);
    }

    # Do Stuff
    $image->Normalize;

    # Write purity cache
    $image->Write($path . $file_without_ext . '_purity_cache.bmp') if ($use_purity_cache eq 'true');

    # Write actual file
    $image->Write($path . $file_without_ext . '.' . $extension);

    undef $image;
   }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Requires array of images with fully qualified path
# takes pixel size or percentage
#-----------------------------------------------------------------------------#
sub image_resize_from_array {
  my ($use_purity_cache, $size, @images) = @_;
  my ($image, $background, $file_name, $path);
  my ($extension, $file_without_ext);

  use Image::Magick;

  foreach (@images){
    ($file_name, $path) = &shazam::io_split_path_and_file($_);
    ($extension, $file_without_ext) = &shazam::io_split_filename_and_exsension($file_name);

    $image = Image::Magick->new;

    # If a purity cache image exists open it, if not open the actual
    if ($use_purity_cache eq 'true' && -e $path . $file_without_ext . '_purity_cache.bmp'){
      $image->Read($path . $file_without_ext . '_purity_cache.bmp');
    } else {
      $image->Read($path . $file_name);
    }

    # Do Stuff
    $image->Resize('geometry' => $size);

    # Write purity cache
    $image->Write($path . $file_without_ext . '_purity_cache.bmp') if ($use_purity_cache eq 'true');

    # Write actual file
    $image->Write($path . $file_without_ext . '.' . $extension);

    undef $image;
   }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Requires array of images with fully qualified path
# takes pixel size or percentage
#-----------------------------------------------------------------------------#
sub image_rotate_from_array {
  my ($use_purity_cache, $degrees, @images) = @_;
  my ($image, $background, $file_name, $path);
  my ($extension, $file_without_ext);

  use Image::Magick;

  foreach (@images){
    ($file_name, $path) = &shazam::io_split_path_and_file($_);
    ($extension, $file_without_ext) = &shazam::io_split_filename_and_exsension($file_name);

    $image = Image::Magick->new;

    # If a purity cache image exists open it, if not open the actual
    if ($use_purity_cache eq 'true' && -e $path . $file_without_ext . '_purity_cache.bmp'){
      $image->Read($path . $file_without_ext . '_purity_cache.bmp');
    } else {
      $image->Read($path . $file_name);
    }

    # Do Stuff
    $image->Rotate('degrees' => $degrees);

    # Write purity cache
    $image->Write($path . $file_without_ext . '_purity_cache.bmp') if ($use_purity_cache eq 'true');

    # Write actual file
    $image->Write($path . $file_without_ext . '.' . $extension);

    undef $image;
   }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_archive_unzip{
  my ($path_to_zip_file, $destination_directory) = @_;
  
  use Archive::Zip;
  my $zip = Archive::Zip->new($path_to_zip_file);

  foreach my $member ($zip->members) {
    next if $member->isDirectory;
    (my $extractName = $member->fileName) =~ s{.*/}{};
    $member->extractToFileNamed("$destination_directory/$extractName");
  }

}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_array_to_file{
  my ($path, @data) = @_;

  open(FILE, ">$path") or &shazam::cgi_error("$!", "[proio_array_to_file]: The specified file could not be written on this machine at the specified name and path: $path");
  foreach (@data) { print FILE $_ . "\n"; }
  close(FILE);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_copy_directory {
   my ($directory_to_copy, $copy_to) = @_;

   use File::Copy;

   my (@dirs, @files);

   &shazam::io_smart_force_path($copy_to);

   @dirs = &shazam::io_get_recursive_directory_list($directory_to_copy, 'virtual');
   @files = &shazam::io_get_recursive_file_list($directory_to_copy, 'virtual');

   foreach (@dirs) { &shazam::io_smart_force_path($copy_to . $_) }
   foreach (@files) { copy($directory_to_copy . $_,  $copy_to . $_) }

}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_create_file {
  my($path) = @_;
  my($file, $pathonly) = &shazam::io_split_path_and_file($path);

  if (!-e $path) {
    &shazam::io_smart_force_path($pathonly);

    # Save the new blank file
    open(FILE, ">$path") or &shazam::cgi_error("$!", "[proio_create_file]: The specified file could not be created on this machine at the specified name and path.<br><br>$path");
    close(FILE);
  }


}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_delete_files_with_prefix {
  my ($prefix, @files) = @_;
  my ($path, $filename);

  foreach (@files) {
    ($filename, $path) = &shazam::io_split_path_and_file($_);
    if ((-d $path) && (-e $path . $filename)){
      unlink($path . $filename) if ($filename =~ m/^$prefix/);
    }
  }

}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_drop_all_files_except_jpg_gif_png {
  my($array_ref) = @_;
  my ($file_name, $path, @new_array);

  foreach (@$array_ref) {
   # ($file_name, $path) = &shazam::io_split_path_and_file($_);
    push(@new_array, $_) if ($_ =~ /\.(jpg|jpeg|gif|png)$/i);
  }
  return @new_array;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_expand_from_storage_lf {
  my $temp = $_[0];
  $temp =~ s/\[CRLF\]/\n/g;
  $temp =~ s/\[PIPE\]/|/g; # Replaces pipes and crlf symbols in text.
  return $temp;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# @deleted_files = &shazam::io_expire_files( $path, 7200 );
# The second parm is options and if not passed will default to 2 hours (7200 seconds)
#########---------------------------------------------------------
## 011 ##                    Expire Files
#########---------------------------------------------------------
#
#  0 dev      device number of filesystem
#  1 ino      inode number
#  2 mode     file mode  (type and permissions)
#  3 nlink    number of (hard) links to the file
#  4 uid      numeric user ID of file's owner
#  5 gid      numeric group ID of file's owner
#  6 rdev     the device identifier (special files only)
#  7 size     total size of file, in bytes
#  8 atime    last access time since the epoch
#  9 mtime    last modify time since the epoch
# 10 ctime    inode change time (NOT creation time!) since the epoch
# 11 blksize  preferred block size for file system I/O
# 12 blocks   actual number of blocks allocated
#-----------------------------------------------------------------------------#
sub io_expire_files {

  my $path = $_[0];
  my $seconds_old = $_[1];
  my @files = &shazam::io_get_file_list( $path, "none" );
  my $file;
  my @deleted_files;

  # If no expire time is passed set to default of 2 hours (7200 seconds)
  if (!$seconds_old) { $seconds_old = 7200; }

  FILE: foreach $file (@files) {
    if (  ( stat("$path$file") )[9] + $seconds_old < time  ) {
      unlink ("$path$file") or &shazam::cgi_error("$!", "[proio_expire_files]: $!");  # Delete the file if it is too old.
      push(@deleted_files, $file);
    }
  }
  return @deleted_files;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_file_append_to_logfile{
  my ($path_to_log, $data) = @_;

  open(LOG, ">>$path_to_log") || die "Can't open Log File: $path_to_log\n";
  print LOG "$data\n";
  close(LOG);

}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_file_to_array{
  my $path = $_[0];
  my @build;

  open(FILE, "<$path") or &shazam::cgi_error("$!", "[proio_file_to_array]: The specified file could not be written on this machine at the specified name and path: $path");
  while ( <FILE> ) {
    chomp;
    push(@build, $_);
  }
  close(FILE);
  return @build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_flatten_for_storage {
  my $temp = shift; # dump the whole thing in
  $temp =~ s/\r//g;
  $temp =~ s/\n/[CRLF]/g;
  $temp =~ s/\|/[PIPE]/g;   # Remove pipe symbols in text.
  return $temp;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# As file permissions are not always an accurate indicator of actual reading
# and writing capabilities (especially under windows), this function attempts
# to write a zero-length test file to disk, and then erases the file and
# returns the result of the test.
#-----------------------------------------------------------------------------#

sub io_force_file_write_test {
  my ($directory) = @_;
  return undef unless (-d $directory);

  my $filename = '';
  $filename = &utils_random_alphanumeric(8) while (-e "$directory$filename");
  my $file = "$directory$filename";

  eval q^
    open(FILE, ">$file");
    print FILE 'test';
    close(FILE);
    die unless (-e $file);
    unlink($file);
  ^;
  
  return ($@) ? 0 : 1;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_force_path {
  my ($path, $permissions) = @_;
  $permissions = 0704 if ($permissions eq '');
  use File::Path;
  mkpath([$path], 0, $permissions);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Returns an array of directories.
# @example = &shazam::io_get_directory_list( $path, "path option" );
#
# Path Options: (none, full)
#
# 'none' returns a list of only directories with no preceeding path
# 'full' returns a list of directories with the full preceeding path
#
# Note: If Path Option is not defined default is NONE
#
#-----------------------------------------------------------------------------#
sub io_get_directory_list {

  my($path, $include_path) = @_;

  my ($item, @items);
  my @build = ();

  opendir(CORE, $path ) || &shazam::cgi_error("$!", "[sub io_get_directory_list]: $path - $!");
  @items = readdir(CORE);
  closedir(CORE);

  foreach $item (@items) {
    if ( -d $path . "$item" ) {        # make sure this IS a directory
      next if $item =~ /^\.\.?$/;      # weed out all .. directories
      #next if $item =~ /_vti_cnf/i;   # weed out front page directories
      if (defined $include_path){
        push(@build, $path . $item . "/") if($include_path eq "full");
        push(@build, $item) if($include_path eq "none");
      } else {
        push(@build, $item);
      }
    }
  }
  return @build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Returns an array of filenames.
# @example = &shazam::io_get_file_list( $path, "path option" );
#
# Path Options: (none, full)
#
# 'none' returns a list of only filenames with no preceeding path
# 'full' returns a list of files with the full preceeding path
#
# Note: If Path Option is not defined default is NONE
#
#-----------------------------------------------------------------------------#
sub io_get_file_list {

  my ($path, $include_path) = @_;

  my ($item, @items);
  my @build = ();

  if (-d $path) {
    opendir(CORE, $path ) || &shazam::cgi_error("$!", "[sub io_get_file_list]: $!");
    @items = readdir(CORE);
    closedir(CORE);

    foreach $item (@items) {
      if ( -f $path . "$item" ) {   # make sure this is a file
        if (defined $include_path){
          push(@build, $item) if($include_path eq "none");
          push(@build, $path . $item) if($include_path eq "full");
        } else {
          push(@build, $item);
        }
      }
    }
    return @build;

  } else {
    return '';
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_get_file_size_in_auto_from_array{
  my(@files) = @_;
  my(%results, $total, $total_bytes, $bytes);

  foreach (@files){
    next if (!-e $_);
    $bytes = (stat($_))[7];
    $total_bytes += $bytes;
    $results{$_} = &shazam::utils_convert_bytes_to_optimal_unit($bytes);
  }

  $total = &shazam::utils_convert_bytes_to_optimal_unit($total_bytes);
  return ($total, %results);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Returns a list of all files and a list unique extions
#-----------------------------------------------------------------------------#
sub io_get_filelist_and_unique_exts {
  my ($path) = @_;
  my @files = &shazam::io_get_file_list($path, 'none') if (-d $path);
  my(%ext_hash, @all_filenames, @unique_ext);

  foreach (@files){
    my ($ext, $filename) = &shazam::io_split_filename_and_exsension($_);
     push(@all_filenames, $_);
     $ext = lc($ext);
     $ext_hash{$ext} = '';
  }

  foreach (keys %ext_hash) { push(@unique_ext, $_) }

  return (\@all_filenames, \@unique_ext);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# results
#   full - Full Path
#   none - No Path, File Names only
#-----------------------------------------------------------------------------#
sub io_get_files_by_extensions {
  my($path, $results, @extensions) = @_;
  my (@files, $file, @matching_files, $extension);

  $results = 'none' if ($results ne 'full');

  @files = &shazam::io_get_file_list($path, $results);
  foreach $file (@files) {
    foreach $extension (@extensions) {
      if ($file =~ /\.$extension$/i){
        push(@matching_files, $file);
      }
    }
  }
  return @matching_files;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Will search for the next incremental ALPHA filename starting with the
# lowercase letter 'a' in the specified path. The extention is optional.
#
# $example = &shazam::io_get_next_alpha_filename($path, "ext");
#
#-----------------------------------------------------------------------------#
sub io_get_next_alpha_filename {
  my ($path, $ext) = @_;
  my $record_key = "a";

  $ext = "." . $ext;
  while (-e $path . "$record_key$ext") {
    $record_key++;
  }
  return $record_key;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Will search for the next incremental NUMERIC filename starting with the
# number '1' in the specified path. The extention is optional.
#
# $example = &shazam::io_get_next_numeric_filename($path, "ext");
#
#-----------------------------------------------------------------------------#
sub io_get_next_numeric_filename {
  my ($path, $ext) = @_;
  my $record_key = "1";

  $ext = "." . $ext;
  while (-e $path . "$record_key$ext") {
    $record_key++;
  }
  return $record_key;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Returns an array of directories recursivly pulled from specified directory.
# @example = &shazam::io_get_directory_list( $path, "path option" );
#
# Path Options: (virtual, full)
#
# 'virtual' returns a list of directories with path starting at path specified
#    'full' returns a list of directories with the full preceeding path
#
# Note: If Path Option is not defined default is FULL
#
#-----------------------------------------------------------------------------#
sub io_get_recursive_directory_list {

  my ($path, $path_options) = @_;
  my @to_be_processed;
  my @master_list;
  my $current_dir;

  @to_be_processed = &shazam::io_get_directory_list($path, "full");

  while (@to_be_processed){
    $current_dir = pop(@to_be_processed);
    push ( @to_be_processed, &shazam::io_get_directory_list($current_dir, "full") );
    push (@master_list, $current_dir);
  }

  if ($path_options eq "virtual"){
    foreach(@master_list){$_ =~ s/$path//;}
    return @master_list;
  } else {
    return @master_list;
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Returns an array of files recursivly pulled from specified directory.
# @example = &shazam::io_get_recursive_file_list( $path, "path option" );
#
# Path Options: (virtual, full)
#
# 'virtual' returns a list of filenames with path starting at path specified
#    'full' returns a list of files with the full preceeding path
#
# Note: If Path Option is not defined default is FULL
#
#-----------------------------------------------------------------------------#
sub io_get_recursive_file_list {

  my ($path, $path_options) = @_;
  my (@master_list, @to_be_processed);

  @to_be_processed = &shazam::io_get_recursive_directory_list($path);
  @master_list = &shazam::io_get_file_list($path, "full");

  while (@to_be_processed){
    push( @master_list, &shazam::io_get_file_list(pop(@to_be_processed), "full") );
  }

  if ($path_options eq "virtual"){
    foreach(@master_list){$_ =~ s/$path//;}
    return @master_list;
  } else {
    return @master_list;
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_get_uploaded_imagename_from_mac_or_pc_path {
  my ($path, $max_chars) = @_;
  my ($name, $extension);

  ($name, $extension) = split(/\./, lc($path));

  if ($name && $extension) {
    $name =~ s/\s/_/g; # Replace whitespace with _
    $name =~ s/-/_/g; # Replace - with _
    $name =~ s/\W//g;  # Delete all non AlphaNum Chars
    $name =~ s/_+/_/g; # Replace more than one _ with one _

    $name = substr($name, 0, $max_chars) if ($max_chars && length($name) > $max_chars); # Return a max ov 25 chars

    $name =~ s/^_*//; # Trim Leading _
    $name =~ s/_*$//; # Trim Trailing _

    $extension =~ s/jpeg/jpg/;
    if ($extension =~ m/(jpg|jpeg|gif|png)/) { $extension = $extension } else { $extension = '' }
  }



  if ($extension && $name) {
    return ($name . '.' . $extension, 'true');
  } else {
    return ('', 'false');
  }

}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_open_file {

  my $input = $_[0];
  my $file;

  if (-e $input){
    open (FILE, $input) || &shazam::cgi_error("$!", "[proio_open_file]: Fatal Error opening $input $!");
    local $/ = undef;
    $file = <FILE>;
    close(FILE);
  } else {
    &shazam::cgi_error("Error: File Not Found", "[proio_open_file]: Fatal Error opening file. The following file does not exist: <br><br><br>$input");
  }
  return $file;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes file or document path and drops last segment
#
# Examples:
#   "./"                returns  ''
#   "./foo/"            returns  './'
#   "c:/test"           returns  'c:/'
#   "c:/test/foobar"    returns  'c:/test/'
#   "c:/test/foobar/"   returns  'c:/test/'
#   "c:/test/file.ext"  returns  'c:/test/'
#-----------------------------------------------------------------------------#
sub io_path_drop_last_segment {

  my($process) = @_;
  my (@split, $work);

  @split = split( /\//, $process );
  pop(@split);
  if (@split > 0) {
    return join('/', @split) . '/';
  } else {
    return '';
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_path_first_segment {
  my @split = split( /\//, $_[0] );
  if (@split > 0){
    return $split[0];
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes file or document path and returns ending segment
#
# Examples:
#   "foobar"            returns  'foobar'
#   "c:/test"           returns  'test'
#   "c:/test/foobar"    returns  'foobar'
#   "c:/test/foobar/"   returns  'foobar'
#   "c:/test/file.ext"  returns  'file.ext'
#-----------------------------------------------------------------------------#
sub io_path_to_last_segment {

  my $process = $_[0];
  my @split;
  my $work;

  @split = split( /\//, $process );
    $work = pop(@split);
    return $work;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes file or document path and returns reversed segments Array
#
# Examples:
#   "c:/test"            returns   'test', 'c:'
#   "c:/test/foobar"     returns   'foobar', 'test', 'c:'
#   "c:/test/foobar/"    returns   'foobar', 'test', 'c:'
#   "c:/test/file.ext"   returns   'file.ext', 'test', 'c:'
#-----------------------------------------------------------------------------#
sub io_path_to_reversed_segments {
  my @split = split( /\//, $_[0] );
  @split = reverse @split;
  if (@split > 0){
    return @split;
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes file or document path and returns segments Array
#
# Examples:
#   "c:/test"            returns   'c:', 'test'
#   "c:/test/foobar"     returns   'c:', 'test', 'foobar'
#   "c:/test/foobar/"    returns   'c:', 'test', 'foobar'
#   "c:/test/file.ext"   returns   'c:', 'test', 'file.ext'
#-----------------------------------------------------------------------------#
sub io_path_to_segments {
  my @split = split( /\//, $_[0] );
  if (@split > 0){
    return @split;
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_prepend_path_to_files_array {
  my ($path, @files) = @_;
  my @new_array;
  foreach (@files){
    push(@new_array, $path . $_);
  }
  return @new_array;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_return_filesnames_with_prefix {
  my($prefix, $array_ref) = @_;
  my ($file_name, $path, @new_array);

  foreach (@$array_ref) {
    ($file_name, $path) = &shazam::io_split_path_and_file($_);
    push(@new_array, $path . $file_name) if ($file_name =~ /^$prefix/);
  }
  return @new_array;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_return_filesnames_without_prefix {
  my($prefix, $array_ref) = @_;
  my ($file_name, $path, @new_array);

  foreach (@$array_ref) {
    ($file_name, $path) = &shazam::io_split_path_and_file($_);
    push(@new_array, $path . $file_name) if ($file_name !~ /^$prefix/);
  }
  return @new_array;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_save_file_binary {
  my ($filename, $data) = @_;
  open (FH, ">$filename");
  binmode(FH); 
  print FH $data;
  close(FH);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_save_file_text {
  my ($filename, $data) = @_;
  open (FH, ">$filename");
  #binmode(IMAGE); 
  print FH $data;
  close(FH);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Default permission is 0711
# Only fires if the path does not exist
#-----------------------------------------------------------------------------#
sub io_smart_force_path {
  my ($path, $permissions) = @_;

  if (!-d $path) {
    $permissions = 0704 if ($permissions eq '');
    use File::Path;
    mkpath([$path], 0, $permissions);
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes path with filename and returns array of path/file and ext.
# Position 0: Extension
# Position 1: Filename
#-----------------------------------------------------------------------------#
sub io_split_filename_and_exsension {
  my $pathfile = $_[0];
  my @split;
  my @build;

  @split = split ( /\./, $pathfile );

  push( @build, pop(@split) );
  push( @build, join('.', @split) ) if (@split);

  return @build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes path with filename and returns array of path and filename.
# Position 0: Filename
# Position 1: Path
#-----------------------------------------------------------------------------#
sub io_split_path_and_file {
  my $pathfile = $_[0];
  my @split;
  my @build;

  @split = split ( /\//, $pathfile );

  push( @build, pop(@split) );
  push( @build, join('/', @split) . '/' ) if (@split);

  return @build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes file or document path and returns ending segment
#
# Examples:
#   "foobar"            returns  'foobar'
#   "c:/test"           returns  'test'
#   "c:\test\foobar"    returns  'foobar'
#   "test::foobar/"     returns  'foobar'
#   "c:/test/file.ext"  returns  'file.ext'
#-----------------------------------------------------------------------------#
sub io_unix_mac_pc_path_to_last_segment {

  my ($process) = @_;
  my @split;
  my $work;

  @split = split(/(\\|\/|::)/, $process);
    $work = pop(@split);
    return $work;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_write_file {
  my($path, $data, $bin_mode) = @_;
  my($file, $pathonly) = &shazam::io_split_path_and_file($path);
  
  &shazam::io_smart_force_path($pathonly) if (!-e $pathonly);
  
  # Save the new blank file
  open(FILE, ">$path") or &shazam::library_cgi_error("$!", "[io_write_file]: The specified file could not be written on this machine at the specified name and path.<br><br>$path");
  binmode(FILE) if ($bin_mode eq 'true');
  print FILE $data;
  close(FILE);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes data file and assigns a unique key derived from numerically or 
# alphabetically incremented key values. Returns specified values 
# when finished.
#
# Example:
# &shazam::keydb_assign_unique_key("c:/data.kdb", "1", "unique key");
#
# Array is configured like the Following:
# $path          - The full path to the data file
# $key start     - Where shall we start incrementing (1, a, i, etc...) 
# $return_option - Specifies what shall be returned
# $escape_html   - true or false
#   unique key (default)
#   data hash
#   
#-----------------------------------------------------------------------------#
sub keydb_assign_unique_key {

  my ($path, $key_start, $return_option, $escape_html) = @_;
  my %existing_data_file;
  my @split;
  my $new_file;

  #&shazam::keydb_create_file($path) if (!-e $path);
  
  use Fcntl qw(:DEFAULT :flock);
  use strict;

  # If the data file exists load in its values 
  if (-e $path) {
    sysopen(DB, $path, O_RDWR|O_CREAT) or &shazam::keydb_cgi_error("$!", "[keydb_assign_unique_key]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
    eval qq^flock(DB, LOCK_EX)^;
    while (<DB>) {
      chomp($_); # Remove LF 
      chop($_) if (substr($_, -1, 1) eq "\015"); # Remove windows CR if it exists
      @split = split(/\|/, $_);
      if ($split[0]) { $existing_data_file{$split[0]} = $split[1]; }
    }    
  } else {
    &shazam::keydb_cgi_error("$!", "[keydb_assign_unique_key]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
  }
  
  # Find Next Key
  while ( exists($existing_data_file{$key_start}) ) {
    $key_start++;
  }
  
  # Insert New key
  $existing_data_file{$key_start} = "";
  
  # Build the official new data file  
  foreach ( sort keys %existing_data_file ) { 
    $new_file .= "$_|$existing_data_file{$_}\012" if ($_);
  }
  chop($new_file); # remove the last \n
  
  # Save the new file
  seek(DB, 0, 0) or die "can't rewind: $!";
  truncate(DB, 0) or die "can't truncate: $!";
  print DB $new_file;
  eval qq^flock(DB, LOCK_UN)^;
  close(DB);

  &shazam::keydb_escape_html_in_hash_by_ref(\%existing_data_file)  if (($return_option eq 'data hash') && ($escape_html eq 'true'));
  
  if ($return_option eq "unique key" || $return_option eq "") {
    return $key_start;
  }
  if ($return_option eq "data hash") {
    return %existing_data_file;
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------# 
sub keydb_cgi_error{

  print "Content-type: text/html\n\n";
  print qq|
  
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
  <title>$_[0]</title>
</head>

<body bgcolor="#E2E2DC">
<p>&nbsp;</p>

<center><font size="+2" color="maroon"><b><blink>Critical Error in KeyDB.lib!</blink></b></font></center>
<center>
<table width="65%" border="3" bordercolor="black" cellpadding="15">
<tr>
  <td bgcolor="#DAD9B8">
  <b>$_[0]:</b>
  <br><br>
  $_[1]  <p>Please contact the system administrator and report this problem. If you could make a note of your browser, browser version, and what you were doing when this error occurred it will be helpful. We are sorry for any inconvenience this error may have caused you, and once we have been notified our engineers will look into it immediately. 
</td>
</tr>
</table>

</center>

</body>
</html>
|;
exit;  
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub keydb_create_file {
  
  my $path = $_[0];
  my ($filename, $path_to_file) = &shazam::keydb_split_path_and_file($path);

  if (!-d $path_to_file) {
    use File::Path;
    mkpath([$path_to_file], 0, 0704);
  }

  if (!-e $path) {
    open(FILE, ">$path") or &shazam::keydb_cgi_error("$!", "[keydb_create_file]: $path - The specified file could not be created on this machine at the specified name and path.<br><br>$path");
    close(FILE);
  }

}




#-----------------------------------------------------------------------------#
#     Version: 2.1
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes data file and increments a value numerically or alphabetically
# returning specified values when finished.
# Example:
# &shazam::keydb_inc_field("c:/data.kdb", "counter", "1", "inc value", 'escape html');
#
# Array is configured like the Following:
# $path          - The full path to the data file
# $key           - The Key that should have its value incremented
# $default_inc   - What will be inserted if inc field is blank (a,1,i,etc) 
# $return_option - Specifies what shall be returned
#   inc value
#   data hash (default)
# $escape_html - Specifies what shall be returned
#   true
#   false
#   
#-----------------------------------------------------------------------------#
sub keydb_dec_value {
  my ($path, $key, $default_dec, $return_option, $escape_html) = @_;
  my %existing_data_file;
  my @split;
  my $new_file;
  
  $default_dec = '1' if (!$default_dec);
  
  &shazam::keydb_create_file($path) if (!-e $path);
  
  use Fcntl qw(:DEFAULT :flock);
  use strict;

  # If the data file exists load in its values 
  if (-e $path) {
    sysopen(DB, $path, O_RDWR|O_CREAT) or &shazam::keydb_cgi_error("$!", "[keydb_inc_value]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
    eval qq^flock(DB, LOCK_EX)^;
    while (<DB>) {
      chomp($_); # Remove LF 
      chop($_) if (substr($_, -1, 1) eq "\015"); # Remove windows CR if it exists
      @split = split(/\|/, $_);
      if ($split[0]) { $existing_data_file{$split[0]} = $split[1]; }
    }    
  } else {
    &shazam::keydb_cgi_error("$!", "[keydb_inc_value]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
  }

  # Inc the value
  if ($existing_data_file{$key}) {
    $existing_data_file{$key}--;
  } else {
    $existing_data_file{$key} = $default_dec;
  }
  
  # Build the official new data file  
  foreach (sort keys %existing_data_file) { 
    $new_file .= "$_|$existing_data_file{$_}\012" if ($_);
  }
  chop($new_file); # remove the last \n
  
  # Save the new file
  seek(DB, 0, 0) or die "can't rewind: $!";
  truncate(DB, 0) or die "can't truncate: $!";
  print DB $new_file;
  eval qq^flock(DB, LOCK_UN)^;
  close(DB);

  &shazam::keydb_expand_hash_from_storage_by_ref(\%existing_data_file);
  &shazam::keydb_escape_html_in_hash_by_ref(\%existing_data_file)  if (($return_option eq 'data hash') && ($escape_html eq 'true'));
  
  if ($return_option eq "dec value") {
    return $existing_data_file{$key};
  }
  if ($return_option eq "data hash" || $return_option eq "") {
    return %existing_data_file;
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Will search all values for token and delete record if found
#-----------------------------------------------------------------------------#
sub keydb_delete_all_records_with_values_matching {

  my ($path, $match_string) = @_;
  my %existing_data_file;
  my ($new_file, @split);

  #&shazam::keydb_create_file($path) if (!-e $path);    

  use Fcntl qw(:DEFAULT :flock);
  use strict;

  # If the data file exists load in its values 
  if (-e $path) {
    sysopen(DB, $path, O_RDWR|O_CREAT) or &shazam::keydb_cgi_error("$!", "[keydb_search_and_replace_values_all]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
    eval qq^flock(DB, LOCK_EX)^;
    while (<DB>) {
      chomp($_); # Remove LF 
      chop($_) if (substr($_, -1, 1) eq "\015"); # Remove windows CR if it exists
      @split = split(/\|/, $_);
      if ($split[0]) { $existing_data_file{$split[0]} = $split[1]; }
    }    
  } else {
    &shazam::keydb_cgi_error("$!", "[keydb_search_and_replace_values_all]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
  }
 

  foreach ( sort keys %existing_data_file ) { 
    if ($_) {
      next if ($existing_data_file{$_} =~ m/\b$match_string\b/);
      $new_file .= "$_|$existing_data_file{$_}\012";
    }
  }


  # Save the new file
  seek(DB, 0, 0) or die "can't rewind: $!";
  truncate(DB, 0) or die "can't truncate: $!";
  print DB $new_file;
  eval qq^flock(DB, LOCK_UN)^;
  close(DB);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub keydb_delete_key {

  my ($path, $key) = @_;
  my %existing_data_file;
  my ($new_file, @split);

  #&shazam::keydb_create_file($path) if (!-e $path);    

  use Fcntl qw(:DEFAULT :flock);
  use strict;

  # If the data file exists load in its values 
  if (-e $path) {
    sysopen(DB, $path, O_RDWR|O_CREAT) or &shazam::keydb_cgi_error("$!", "[keydb_delete_key]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
    eval qq^flock(DB, LOCK_EX)^;
    while (<DB>) {
      chomp($_); # Remove LF 
      chop($_) if (substr($_, -1, 1) eq "\015"); # Remove windows CR if it exists
      @split = split(/\|/, $_);
      if ($split[0]) { $existing_data_file{$split[0]} = $split[1]; }
    }    
  } else {
    &shazam::keydb_cgi_error("$!", "[keydb_delete_key]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
  }
 
  # Delete the key   
  delete( $existing_data_file{$key}) if (exists($existing_data_file{$key}));  

  # Build the official new data file  
  foreach ( sort keys %existing_data_file ) { 
    $new_file .= "$_|$existing_data_file{$_}\012" if ($_);
  }
  chop($new_file); # remove the last \n
  
  # Save the new file
  seek(DB, 0, 0) or die "can't rewind: $!";
  truncate(DB, 0) or die "can't truncate: $!";
  print DB $new_file;
  eval qq^flock(DB, LOCK_UN)^;
  close(DB);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub keydb_delete_keys {

  my ($path, @keys) = @_;
  my %existing_data_file;
  my ($new_file, @split);

  #&shazam::keydb_create_file($path) if (!-e $path);    

  use Fcntl qw(:DEFAULT :flock);
  use strict;

  # If the data file exists load in its values 
  if (-e $path) {
    sysopen(DB, $path, O_RDWR|O_CREAT) or &shazam::keydb_cgi_error("$!", "[keydb_delete_keys]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
    eval qq^flock(DB, LOCK_EX)^;
    while (<DB>) {
      chomp($_); # Remove LF 
      chop($_) if (substr($_, -1, 1) eq "\015"); # Remove windows CR if it exists
      @split = split(/\|/, $_);
      if ($split[0]) { $existing_data_file{$split[0]} = $split[1]; }
    }    
  } else {
    &shazam::keydb_cgi_error("$!", "[keydb_delete_keys]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
  }
 
  # Delete the keys   
  foreach (@keys) {
    delete( $existing_data_file{$_} ) if (exists($existing_data_file{$_}));
  }  

  # Build the official new data file  
  foreach ( sort keys %existing_data_file ) { 
      $new_file .= "$_|$existing_data_file{$_}\012" if ($_);
  }
  chop($new_file); # remove the last \n

  # Save the new file
  seek(DB, 0, 0) or die "can't rewind: $!";
  truncate(DB, 0) or die "can't truncate: $!";
  print DB $new_file;
  eval qq^flock(DB, LOCK_UN)^;
  close(DB);

  return %existing_data_file;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub keydb_escape_html {
  my $toencode = shift;
  $toencode=~s/&/&amp;/g;
  $toencode=~s/\"/&quot;/g; # "
  $toencode=~s/>/&gt;/g;
  $toencode=~s/</&lt;/g;
    
  $toencode=~s/\[/&#91;/g;
  $toencode=~s/\]/&#93;/g;
    
  return $toencode;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub keydb_escape_html_in_hash_by_ref {
  my ($hash_ref) = @_;
  foreach (keys %$hash_ref) {
    $$hash_ref{$_} =~ s/&/&amp;/g;
    $$hash_ref{$_} =~ s/\"/&quot;/g; # "
    $$hash_ref{$_} =~ s/>/&gt;/g;
    $$hash_ref{$_} =~ s/</&lt;/g;

    $$hash_ref{$_} =~ s/\[/&#91;/g;
    $$hash_ref{$_} =~ s/\]/&#93;/g;
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub keydb_expand_from_storage {
  my $temp = $_[0]; 
  $temp =~ s/\[CRLF\]/\n/g;
  $temp =~ s/\[PIPE\]/|/g; # Replaces pipes and crlf symbols in text.
  return $temp;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub keydb_expand_hash_from_storage_by_ref {
  my ($hash_ref) = @_;
  foreach (keys %$hash_ref) {
    $$hash_ref{$_} =~ s/\[CRLF\]/\n/g;
    $$hash_ref{$_} =~ s/\[PIPE\]/|/g;
  } 
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub keydb_flatten_for_storage {
  my $temp = shift; # dump the whole thing in
  $temp =~ s/\r//g;
  $temp =~ s/\n/[CRLF]/g;
  $temp =~ s/\|/[PIPE]/g;   # Remove pipe symbols in text.
  return $temp;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub keydb_flatten_hash_for_storage_by_ref {
  my ($hash_ref) = @_;
  foreach (keys %$hash_ref) {
    $$hash_ref{$_} =~ s/\r//g;
    $$hash_ref{$_} =~ s/\n/[CRLF]/g;
    $$hash_ref{$_} =~ s/\|/[PIPE]/g;
  } 
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes data file and increments a value numerically or alphabetically
# returning specified values when finished.
# Example:
# &shazam::keydb_inc_field("c:/data.kdb", "counter", "1", "inc value", 'escape html');
#
# Array is configured like the Following:
# $path          - The full path to the data file
# $key           - The Key that should have its value incremented
# $default_inc   - What will be inserted if inc field is blank (a,1,i,etc) 
# $return_option - Specifies what shall be returned
#   inc value
#   data hash (default)
# $escape_html - Specifies what shall be returned
#   true
#   false
#   
#-----------------------------------------------------------------------------#
sub keydb_inc_value {
  my ($path, $key, $default_inc, $return_option, $escape_html) = @_;
  my %existing_data_file;
  my @split;
  my $new_file;
  
  $default_inc = '1' if (!$default_inc);
  
  &shazam::keydb_create_file($path) if (!-e $path);
  
  use Fcntl qw(:DEFAULT :flock);
  use strict;

  # If the data file exists load in its values 
  if (-e $path) {
    sysopen(DB, $path, O_RDWR|O_CREAT) or &shazam::keydb_cgi_error("$!", "[keydb_inc_value]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
    eval qq^flock(DB, LOCK_EX)^;
    while (<DB>) {
      chomp($_); # Remove LF 
      chop($_) if (substr($_, -1, 1) eq "\015"); # Remove windows CR if it exists
      @split = split(/\|/, $_);
      if ($split[0]) { $existing_data_file{$split[0]} = $split[1]; }
    }    
  } else {
    &shazam::keydb_cgi_error("$!", "[keydb_inc_value]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
  }

  # Inc the value
  if ($existing_data_file{$key}) {
    $existing_data_file{$key}++;
  } else {
    $existing_data_file{$key} = $default_inc;
  }
  
  # Build the official new data file  
  foreach (sort keys %existing_data_file) { 
    $new_file .= "$_|$existing_data_file{$_}\012" if ($_);
  }
  chop($new_file); # remove the last \n
  
  # Save the new file
  seek(DB, 0, 0) or die "can't rewind: $!";
  truncate(DB, 0) or die "can't truncate: $!";
  print DB $new_file;
  eval qq^flock(DB, LOCK_UN)^;
  close(DB);

  &shazam::keydb_expand_hash_from_storage_by_ref(\%existing_data_file);
  &shazam::keydb_escape_html_in_hash_by_ref(\%existing_data_file)  if (($return_option eq 'data hash') && ($escape_html eq 'true'));
  
  if ($return_option eq "inc value") {
    return $existing_data_file{$key};
  }
  if ($return_option eq "data hash" || $return_option eq "") {
    return %existing_data_file;
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# $example = &shazam::keydb_read_field($path . "file.ext", "fieldname");
#-----------------------------------------------------------------------------#
sub keydb_read_field {
  my ($file, $key, $escape_html) = @_;
  my %tmp;

  $escape_html = 'false' if (!$escape_html);

  %tmp = &shazam::keydb_read_file($file, $escape_html);  
  return $tmp{$key};
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub keydb_read_file {
  my ($file, $escape_html) = @_;  
  my %build;
  my @split;
  
  $escape_html = 'false' if (!$escape_html);

  use Fcntl qw(:DEFAULT :flock);
  use strict;

  #&shazam::keydb_create_file($file) if (!-e $file);
  
  if (-e $file) {
    sysopen(DB, $file, O_RDWR|O_CREAT) or &shazam::keydb_cgi_error("$!", "[keydb_read_file]: The data file requested could not be located on this machine at the specified name and path.<br><br>$file");
    eval qq^flock(DB, LOCK_SH)^;
    while (<DB>) {
      chomp($_); # Remove LF 
      chop($_) if (substr($_, -1, 1) eq "\015"); # Remove windows CR if it exists
      @split = split(/\|/, $_);
      if ($split[0]) { $build{$split[0]} = $split[1]; }  
    }
    
    eval qq^flock(DB, LOCK_UN)^; # Unlock
    close(DB);  

    &shazam::keydb_expand_hash_from_storage_by_ref(\%build);
    &shazam::keydb_escape_html_in_hash_by_ref(\%build) if ($escape_html eq 'true');

    return %build;
  } else {
    &shazam::keydb_cgi_error("$!", "[keydb_read_file]: The data file requested could not be located on this machine at the specified name and path.<br><br>$file");
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub keydb_s_create_file {
  
  my $path = $_[0];
  my ($filename, $path_to_file) = &shazam::keydb_split_path_and_file($path);


  if (!-d $path_to_file) {
    use File::Path;
    mkpath([$path_to_file], 0, 0711);
  }

  if (!-e $path) {
    my %hash;
    use Storable qw(lock_store);
    lock_store(\%hash, $path);
  }

}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes data and merges it with any existing data in the data file.
# Example:
# &shazam::keydb_s_write_merge_from_hash_ref("c:/data.kds", \%hash);
# 
# Return Value is Data Hash Reference containing all updated key value pairs
#
#-----------------------------------------------------------------------------#
sub keydb_s_delete_all_records_with_values_matching {
  my ($path, $match_string) = @_;
  my ($hash_ref_existing_data, $hash_ref_new_data);

  
  &shazam::keydb_s_create_file($path) if (!-e $path);
  
  use Fcntl qw(:DEFAULT :flock);
  use strict;

  if (-e $path) {

     use Storable qw(store_fd fd_retrieve);
     
     sysopen(DB, "$path", O_RDWR|O_CREAT, 0704) or die "can't open $path: $!";
     eval qq^flock(DB, LOCK_EX) or die "can't lock $path: $!"^;
     
     $hash_ref_existing_data = fd_retrieve(\*DB);
     
     foreach (keys %$hash_ref_existing_data) {
       delete($$hash_ref_existing_data{$_}) if ($$hash_ref_existing_data{$_} =~ m/\b$match_string\b/);
     }
     
     seek(DB, 0, 0) or die "can't rewind: $!";
     truncate(DB, 0) or die "can't truncate: $!";
   
     store_fd(\%$hash_ref_existing_data, \*DB) or die "can't store hash\n";
     
     eval qq^flock(DB, LOCK_UN)^;
     close(DB);
     
     return \%$hash_ref_existing_data;
 
  } else {
    &shazam::keydb_cgi_error("$!", "[keydb_s_delete_all_records_with_values_matching]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub keydb_s_delete_keys {
  my ($path, @keys) = @_;
  my ($hash_ref_existing_data);

 # &shazam::keydb_s_create_file($path) if (!-e $path);
  
  use Fcntl qw(:DEFAULT :flock);
  use strict;  
  
  if (-e $path) {

     use Storable qw(store_fd fd_retrieve);
     use Fcntl qw(:DEFAULT :flock);
     
     sysopen(DB, "$path", O_RDWR|O_CREAT, 0704) or die "can't open $path: $!";
     eval qq^flock(DB, LOCK_EX) or die "can't lock $path: $!"^;
     
     $hash_ref_existing_data = fd_retrieve(\*DB);
     
     # Delete the keys   
     foreach (@keys) {
       delete( $$hash_ref_existing_data{$_} ) if (exists($$hash_ref_existing_data{$_}));
     }  

     #foreach (keys %$hash_ref_new_data) { $$hash_ref_existing_data{$_} = $$hash_ref_new_data{$_}; }
     

     seek(DB, 0, 0) or die "can't rewind: $!";
     truncate(DB, 0) or die "can't truncate: $!";
   
     store_fd(\%$hash_ref_existing_data, \*DB) or die "can't store hash\n";
     
     eval qq^flock(DB, LOCK_UN)^;
     close(DB);
     
     return \%$hash_ref_existing_data;
 
  } else {
    &shazam::keydb_cgi_error("$!", "[s_delete_keys]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub keydb_s_read_file {

  my ($file, $escape_html) = @_;  
  my ($hash_ref);
  
  $escape_html = 'false' if (!$escape_html);

  #&shazam::keydb_s_create_file($file) if (!-e $file);
  use Fcntl qw(:DEFAULT :flock);
  use strict;  

  if (-e $file) {
              
    use Storable qw(fd_retrieve);
    use Fcntl qw(:DEFAULT :flock);
    open(DB, "< $file") or die "can't open $file: $!";
    eval qq^flock(DB, LOCK_SH) or die "can't lock $file: $!"^;
    $hash_ref = fd_retrieve(\*DB);
    eval qq^flock(DB, LOCK_UN)^;
    close(DB);
       
    &shazam::keydb_escape_html_in_hash_by_ref(\%$hash_ref)  if ($escape_html eq 'true');
               
    #&shazam::keydb_cgi_print_hash($hash_ref);

    return $hash_ref;
  } else {
    &shazam::keydb_cgi_error("$!", "[shazam::keydb_s_read_file]: $file - The data file requested could not be located on this machine at the specified name and path.<br><br>$file");
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes data and merges it with any existing data in the data file.
# Example:
# &shazam::keydb_s_write_merge_from_hash_ref("c:/data.kds", \%hash);
# 
# Return Value is Data Hash Reference containing all updated key value pairs
#
#-----------------------------------------------------------------------------#
sub keydb_s_write_merge_from_hash_ref {

  my ($path, $hash_ref_new_data) = @_;
  my ($hash_ref_existing_data);

  
  &shazam::keydb_s_create_file($path) if (!-e $path);
  
  use Fcntl qw(:DEFAULT :flock);
  use strict;

  if (-e $path) {

     use Storable qw(store_fd fd_retrieve);
     use Fcntl qw(:DEFAULT :flock);
     
     sysopen(DB, "$path", O_RDWR|O_CREAT, 0704) or die "can't open $path: $!";
     eval qq^flock(DB, LOCK_EX) or die "can't lock $path: $!"^;
     
     $hash_ref_existing_data = fd_retrieve(\*DB);
     foreach (keys %$hash_ref_new_data) { $$hash_ref_existing_data{$_} = $$hash_ref_new_data{$_}; }
     
     seek(DB, 0, 0) or die "can't rewind: $!";
     truncate(DB, 0) or die "can't truncate: $!";
   
     store_fd(\%$hash_ref_existing_data, \*DB) or die "can't store hash\n";
     
     eval qq^flock(DB, LOCK_UN)^;
     close(DB);
     
     return \%$hash_ref_existing_data;
 
  } else {
    &shazam::keydb_cgi_error("$!", "[s_write_merge_from_hash_ref]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes data and merges it with any existing data in the data file.
# Example:
# &shazam::keydb_s_write_over_from_hash_ref("c:/data.kds", \%hash);
# 
# Returns nothing
#
#-----------------------------------------------------------------------------#
sub keydb_s_write_over_from_hash_ref {

  my ($path, $hash_ref_new_data) = @_;
  my ($hash_ref_existing_data);
  
  &shazam::keydb_s_create_file($path) if (!-e $path);
  
  use Fcntl qw(:DEFAULT :flock);
  use strict;  

  if (-e $path) {

     use Storable qw(store_fd fd_retrieve);
     use Fcntl qw(:DEFAULT :flock);
     
     sysopen(DB, "$path", O_RDWR|O_CREAT, 0704) or die "can't open $path: $!";
     eval qq^flock(DB, LOCK_EX) or die "can't lock $path: $!"^;

     seek(DB, 0, 0) or die "can't rewind: $!";
     truncate(DB, 0) or die "can't truncate: $!";
   
     store_fd(\%$hash_ref_new_data, \*DB) or die "can't store hash\n";
     
     eval qq^flock(DB, LOCK_UN)^;
     close(DB);
 
  } else {
    &shazam::keydb_cgi_error("$!", "[s_write_over_from_hash_ref]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Will search all values for token and replace it with specified value
#-----------------------------------------------------------------------------#
sub keydb_search_and_replace_values_all {

  my ($path, $find, $replacement) = @_;
  my %existing_data_file;
  my ($new_file, @split);

  #&shazam::keydb_create_file($path) if (!-e $path);    

  use Fcntl qw(:DEFAULT :flock);
  use strict;

  # If the data file exists load in its values 
  if (-e $path) {
    sysopen(DB, $path, O_RDWR|O_CREAT) or &shazam::keydb_cgi_error("$!", "[keydb_search_and_replace_values_all]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
    eval qq^flock(DB, LOCK_EX)^;
    while (<DB>) {
      chomp($_); # Remove LF 
      chop($_) if (substr($_, -1, 1) eq "\015"); # Remove windows CR if it exists
      @split = split(/\|/, $_);
      if ($split[0]) { $existing_data_file{$split[0]} = $split[1]; }
    }    
  } else {
    &shazam::keydb_cgi_error("$!", "[keydb_search_and_replace_values_all]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
  }
 

  # Build the official new data file  
  foreach ( sort keys %existing_data_file ) { 
    if ($_) {
      $existing_data_file{$_} =~ s/$find/$replacement/g;
      $new_file .= "$_|$existing_data_file{$_}\012";
    }
  }
  chop($new_file); # remove the last \n
  
  # Save the new file
  seek(DB, 0, 0) or die "can't rewind: $!";
  truncate(DB, 0) or die "can't truncate: $!";
  print DB $new_file;
  eval qq^flock(DB, LOCK_UN)^;
  close(DB);
}




#-----------------------------------------------------------------------------#
#     Version: 2.1
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Will search values for keys specified in array for token and replace
# it with specified new value.
#-----------------------------------------------------------------------------#
sub keydb_search_and_replace_values_keys {

  my ($path, $find, $replacement, @keys) = @_;
  my %existing_data_file;
  my ($new_file, @split);

  #&shazam::keydb_create_file($path) if (!-e $path);    

  use Fcntl qw(:DEFAULT :flock);
  use strict;

  # If the data file exists load in its values 
  if (-e $path) {
    sysopen(DB, $path, O_RDWR|O_CREAT) or &shazam::keydb_cgi_error("$!", "[keydb_search_and_replace_values_keys]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
    eval qq^flock(DB, LOCK_EX)^;
    while (<DB>) {
      chomp($_); # Remove LF 
      chop($_) if (substr($_, -1, 1) eq "\015"); # Remove windows CR if it exists
      @split = split(/\|/, $_);
      if ($split[0]) { $existing_data_file{$split[0]} = $split[1]; }
    }    
  } else {
    &shazam::keydb_cgi_error("$!", "[keydb_search_and_replace_values_keys]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
  }

  # Replace values in these keys   
  foreach (@keys) {
    $existing_data_file{$_} =~ s/\b$find\b/$replacement/g;
  }  

  # Build the official new data file  
  foreach ( sort keys %existing_data_file ) { 
    if ($_) {
      $new_file .= "$_|$existing_data_file{$_}\012";
    }
  }
  chop($new_file); # remove the last \n
  
  # Save the new file
  seek(DB, 0, 0) or die "can't rewind: $!";
  truncate(DB, 0) or die "can't truncate: $!";
  print DB $new_file;
  eval qq^flock(DB, LOCK_UN)^;
  close(DB);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes path with filename and returns array of path and filename.
# Position 0: Filename
# Position 1: Path
#-----------------------------------------------------------------------------#
sub keydb_split_path_and_file {
  my $pathfile = $_[0];
  my @split;
  my @build;

  @split = split ( /\//, $pathfile );

  push( @build, pop(@split) );
  push( @build, join("/", @split) . "/" );
  
  return @build;
}




#-----------------------------------------------------------------------------#
#     Version: 2.1
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes data and merges it with any existing data in the data file.
# Example:
# &shazam::keydb_write_merge("c:/data.kdb", @array_of_data);
#
# Array is configured like the Following:
# Key1|Value1
# Key2|Value2
# etc...
# 
# Return Value is Data Hash containing all updated key value pairs
#
#-----------------------------------------------------------------------------#
sub keydb_write_merge {

  my ($path, @input) = @_;
  my %existing_data_file;
  my @split;
  my $new_file;
  
  &shazam::keydb_create_file($path) if (!-e $path);
  
  use Fcntl qw(:DEFAULT :flock);
  use strict;

  if (-e $path) {
    sysopen(DB, $path, O_RDWR|O_CREAT) or &shazam::keydb_cgi_error("$!", "[keydb_write_merge]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
    eval qq^flock(DB, LOCK_EX)^;
    while (<DB>) {
      chomp($_); # Remove LF 
      chop($_) if (substr($_, -1, 1) eq "\015"); # Remove windows CR if it exists
      @split = split(/\|/, $_);
      if ($split[0]) { $existing_data_file{$split[0]} = $split[1]; }
    }    
  } else {
    &shazam::keydb_cgi_error("$!", "[keydb_write_merge]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
  }
  
  # MERGE old data with new data
  @split = ();
  foreach (@input) {
    @split = split(/\|/, $_);
    if ($split[0]) {
      $existing_data_file{"$split[0]"} = &shazam::keydb_flatten_for_storage($split[1]);
    }
  }
  
  # Build the official new data file  
  foreach (sort keys %existing_data_file){ 
    $new_file .= "$_|$existing_data_file{$_}\012" if ($_);
  }
  chop($new_file); # remove the last \n
  
  # Save the new file
  seek(DB, 0, 0) or die "can't rewind: $!";
  truncate(DB, 0) or die "can't truncate: $!";
  print DB $new_file;
  eval qq^flock(DB, LOCK_UN)^;
  close(DB);

  return %existing_data_file;
}




#-----------------------------------------------------------------------------#
#     Version: 2.1
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes data and merges it with any existing data in the data file.
# Example:
# &shazam::keydb_write_merge("c:/data.kdb", \%hash, 'true', 'false');
# 
# Return Value is Data Hash containing all updated key value pairs
#
#-----------------------------------------------------------------------------#
sub keydb_write_merge_from_hash_ref {

  my ($path, $hash_ref, $escape_html_in_return_hash) = @_;
  my %existing_data_file;
  my ($new_file, @split);
  
  &shazam::keydb_create_file($path) if (!-e $path);
  
  use Fcntl qw(:DEFAULT :flock);
  use strict;

  if (-e $path) {
    sysopen(DB, $path, O_RDWR|O_CREAT) or &shazam::keydb_cgi_error("$!", "[keydb_write_merge]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
    eval qq^flock(DB, LOCK_EX)^;
    while (<DB>) {
      chomp($_); # Remove LF 
      chop($_) if (substr($_, -1, 1) eq "\015"); # Remove windows CR if it exists
      @split = split(/\|/, $_);
      if ($split[0]) { $existing_data_file{$split[0]} = $split[1]; }
    }    
  } else {
    &shazam::keydb_cgi_error("$!", "[keydb_write_merge]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
  }
  
  # MERGE old data with new data
  foreach (keys %$hash_ref) {
    $existing_data_file{$_} = $$hash_ref{$_}; 
  }
  
  &shazam::keydb_flatten_hash_for_storage_by_ref(\%existing_data_file);
  
  # Build the official new data file  
  foreach (sort keys %existing_data_file){ 
    $new_file .= $_ . '|' . $existing_data_file{$_} . "\012" if ($_);
  }
  chop($new_file); # remove the last \n
  
  # Save the new file
  seek(DB, 0, 0) or die "can't rewind: $!";
  truncate(DB, 0) or die "can't truncate: $!";
  print DB $new_file;
  eval qq^flock(DB, LOCK_UN)^;
  close(DB);

  &shazam::keydb_expand_hash_from_storage_by_ref(\%existing_data_file);
  &shazam::keydb_escape_html_in_hash_by_ref(\%existing_data_file) if ($escape_html_in_return_hash eq 'true');
  
  return %existing_data_file;
}




#-----------------------------------------------------------------------------#
#     Version: 2.1
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes datafile and overwrites it ONLY with any existing data in the
# data passed in.
#
# Example:
# &shazam::keydb_write_merge("c:/data.kdb", @array_of_data);
#
# Array is configured like the Following:
# Key1|Value1
# Key2|Value2
# etc...
#-----------------------------------------------------------------------------#
sub keydb_write_over {

  my ($path, @input) = @_;
  my @split;
  my %build;
  my $new_file;

  &shazam::keydb_create_file($path) if (!-e $path);
  
  use Fcntl qw(:DEFAULT :flock);
  use strict;

  # Write in data to hash for sort
  foreach (@input) {
    @split = split(/\|/, $_);
    if ($split[0]) {
      $build{"$split[0]"} = $split[1];     
    }
  }
  
  # Build the official new data file  
  foreach ( sort keys %build ) { 
    $new_file .= $_ . '|' . &shazam::keydb_flatten_for_storage( $build{$_} ) . "\012" if ($_);
  }
  chop($new_file); # remove the last \012
  
  # Save the new file
  sysopen(DB, $path, O_RDWR|O_CREAT) or &shazam::keydb_cgi_error("$!", "[keydb_write_over]: $path - The specified file could not be written on this machine at the specified name and path.");
  eval qq^flock(DB, LOCK_EX)^;
  seek(DB, 0, 0) or die "can't rewind: $!";
  truncate(DB, 0) or die "can't truncate: $!";
  print DB $new_file;
  eval qq^flock(DB, LOCK_UN)^;
  close(DB);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes datafile and overwrites it ONLY with any existing data in the
# data passed in.
#
# Example:
# &shazam::keydb_write_merge("c:/data.kdb", \%hash);
#
#-----------------------------------------------------------------------------#
sub keydb_write_over_from_hash_ref{

  my ($path, $hash_ref) = @_;
  my @split;
  my $new_file;
  my $tmp;

  &shazam::keydb_create_file($path) if (!-e $path);
  
  use Fcntl qw(:DEFAULT :flock);
  use strict;

  # Build the official new data file  
  foreach (sort keys %$hash_ref) { 
      $new_file .= $_ . '|' . &shazam::keydb_flatten_for_storage( $$hash_ref{$_} ) . "\012" if ($_);
  }
  chop($new_file); # remove the last \012
  
  # Save the new file
  sysopen(DB, $path, O_RDWR|O_CREAT) or &shazam::keydb_cgi_error("$!", "[keydb_write_over]: $path - The specified file could not be written on this machine at the specified name and path.");
  eval qq^flock(DB, LOCK_EX)^;
  seek(DB, 0, 0) or die "can't rewind: $!";
  truncate(DB, 0) or die "can't truncate: $!";
  print DB $new_file;
  eval qq^flock(DB, LOCK_UN)^;
  close(DB);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub net_get_data_from_url {
  my ($url) = @_;
  
  use LWP::Simple;
  my $data = get($url);

  return $data;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub net_sendmail_advanced {
  my($mail_server, $auth_user, $auth_pass, $from, $to, $header_info_hash_ref, $body) = @_;

  my %header_info = %$header_info_hash_ref;
    
  $header_info{'To'} = $to if (!exists $header_info{'To'});
  $header_info{'From'} = $from if (!exists $header_info{'From'});

  my $data;
  foreach (keys %header_info) {
    $data .= "$_: $header_info{$_}\n";
  }
  $data .= "\n$body";

  use Net::SMTP;
  my $smtp = Net::SMTP->new($mail_server);
  $smtp->auth($auth_user, $auth_pass) if ($auth_user ne '');

  die "Couldn't connect to server" unless $smtp;

  $smtp->mail($from);
  foreach ( split(/;/, $to) ) { $smtp->to($_) }
  $smtp->data();
  $smtp->datasend($data);
  $smtp->dataend();
  $smtp->quit;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub net_sendmail_basic{
  my($mail_server, $from, $to, $fake_from, $fake_to, $subject, $text) = @_;

  use Net::SMTP;
  my $smtp = Net::SMTP->new($mail_server);
  
  # die "Couldn't connect to server" unless $smtp;
  if ($smtp) {
     $fake_from = $from if ($fake_from eq '');
     $fake_to = $from if ($fake_to eq '');

     $smtp->mail($from); # Real Address of Sender
     $smtp->to($to);     # Real Address of to
     $smtp->data();
     $smtp->datasend('From: ' . $fake_from . "\n") if ($fake_from ne '');
     $smtp->datasend('To: ' . $fake_to . "\n") if ($fake_to ne '');
     $smtp->datasend('Subject: ' . $subject . "\n\n") if ($subject ne '');
     $smtp->datasend("$text\n");
     $smtp->dataend();
     $smtp->quit;
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub net_sendmail_simple {
  my($mail_server, $auth_user, $auth_pass, $html_or_text, $from, $to, $subject, $body, $from_display, $to_display, @attachments) = @_;

  my %header_info;

  $header_info{'From'} = ($from_display eq '') ? $from : $from_display;
  $header_info{'To'} = ($to_display eq '') ? $_ : $to_display;
  $header_info{'Subject'} = $subject;
  $header_info{'Content-Type'} = ($html_or_text eq 'html') ? 'text/html' : 'text/plain';
  
  #####################################
  ##                                 ##
  ##  ATTACHMENT STUFF WILL GO HERE  ##
  ##                                 ##
  #####################################

  foreach ( split(/;/, $to) ) {
    &shazam::net_sendmail_advanced($mail_server, $auth_user, $auth_pass, $from, $_, \%header_info, $body);
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub p { return cgi_print(@_) }
sub cgi_print {
 my $input = shift;
 &shazam::cgi_print_string($input);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_array_to_csv {
  my ($seperator, @items) = @_;
  my ($build);

  foreach (@items) {
    $build .= $_ . $seperator if($_);
  }
  chop($build) if ($build);
  return $build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_build_delimited_sorted_list_from_array{
  my($delimiter, @array) = @_;
  my($build);
  foreach (sort @array){
    $build .= $_ . $delimiter if ($_ ne '');
  }
  $build =~ s/$delimiter$//;
  return $build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_build_name_first_last {
  my ($prefix, $fname, $mname, $lname, $suffix) = @_;
  my ($full_name, $formal_name);
  $full_name = &shazam::string_trim_ws($fname) . ' ' if ($fname);
  $full_name .= &shazam::string_trim_ws($mname) if ($mname);
  $full_name .= ' ' if ($mname && $lname);
  $full_name .= &shazam::string_trim_ws($lname);
  $formal_name = &shazam::string_trim_ws($prefix) . ' ' if ($prefix);
  $formal_name .= $full_name;
  $formal_name .= ', ' . &shazam::string_trim_ws($suffix) if ($suffix);
  $formal_name =~ s/ ,/,/;
  $formal_name =~ s/ +/ /g;
  return &shazam::string_trim_ws($formal_name);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_build_name_last_first{
  my ($fname, $mname, $lname) = @_;
  my ($full_name);
  $full_name = &shazam::string_trim_ws($lname) . ', ' if ($lname);
  $full_name .= &shazam::string_trim_ws($fname);
  $full_name .= ' ' . &shazam::string_trim_ws($mname) if ($mname);
  $full_name =~ s/ +/ /g;
  return &shazam::string_trim_ws($full_name);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_build_username_from_full_name{
  my ($fname, $mname, $lname, $org, $min_length, $max_length) = @_;
  my ($username);

  $min_length = '6' if ($min_length eq '');
  $max_length = '15' if ($min_length eq '');

  $username = substr(&shazam::string_trim_ws($fname), 0, 1) if ($fname ne '');
  $username .= substr(&shazam::string_trim_ws($mname), 0, 1) if ($mname ne '');
  $username .= substr(&shazam::string_trim_ws($lname), 0, 10) if ($lname ne '');
  $username .= substr(&shazam::string_trim_ws($org), 0, 10) if ($org ne '' && $fname eq '' && $mname eq '' && $lname eq '');
  $username =~ s/\W+//g;
  $username =~ s/-//g;

  # If it is too short make it min length
  if (length($username) < 6) {
    $username .= &shazam::utils_random_alphanumeric(6);
    $username = substr($username, 0, 6);
  }

  # If it is too long make it shorter
  if (length($username) > $max_length) {
    $username = substr($username, 0, $max_length);
  }

  $username = lc($username);

  return &shazam::string_trim_ws($username);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_char_to_char_in_array_ref {
  my ($find, $replace_with, $array_ref) = @_;
  foreach (@$array_ref) { $_ =~ s/$find/$replace_with/g; }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_count_substrs {
  my ($string_ref, $sub_string) = @_;
  my $count = 0;
  
  $count++ while $$string_ref =~ /$sub_string/g;  
  
  return $count;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Replace new lines with spaces
#-----------------------------------------------------------------------------#
sub string_cr_to_sp{

  my $core = shift;

  $core =~ s/\n/ /g;
  $core =~ s/\r/ /g;

  return $core;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_csv_to_array {
  my ($seperator, $csv_string) = @_;
  my @split_it = split(/$seperator/, $csv_string);
  return @split_it
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_do_replacements_from_hash_ref {
  my ($replacement_hash_ref, @string_refs) = @_;
  my $new_hash_ref = {};
  foreach (keys %$replacement_hash_ref) {
    my $key = $_;
    #$key =~ s/([\?\*\+\[\]\\\.])/\\$1/g;
    $new_hash_ref->{$key} = $replacement_hash_ref->{$_};
    #&shazam::p($_);
  }
  $replacement_hash_ref = $new_hash_ref;
  #&shazam::cgi_print_hash($replacement_hash_ref) if ($replacement_hash_ref->{'foo'});
  

  my $index;
  foreach (@string_refs) {
    if (! ( ref($_) ne 'SCALAR' || $$_ eq '' || ref($replacement_hash_ref) ne 'HASH' || keys(%$replacement_hash_ref) < 1 )) {
      foreach my $replace (keys %$replacement_hash_ref) {
        $$_ =~ s/\Q$replace\E/$replacement_hash_ref->{$replace}/g;
      }
    }
    #$$_ =~ s/\+/./g;
    $index++;
  }

}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_dynamic_returns{
  my($source_string, $if_empty, $if_not_empty_insert_before, $if_not_empty_insert_after) = @_;
  if ($source_string eq ''){
    return $if_empty;
  } else {
    return $if_not_empty_insert_before . $source_string . $if_not_empty_insert_after;
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes a string of text and returns unique words ARRAY
#-----------------------------------------------------------------------------#
sub string_extract_unique_words_and_numbers {

  my $process = shift;
  my @tmp;
  my %dup_remover;
  my $build;

  $process =~ s/\W+/./g;   # Replace any Non AlphaNumeric char with a .
  #$process =~ s/[0-9]/\./g; # replaces numbers with .
  $process =~ s/\.+/ /g;    # replaces 2 or more . with one.
  $process =~ tr/A-Z/a-z/;  # lowercase everything
  @tmp = split (/\s/, $process);

  # Send to hash one word perk key
  foreach (@tmp) { $dup_remover{$_} = ''; }

  # Build string from hash with no dups
  foreach (sort keys %dup_remover) { $build .= $_ . ' '; }
  chop($build); # Chop Off Last SPACE

  #Make sure there are no multiple spaces.
  $build =~ s/ +/ /g; # replaces 2 or more spaces with one.

  return $build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes a string of text and returns unique words ARRAY
#-----------------------------------------------------------------------------#
sub string_extract_unique_words_only {

  my $process = shift;
  my @tmp;
  my %dup_remover;
  my $build;

  $process =~ s/\W+/./g;   # Replace any Non AlphaNumeric char with a .
  $process =~ s/[0-9]/\./g; # replaces numbers with .
  $process =~ s/\.+/ /g;    # replaces 2 or more . with one.
  $process =~ tr/A-Z/a-z/;  # lowercase everything
  @tmp = split (/\s/, $process);

  # Send to hash one word perk key
  foreach (@tmp) { $dup_remover{$_} = ''; }

  # Build string from hash with no dups
  foreach (sort keys %dup_remover) { $build .= $_ . ' '; }
  chop($build); # Chop Off Last SPACE

  #Make sure there are no multiple spaces.
  $build =~ s/ +/ /g; # replaces 2 or more spaces with one.

  return $build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# %foo = &shazam::string_hash_cruncher_strict_alpahnum_only(\%hash, '25', 'true');
#-----------------------------------------------------------------------------#
sub string_hash_cruncher_strict_alpahnum_only{
  my($hash_ref, $max_chars, $trim) = @_;
  my(%new_hash, $work);

  # if it is passed in then Inc it bacause it is 0 based
  $max_chars++ if ($max_chars);

  foreach (keys %$hash_ref){
    $work = $$hash_ref{$_};
    $work =~ s/\s/_/g; # Replace whitespace with _
    $work =~ s/\W//g;  # Delete all non AlphaNum Chars
    $work =~ s/_+/_/g; # Replace more than one _ with one _
    $work =~ s/_/ /g;  # Replace all _ with space
    $work = substr($work, 0, $max_chars) if ($max_chars); # Return a max ov 25 chars
    $work = &shazam::string_trim_ws($work) if ($trim eq 'true');
    $new_hash{$_} = $work if ($work);
  }

  return %new_hash;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_is_valid_email_address{
  my ($mail) = @_;
                                                    #in form name@host
  return 'false' if ( $mail !~ /^[0-9a-zA-Z\.\-\_]+\@[0-9a-zA-Z\.\-]+$/ ); #characters allowed on name: 0-9a-Z-._ on host: 0-9a-Z-. on between: @
  return 'false' if ( $mail =~ /^[^0-9a-zA-Z]|[^0-9a-zA-Z]$/);             #must start or end with alpha or num
  return 'false' if ( $mail !~ /([0-9a-zA-Z]{1})\@./ );                    #name must end with alpha or num
  return 'false' if ( $mail !~ /.\@([0-9a-zA-Z]{1})/ );                    #host must start with alpha or num
  return 'false' if ( $mail =~ /.\.\-.|.\-\..|.\.\..|.\-\-./g );           #pair .- or -. or -- or .. not allowed
  return 'false' if ( $mail =~ /.\.\_.|.\-\_.|.\_\..|.\_\-.|.\_\_./g );    #pair ._ or -_ or _. or _- or __ not allowed
  return 'false' if ( $mail !~ /\.([a-zA-Z]{2,3})$/ );                     #host must end with '.' plus 2 or 3 alpha for TopLevelDomain (MUST be modified in future!)
  return 'true';
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_key_value_csv_to_hash {
  my ($csv_string) = @_;
  my (@parent_split, @child_split, %new_hash, $key, $value);

  @parent_split = split(/:::/, $csv_string);

  foreach (@parent_split) {
    @child_split = split(/;;/, $_);
    $key = $child_split[0];
    $value = $child_split[1];

    $value =~ s/\[NL\]/\n/g;
    $value =~ s/\[CSV1\]/:::/g;
    $value =~ s/\[CSV2\]/;;/g;

    $new_hash{$key} = $value;
  }
  return %new_hash;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_key_value_hash_to_csv {
  my ($hash_ref) = @_;
  my ($key, $value, $build);

  foreach (keys %$hash_ref) {
    $key = $_;
    $value = $$hash_ref{$_};

    $value =~ s/\[NL\]//g;
    $value =~ s/\[CSV1\]//g;
    $value =~ s/\[CSV2\]//g;

    $value =~ s/\r//g;
    $value =~ s/\n/\[NL\]/g;
    $value =~ s/:::/\[CSV1\]/g;
    $value =~ s/;;/\[CSV2\]/g;

    $build .= $key . ';;' . $value . ':::';
  }

  $build =~ s/:::$//; # Chop off the last :::

  return $build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_limit_input_text {
  my($max_chars, $trim, $append_text_if_greater_than_max, $chop_at_last_whitespace, $text) = @_;
  my($work);


  # if it is passed in then Inc it bacause it is 0 based
  $max_chars++ if ($max_chars);
  $work = substr($text, 0, $max_chars) if ($max_chars); # Return a max ov 25 chars
  $work = &shazam::string_trim_ws($work) if ($trim eq 'true');
  $work =~ s/\s\S+$// if ($chop_at_last_whitespace eq 'true' && length($text) > $max_chars);
  $work .= $append_text_if_greater_than_max if (length($text) > $max_chars);
  return $work;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Grabs keys from existing hash ref and returns a new hash with matching
# prefix in key but with out the prefix itself
#-----------------------------------------------------------------------------#
sub string_match_hash_prefix {
  my ($hash_ref, $prefix) = @_;
  my (%new_data, $key, $value);

  foreach (keys %$hash_ref) {
    if ($_ =~ m/^$prefix/) {
      $key = $_;
      $key =~ s/$prefix//;
      $new_data{$key} = $$hash_ref{$_};
    }
  }
  return %new_data;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_memo_newlines_to_char_seperated_list{
  my ($char, $work) = @_;

  $work = &shazam::string_trim_ws($work);

  $work =~ s/\n+/$char/g; # Replace Multiple new lines with one new line
  $work =~ s/$char$//g;
  $work .= '.' if ($work);

  return $work;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Example: print &shazam::string_pad_with_char('13', '0', 5);
#-----------------------------------------------------------------------------#

sub string_pad_with_char {
  my ($value_to_pad, $pad_with, $pad_width) = @_;
  substr("$pad_with" x $pad_width . $value_to_pad, - $pad_width);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Generic Replace
#-----------------------------------------------------------------------------#
sub string_replace{
  my ($find, $replace_with, $data) = @_;
  $data =~ s/$find/$replace_with/g;
  return $data;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_replace_leading_spaces_with_string {
  my($string, $replacement) = @_;
  my(@lines, $i);  
  my $length_of_replacement = length($replacement);
  
  @lines = split(/\n/, $string);
  foreach (@lines){
    my $i = 0;
    while (substr($_, $i, 1) eq ' ') { 
      substr($_, $i, 1) = $replacement;
      $i = $i + $length_of_replacement;
    }
  }
  $string = join("\n", @lines);
  return $string;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_return_passed_if_empty{
  my($source_string, $alternative_if_no_source) = @_;
  if ($source_string ne ''){
    return $source_string;
  } else {
    return $alternative_if_no_source;
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_return_positional_suffix {
  my ($number) = @_;
  $number =~ s/\D//g;
  
  return '' if ($number !~ /\d$/);
  
  my $suffix = 'th';
  if ($number !~ /1\d$/) {  
    if    ($number =~ /1$/) {$suffix = 'st'}
    elsif ($number =~ /2$/) {$suffix = 'nd'}
    elsif ($number =~ /3$/) {$suffix = 'rd'}
  }
    
  return $suffix;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Given a query as entered by the user, return a perl expression
# which does a "next" if the search record (to be in $_) is not matched by
# the user's input search string.
#
# If the query looks like a perl regexp (if it has a backslash)
# then match as a perl regexp.
#
# Otherwise assume it is a word or set of words, possibly joined
# by `and', `or' and `not' (the default is `and'). In this mode, words
#  are assumed to be complete; partial matching can be forced with *
# at any point (eg work* to match work, workers, working).
#
# Can also set tag boolean=yes or no to override automatic choice.
#-----------------------------------------------------------------------------#
sub string_search_expression_builder {

  my($query) = @_;

  # Sanity check: query must not contain unescaped "/"!
  $query =~ s|^/|\\/|;
  $query =~ s|([^\\])/|\\/|g;

  my $caseSensitivity   = 'i'; # normally "i" (insensitive)


  # boolean expression support
  #if ( ($tags{'boolean'} eq "no")
  #|| (($tags{'boolean'} ne "yes") && $query =~ /\\/)) {
  ## perl expression, return as is.
  # return "($query)";
  #}
  # boolean expression (or single word)

  my($not, $join);
  my($qrycmd) = "("; # Beginning of expression
  # $query =~ tr/A-Z/a-z/;
  $query =~ s/\(/ ( /g; # make sure brackets are separate "words"
  $query =~ s/\)/ ) /g;
  $query =~ s/['"`]//g;   # quotes don't work (yet?)   I changed the order
  # for (split(/[+ \t]+/, $query)) {
  # Splitting on "+" is bad for queries like "C++"!
  $query =~ s/\+/\\+/g;
  for (split(/[ \t]+/, $query)) {
  # for each "word", do ...
    next if /^$/;
    if ($_ eq ")") { $qrycmd .= $_; next; }
    if ($_ eq "(") { $qrycmd .= "$join$_"; $join = ""; next; }
    if ($_ eq "not") { $not = "!"; next; }
    if ($_ eq "or")  { $join = " || "; next; }
    if ($_ eq "and") { $join = " && "; next; }
    if (/\*/) { s/\*/\\w*/g; }
    # match word boundaries only if fully alphanumeric
    # (for queries like "C++")
    elsif (/^\w+$/) { s/(.*)/\\b\1\\b/; }
    $qrycmd .= "$join$not/$_/$caseSensitivity" . "o";
    $join = " && ";     # default to AND joins
    $not = "";
    }
  $qrycmd .= ")"; # End of expression
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_simple_wrap_lines_at_word_boundries {
  my($text_to_wrap, $wrap_at_char) = @_;
  my @text;
  
  $wrap_at_char = 80 if (!$wrap_at_char);
  
  while($text_to_wrap ne '') {
    $text_to_wrap =~ /(.{1,$wrap_at_char}\W)/ms;
    push(@text, $1);
    $text_to_wrap = $';
  }

  return join("\n", @text);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Attention - Needs work in word boundries so it does not do partial matches
# Works like &shazam::string_title_case() in that it will Capitalize the first
# letter of EACH word in a string except that it does not capitalize words
# such as it, is, in, the, etc... unless it is the first word.
#-----------------------------------------------------------------------------#
sub string_smart_title_case{
  my($string) = @_;
  my @exception_words = ('A', 'The', 'If', 'Is', 'It', 'Of', 'Our', 'An',
                         'On', 'In', 'But', 'With', 'Has', 'Had', 'Have');
  lc($string);
  $string =~ s/([\w']+)/\u\L$1/g;
  foreach(@exception_words){
    $string =~ s/\b$_\b/lc($_)/ge;
  }
  # Uppercase the first letter
  $string =~ s/(.)/\u$1/;
  return $string;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_spaces_to_underscore_in_array_ref {
  my ($array_ref) = @_;
  foreach (@$array_ref) { $_ =~ s/_/ /g; }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_state_abbreviation_to_full_name {
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_state_full_name_to_abbreviation {
   my ($state_name) = @_;
   my %states = &shazam::data_states_hash();
   my %new_states;
   foreach (keys %states) { $new_states{lc($states{$_})} = lc($_) }
   return $new_states{lc($state_name)};
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_string_to_string_in_string_case_insensitive {
  my ($find, $replace_with, $string) = @_;
   $string =~ s/$find/$replace_with/gi;
   return $string;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Strips out All non-numeric data
#-----------------------------------------------------------------------------#
sub string_strip_non_numeric {
  my ($return_zero_if_empty, $data) = @_;
  $data =~ s/\D//g;
  $data = '0' if ($return_zero_if_empty eq 'true' && $data eq '');
  return $data;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Capitalize the first letter of EACH word in a string
#-----------------------------------------------------------------------------#
sub string_title_case {
  my($string) = @_;
  $string =~ s/([\w']+)/\u\L$1/g;
  return $string;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Trim Non Alpha Num Chars from front and rear of sting
#-----------------------------------------------------------------------------#
sub string_trim_non_alpha_num {
  my ($data) = @_;

  $data =~ s/^\W*//;
  $data =~ s/\W*$//;

  return $data;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Trim Whitespace from Front & Rear of String
#-----------------------------------------------------------------------------#
sub string_trim_ws{
  my $core = shift;
  $core = &shazam::string_trim_ws_front($core);
  $core = &shazam::string_trim_ws_rear($core);
  return $core;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Trim Whitespace from Front of String
#-----------------------------------------------------------------------------#
sub string_trim_ws_front{
  my $core = shift;
  $core =~ s/^\s*//;
  return $core;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Trim Whitespace from Rear of String
#-----------------------------------------------------------------------------#
sub string_trim_ws_rear{
  my $core = shift;
  $core =~ s/\s*$//;
  return $core;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_underscore_to_spaces_in_array_ref {
  my ($array_ref) = @_;
  foreach (@$array_ref) { $_ =~ s/_/ /g; }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# ($prior_tag, $next_tag, $num_through, $through_num, $count, $num_through_num_of_count, @array) =
# &structure_generic_page_display_from_array_ref('10', '200', '|', \@array);
#-----------------------------------------------------------------------------#
sub struct_generic_page_display_from_array_ref{
  my ($results_returned, $current_position, $recno_delineator, $data_array_ref) = @_;

  my (@new_array, $count, $list_position, $end_list_position, $current_result,
       $list_pos, $prior_position, $prior_tag, $nexttag, $num_through, $next_tag,
       $through_num, $num_through_num_of_count);

  $count = @$data_array_ref;

  $current_position = 1 if (($current_position < 1) || ($current_position eq ''));
  $list_position = $current_position - 1;

  $results_returned = 1 if (($results_returned < 1) || ($results_returned eq ''));

  # Set number of records to be displayed
  if ( $count >= ($list_position + $results_returned) ) {
    $end_list_position = $list_position + $results_returned;
  } else {
    $end_list_position = $count;
  }

  while ($list_position < $end_list_position) {
    $current_result = $$data_array_ref[$list_position];
    $list_pos = ($list_position + 1);
    push(@new_array, $list_pos . $recno_delineator . $current_result);
    $list_position++;
  }

  # Determine if the Prior and Next tags will be shown and what their values will be.
  $prior_position = ($list_position - ($results_returned * 2));
  $prior_position = 0 if($prior_position < 0);

  if ($end_list_position > $results_returned) { $prior_tag = $prior_position + 1; } else { $prior_tag = ''; }
  if ($end_list_position < $count) { $next_tag = $end_list_position + 1; } else { $next_tag = ''; }

  $num_through = $current_position;
  $through_num = $end_list_position;

  # Build 1 - 10 of 800
  if ($count > 0) {
    $num_through_num_of_count = $num_through . '-' . $through_num . ' of ' . $count;
  } else {
    $num_through_num_of_count = '';
  }

  # $previous, $next, $num_of, $of_num, @records
  return ($prior_tag, $next_tag, $num_through, $through_num, $count, $num_through_num_of_count, @new_array);

}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub struct_insert_items_at_position {
  my ($insert_index, $array_ref, @items_to_add) = @_;
  my ($before, $after, $current_pos, $count);
  my $position = 0;
  my $count = @$array_ref;
  my @new_array;

  $insert_index = ($insert_index + $count) if ($insert_index < 0);
  $insert_index = $count if ($insert_index > $count);

  if ($insert_index <= $count){
    while ($position < $insert_index) {
      push(@new_array, $$array_ref[$position]);
      $position++;
    }
  }

  @new_array = (@new_array, @items_to_add);

  while ($position < $count) {
    push(@new_array, $$array_ref[$position]);
    $position++;
  }

  return @new_array;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub struct_logical_or_hashes {
  my (@hash_refs) = @_;
  my %build = ();

  foreach my $hash_ref (@hash_refs) {
    foreach (keys %$hash_ref) {
      $build{$_} = $hash_ref->{$_} if ($build{$_} ne 'true');
    }
  }

  return \%build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub struct_randomize_array_by_reference {
  my $array_ref = shift;
  my $i = scalar(@$array_ref);
  my ($j, $item);
  foreach $item (@$array_ref ) {
    --$i;
    $j = int rand ($i+1);
    next if $i == $j;
    @$array_ref [$i,$j] = @$array_ref[$j,$i];
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub struct_return_array_element_before_and_after_selected{
  my ($selected, $array_ref) = @_;
  my ($before, $after, $current_pos, $count);
  my $position = 0;
  my $count = @$array_ref;
  while ($position <= $count) {
    if ($$array_ref[$position] =~ m/^$selected$/){
      $before = $$array_ref[$position-1];
      $after = $$array_ref[$position+1] if ($position < ($count-1));
      $after = $$array_ref[0] if ($position >= ($count-1));
      return ($before, $after, $position, $count);
    }
    $position++;
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub struct_return_array_element_position {
  my ($string_to_match, $array_ref) = @_;
  my ($count);
  my $position = 0;
  my $count = @$array_ref;
  while ($position < $count) {
    return ($position) if ($array_ref->[$position] eq $string_to_match);
    $position++;
  }
  return '';
}
#sub struct_return_array_element_position {
#  my ($string_to_match, $array_ref) = @_;
#  my ($count);
#  my $position = 0;
#  my $count = @$array_ref;
#  while ($position < $count) {
#    return ($position) if ($$array_ref[$position] =~ m/^$string_to_match$/);
#    $position++;
#  }
#  return '';
#}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub struct_return_array_element_position_partial_match {
  my ($string_to_match, $array_ref) = @_;
  my ($count);
  my $position = 0;
  my $count = @$array_ref;
  while ($position < $count) {
    return ($position) if ($$array_ref[$position] =~ m/$string_to_match/);
    $position++;
  }
  return '';
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub struct_return_array_sort_indicies {
  my @array = @_;
    
  my @sorted_array = sort {$a<=>$b} @array;
  
  my %indicies;
  my $index = 0;
  foreach (@sorted_array) {
    $indicies{$_} = $index;
    $index++;
  }
  
  foreach (@array) {
    $_ = $indicies{$_};
  }

  return @array;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub struct_return_array_unique_items {
  my ($array_ref, $ignore_case) = @_;
  my %indicies = ();
  my @build = ();

  my $index = 0;
  foreach (@$array_ref) {
    if ($ignore_case eq 'true') {
      unless (exists $indicies{lc $_} && ($_ eq lc $_ || $_ eq uc $_)) {
        if (exists $indicies{lc $_}) {
          $build[$indicies{lc $_}] = $_;
        } else {
          $indicies{lc $_} = $index;
          push @build, $_;
          $index++;
        }
      }
    } elsif (!exists $indicies{$_}) {
      $indicies{$_} = $index;
      push @build, $_;
      $index++;
    }
  }
  
  return @build;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub utils_convert_bytes_to_optimal_unit{
  my($bytes) = @_;

  return '' if ($bytes eq '');

  my($size);
  $size = $bytes . ' Bytes' if ($bytes < 1024);
  $size = sprintf("%.2f", ($bytes/1024)) . ' KB' if ($bytes >= 1024 && $bytes < 1048576);
  $size = sprintf("%.2f", ($bytes/1048576)) . ' MB' if ($bytes >= 1048576 && $bytes < 1073741824);
  $size = sprintf("%.2f", ($bytes/1073741824)) . ' GB' if ($bytes >= 1073741824 && $bytes < 1099511627776);
  $size = sprintf("%.2f", ($bytes/1099511627776)) . ' TB' if ($bytes >= 1099511627776);

  return $size;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# &shazam::utils_random_alpha - Random Alpha Generator
# EXAMPLE: &shazam::utils_random_alphanumeric(10);  # Returns a 10 digit random Alpha
#-----------------------------------------------------------------------------#
sub utils_random_alpha {

  my $input = $_[0];

  my @chars = ( "A".."Z" );
  my $random = join("", @chars[map{rand @chars} (1..$input)]);
  return $random;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# &shazam::utils_random_alphanumeric - Random Alphanumeric Generator
# EXAMPLE: &shazam::utils_random_alphanumeric(10);  # Returns a 10 digit random Alphanumeric
#-----------------------------------------------------------------------------#
sub utils_random_alphanumeric {

  my $input = $_[0];

  my @chars = ( "A".."Z", 0..9 );
  my $random = join("", @chars[map{rand @chars} (1..$input)]);
  return $random;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# &shazam::utils_random_number - Random Number Generator
# EXAMPLE: &shazam::utils_random_number(10);  # Returns a 10 digit random number
#-----------------------------------------------------------------------------#
sub utils_random_number {

  my $input = $_[0];

  my @chars = ( 0..9 );
  my $random = join('', @chars[map{rand @chars} (1..$input)]);
  return $random;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub wx_download_file_with_progress_dialog {
  my ($url, $parent, $title, $message, $modal, $lwp_agent) = @_;
  use Wx ':everything';
  use LWP;
  $lwp_agent = LWP::UserAgent->new() unless (ref $lwp_agent eq 'LWP::UserAgent');
  my $result = $lwp_agent->head($url);
  my $remote_headers = $result->headers;
  my $update_size = $remote_headers->content_length;
  my $flags = wxPD_ELAPSED_TIME | wxPD_ESTIMATED_TIME | wxPD_REMAINING_TIME | wxPD_AUTO_HIDE | wxPD_CAN_ABORT;
  $flags = $flags | wxPD_APP_MODAL if ($modal ne 'false');
  my $progress_dialog = Wx::ProgressDialog->new($title, $message, $update_size, $parent, $flags);
  $progress_dialog->Show(1);
  my $download_data = '';
  my $aborted = 0;
  my $file_data = $lwp_agent->get($url, ':content_cb' => \&wx_download_file_with_progress_dialog_update_progress );
  $file_data = $file_data->content();
  $progress_dialog->Destroy();
  return (length $file_data > length $download_data) ? $file_data : $download_data;
  #return $download_data;
  sub wx_download_file_with_progress_dialog_update_progress {
    my ($data, $response, $protocol) = @_;
    $download_data .= $data;
    my $continue = $progress_dialog->Update(length $download_data);
    if (!$continue) {
      $aborted = 1;
      $lwp_agent->abort;
    }
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub wx_notebook_remove_and_hide_tabs {
  my ($notebook, @tabs) = @_;
  if (!@tabs) {
    while (my $count = $notebook->GetPageCount) {
      $notebook->GetPage($count-1)->Show(0);
      $notebook->RemovePage($count-1);
    }
  } else {
    my $removals = 0;
    foreach (@tabs) {
      $notebook->GetPage($_ - $removals)->Show(0);
      $notebook->RemovePage($_ - $removals);
      $removals++;
    }
  }
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub wx_styledtextctrl_settext_circumvent_readonly {
  my ($stc, $text) = @_;
  my $readonly = $stc->GetReadOnly();
  $stc->SetReadOnly(0);
  $stc->SetText($text);
  $stc->SetReadOnly($readonly);
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub wx_widget_get_value {
  my ($widget_object) = @_;
  my $widget_type = ref $widget_object;
  $widget_type =~ s/^Wx:://;
  $widget_type = lc $widget_type;
  my $sub = "wx_widget_get_value_$widget_type";
  my $value = &$sub($widget_object);
  return $value;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub wx_widget_get_value_choice {
  my ($widget_object) = @_;
  my $value = $widget_object->GetStringSelection();
  return $value;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub wx_widget_get_value_htmlwindow {
  my ($widget_object) = @_;
  my $value = undef;
  return $value;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub wx_widget_get_value_styledtextctrl {
  my ($widget_object) = @_;
  my $value = $widget_object->GetText();
  return $value;
}




#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub wx_widget_get_value_textctrl {
  my ($widget_object) = @_;
  my $value = $widget_object->GetValue();
  return $value;
}





1;