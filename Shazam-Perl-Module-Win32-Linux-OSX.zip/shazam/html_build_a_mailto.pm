package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_build_a_mailto {
  my($email_address, $in_the_a, $from, $cc, $subject, $body, $params) = @_;
  my($target, $proto);

  $params = ' ' . $params if ($params ne '');
  $in_the_a = $email_address if ($in_the_a eq '');

  return qq|<a href="mailto:$email_address?from=$from&cc=$cc&subject=$subject&body=$body"$params>$in_the_a</a>|
}
1;
