package shazam;
 # Attention - need to fix these
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# description: Builds an aligned, balanced HTML table, sorted in rows
# example: &shazam::html_build_table_balanced($params_table_outer, $params_tr_outer, $params_td_outer, $params_table_inner, $params_tr_inner, $params_td_inner, $columns, $auto_reduce_columns, @data);
# parameters: table, tr, and td params for outer and inner tables respectively;
#             number of columns; whether columns reduce if data is too small; data
#-----------------------------------------------------------------------------#
sub html_build_table_balanced {
  my ($params_table_outer, $params_tr_outer, $params_td_outer, $params_table_inner, $params_tr_inner, $params_td_inner, $columns, $auto_reduce_columns, @data) = @_;

  return '' if (@data < 1);

  $columns = scalar(@data) if ($columns > scalar(@data) && $auto_reduce_columns eq 'true');

  my (@temp_array, @built_data, $iter0, $iter1);
  for ($iter1 = 0; $iter1 < $columns; $iter1++) {
    @temp_array = ();
          for ($iter0 = 0; $iter0 < scalar(@data); $iter0 += $columns) {
      push(@temp_array, $data[$iter0 + $iter1]);
          }
          push(@built_data, &shazam::html_build_table(1,$params_table_inner,$params_tr_inner,$params_td_inner,@temp_array));
  }
  return &shazam::html_build_table($columns,$params_table_outer,$params_tr_outer,$params_td_outer,@built_data);
}
1;
