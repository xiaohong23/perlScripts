package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Requires array of images with fully qualified path
# takes pixel size or percentage
#-----------------------------------------------------------------------------#
sub image_rotate_from_array {
  my ($use_purity_cache, $degrees, @images) = @_;
  my ($image, $background, $file_name, $path);
  my ($extension, $file_without_ext);

  use Image::Magick;

  foreach (@images){
    ($file_name, $path) = &shazam::io_split_path_and_file($_);
    ($extension, $file_without_ext) = &shazam::io_split_filename_and_exsension($file_name);

    $image = Image::Magick->new;

    # If a purity cache image exists open it, if not open the actual
    if ($use_purity_cache eq 'true' && -e $path . $file_without_ext . '_purity_cache.bmp'){
      $image->Read($path . $file_without_ext . '_purity_cache.bmp');
    } else {
      $image->Read($path . $file_name);
    }

    # Do Stuff
    $image->Rotate('degrees' => $degrees);

    # Write purity cache
    $image->Write($path . $file_without_ext . '_purity_cache.bmp') if ($use_purity_cache eq 'true');

    # Write actual file
    $image->Write($path . $file_without_ext . '.' . $extension);

    undef $image;
   }
}
1;
