package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_reset_select_boxes_with_selected_options_from_hash{
  my ($form, %options) = @_;
  my ($key, $value);


# This works but is so slow that it is hard to believe
#  use Benchmark; my $t0 = new Benchmark;
#
#  # Remove "selected" from any we will reset
#  foreach (keys %options){
#    $key = $_;
#    $value = $options{$_};
#    $form =~ s,(<select .*?name="$key".*?<option .*?) selected(>.*?/select>),$1$2,sgi;
#  }
#
#  my $t1 = new Benchmark; my $td = timediff($t1, $t0); &shazam::cgi_print( timestr($td) );


  # This will remove the selected status from ALL select boxes even ones not in the options hash
  # But it is faster
  $form =~ s/ selected>/>/gi;


  # Set selected option for any select boxes in our hash
  foreach (keys %options){
    $key = $_;
    $value = $options{$_};
    $form =~ s,(<select .*?name="$key".*?<option value="$value".*?)(>.*?/select>),$1 selected$2,sgi;
  }


  return $form;
}
1;
