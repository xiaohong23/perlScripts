package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_build_a_href {
  my($actual_link, $in_the_a, $force_http_in_actual_link, $open_in_new_window, $params) = @_;
  my($target, $proto);

  $params = ' ' . $params if ($params ne '');
  $in_the_a = $actual_link if ($in_the_a eq '');
  $actual_link =~ /()/;
  $actual_link =~ s/^(https):\/\///i if ($force_http_in_actual_link eq 'true');
  $actual_link =~ s/^(http):\/\///i if ($force_http_in_actual_link eq 'true');
  $proto = $1;
  $proto = 'http' if ($proto eq '');
  $actual_link = "$proto://" . $actual_link if ($force_http_in_actual_link eq 'true');

  $target = ' target="_blank"' if ($open_in_new_window eq 'true');

  return qq|<a$target href="$actual_link"$params>$in_the_a</a>|
}
1;
