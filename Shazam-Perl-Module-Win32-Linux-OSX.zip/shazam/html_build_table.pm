package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# example: &shazam::html_build_table($cols, $table_params, $tr_params, $td_params, @data);
#-----------------------------------------------------------------------------#
sub html_build_table{
  my($cols, $table_params, $tr_params, $td_params, @data) = @_;
  my($i, $work);

  return '' if (@data < 1);

  my $mod = (@data % $cols);

  $table_params = ' ' . $table_params if ($table_params);
  $tr_params = ' ' . $tr_params if ($tr_params);
  $td_params = ' ' . $td_params if ($td_params);

  for ($i = 0; $i < @data; $i++){
    $work .= "  <td$td_params>$data[$i]</td>\n";
    $work .= "</tr>\n<tr$tr_params>\n" if (((($i + 1) % $cols) == 0) && (($i + 1) != @data));
    $work .= "  <td$td_params>&nbsp;</td>\n" x ($cols - $mod) if ((($i + 1) == @data) && ($mod != 0));
  }
  $work = "<table$table_params>\n<tr$tr_params>\n$work\n</tr>\n</table>";

  return $work;
}
1;
