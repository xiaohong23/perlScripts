package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# example: &shazam::html_build_select_box($name, $selected, @options)
# name
# selected
# value|Name
# value|Name
#-----------------------------------------------------------------------------#
sub html_build_select_box_class {
  my($name, $class, $selected, @options) = @_;
  my (@split, $build, $value);

  foreach $value (@options) {
    @split = split(/\|/, $value);
    $build .= qq|  <option value="$split[0]">$split[1]</option>| . "\n" if ($split[0] ne $selected);
    $build .= qq|  <option value="$split[0]" selected>$split[1]</option>| . "\n" if ($split[0] eq $selected);
  }
  $build = qq|<select class="$class" name="$name">| . "\n" . $build . "</select>";
  return $build;
}
1;
