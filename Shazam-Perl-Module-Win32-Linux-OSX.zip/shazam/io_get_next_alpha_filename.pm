package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Will search for the next incremental ALPHA filename starting with the
# lowercase letter 'a' in the specified path. The extention is optional.
#
# $example = &shazam::io_get_next_alpha_filename($path, "ext");
#
#-----------------------------------------------------------------------------#
sub io_get_next_alpha_filename {
  my ($path, $ext) = @_;
  my $record_key = "a";

  $ext = "." . $ext;
  while (-e $path . "$record_key$ext") {
    $record_key++;
  }
  return $record_key;
}
1;
