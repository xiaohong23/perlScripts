package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub graphics_color_return_gradient {
  my ($hex_code_1, $hex_code_2, $num_colors_or_point_array_ref) = @_;

  my @points;
  if (ref($num_colors_or_point_array_ref) eq 'ARRAY') {
    @points = @$num_colors_or_point_array_ref;
  } else {
    return if ($num_colors_or_point_array_ref < 1);
    foreach (0..$num_colors_or_point_array_ref - 1) {
      push(@points, 100 / ($num_colors_or_point_array_ref - 1) * $_);
    }
  }
  
  my @start_point = &shazam::graphics_color_convert_hex6_to_rgb($hex_code_1);
  my @end_point = &shazam::graphics_color_convert_hex6_to_rgb($hex_code_2);
  my @difference;
  
  foreach (0..2) {
    $difference[$_] = $end_point[$_] - $start_point[$_];
  }

  my @colors;
  foreach (@points) {
    my @this_color;
    foreach my $color_element (0..2) {
      $this_color[$color_element] = $start_point[$color_element] + $_ / 100 * $difference[$color_element];
    }
    push(@colors, [@this_color]);
  }
  
  foreach (@colors) {
    $_ = &shazam::graphics_color_convert_rgb_to_hex6(@$_);
  }
  
  return @colors;
}
1;
