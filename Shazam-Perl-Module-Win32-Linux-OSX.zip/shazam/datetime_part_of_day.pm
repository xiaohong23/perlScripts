package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Returns morning, afternoon, or evening according
# to the server based time of the day.
#-----------------------------------------------------------------------------#
sub datetime_part_of_day {
  my @time = split /[\s:]/, localtime;
  return "morning" if ($time[3] < 12 );
  return "afternoon" if ($time[3] > 12 && $time[3] < 18 );
  return "evening" if ($time[3] >= 18 );
}
1;
