package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Returns an array of directories.
# @example = &shazam::io_get_directory_list( $path, "path option" );
#
# Path Options: (none, full)
#
# 'none' returns a list of only directories with no preceeding path
# 'full' returns a list of directories with the full preceeding path
#
# Note: If Path Option is not defined default is NONE
#
#-----------------------------------------------------------------------------#
sub io_get_directory_list {

  my($path, $include_path) = @_;

  my ($item, @items);
  my @build = ();

  opendir(CORE, $path ) || &shazam::cgi_error("$!", "[sub io_get_directory_list]: $path - $!");
  @items = readdir(CORE);
  closedir(CORE);

  foreach $item (@items) {
    if ( -d $path . "$item" ) {        # make sure this IS a directory
      next if $item =~ /^\.\.?$/;      # weed out all .. directories
      #next if $item =~ /_vti_cnf/i;   # weed out front page directories
      if (defined $include_path){
        push(@build, $path . $item . "/") if($include_path eq "full");
        push(@build, $item) if($include_path eq "none");
      } else {
        push(@build, $item);
      }
    }
  }
  return @build;
}
1;
