package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_key_value_hash_to_csv {
  my ($hash_ref) = @_;
  my ($key, $value, $build);

  foreach (keys %$hash_ref) {
    $key = $_;
    $value = $$hash_ref{$_};

    $value =~ s/\[NL\]//g;
    $value =~ s/\[CSV1\]//g;
    $value =~ s/\[CSV2\]//g;

    $value =~ s/\r//g;
    $value =~ s/\n/\[NL\]/g;
    $value =~ s/:::/\[CSV1\]/g;
    $value =~ s/;;/\[CSV2\]/g;

    $build .= $key . ';;' . $value . ':::';
  }

  $build =~ s/:::$//; # Chop off the last :::

  return $build;
}
1;
