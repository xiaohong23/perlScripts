package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub keydb_s_read_file {

  my ($file, $escape_html) = @_;  
  my ($hash_ref);
  
  $escape_html = 'false' if (!$escape_html);

  #&shazam::keydb_s_create_file($file) if (!-e $file);
  use Fcntl qw(:DEFAULT :flock);
  use strict;  

  if (-e $file) {
              
    use Storable qw(fd_retrieve);
    use Fcntl qw(:DEFAULT :flock);
    open(DB, "< $file") or die "can't open $file: $!";
    eval qq^flock(DB, LOCK_SH) or die "can't lock $file: $!"^;
    $hash_ref = fd_retrieve(\*DB);
    eval qq^flock(DB, LOCK_UN)^;
    close(DB);
       
    &shazam::keydb_escape_html_in_hash_by_ref(\%$hash_ref)  if ($escape_html eq 'true');
               
    #&shazam::keydb_cgi_print_hash($hash_ref);

    return $hash_ref;
  } else {
    &shazam::keydb_cgi_error("$!", "[shazam::keydb_s_read_file]: $file - The data file requested could not be located on this machine at the specified name and path.<br><br>$file");
  }
}
1;
