package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_simple_wrap_lines_at_word_boundries {
  my($text_to_wrap, $wrap_at_char) = @_;
  my @text;
  
  $wrap_at_char = 80 if (!$wrap_at_char);
  
  while($text_to_wrap ne '') {
    $text_to_wrap =~ /(.{1,$wrap_at_char}\W)/ms;
    push(@text, $1);
    $text_to_wrap = $';
  }

  return join("\n", @text);
}

1;
