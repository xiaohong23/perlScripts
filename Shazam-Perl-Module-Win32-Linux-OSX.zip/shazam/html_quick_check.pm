package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0 - Contributed
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_quick_check {
  my %Pair = (
              'A', 1,
         'ADDRESS',1,
               'B',1,
           'BLINK',1,  # mozilla
      'BLOCKQUOTE',1,
              'BQ',1,
          'CENTER',1,  # mozilla
            'CITE',1,
            'CODE',1,
             'DFN',1,
             'DIR',1,
              'DL',1,
              'EM',1,
             'FIG',1,
            'FONT',1,  # mozilla
            'FORM',1,
              'H1',1,
              'H2',1,
              'H3',1,
              'H4',1,
              'H5',1,
              'H6',1,
            'HEAD',1,
            'HTML',1,
               'I',1,
             'KBD',1,
         'LISTING',1,
            'MATH',1,
            'MENU',1,
              'OL',1,
             'PRE',1,
               'S',1,
            'SAMP',1,
          'SELECT',1,
          'STRONG',1,
           'STYLE',1,
           'TABLE',1,
        'TEXTAREA',1,
           'TITLE',1,
              'TT',1,
               'U',1,
              'UL',1,
             'VAR',1,
             'XMP',1,);

# Nestable elements
my %Nestable = (
      'BLOCKQUOTE',1,
              'DL',1,
            'MENU',1,
              'OL',1,
           'TABLE',1,
              'UL',1,);


  local($_) = @_;
  local($*) = 0;

  my($tag, $isendtag, @tags, %tags, $tag1, $Error);

  $Error = "";

  for $tag (/<\s*([^\s>]+)[^>]*>/g) {
    $tag =~ y/a-z/A-Z/;
    $isendtag = $tag =~ s!^/!!;
    next unless $Pair{$tag};

    if ($isendtag) {
      if ($tag1 = pop @tags) {
        $tag1 eq $tag || ($Error .=  "<$tag1> does not match </$tag>\n");
      } else {
        $Error .=  "</$tag> appears without matching <$tag>\n";
      }

      $tags{$tag1} -= 1;
    } else {
      push(@tags, $tag);
      $tags{$tag} += 1;
      $tags{$tag} <=1 || $Nestable{$tag} || ($Error .=  "<$tag> cannot be nested\n");
    }
  }

  for $tag (@tags) {
    $Error .= "missing required </$tag> for <$tag>\n";
  }

  return $Error;
}
1;
