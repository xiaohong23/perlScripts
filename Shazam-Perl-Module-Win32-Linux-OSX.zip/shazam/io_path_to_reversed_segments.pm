package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Takes file or document path and returns reversed segments Array
#
# Examples:
#   "c:/test"            returns   'test', 'c:'
#   "c:/test/foobar"     returns   'foobar', 'test', 'c:'
#   "c:/test/foobar/"    returns   'foobar', 'test', 'c:'
#   "c:/test/file.ext"   returns   'file.ext', 'test', 'c:'
#-----------------------------------------------------------------------------#
sub io_path_to_reversed_segments {
  my @split = split( /\//, $_[0] );
  @split = reverse @split;
  if (@split > 0){
    return @split;
  }
}
1;
