package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_do_replacements_from_hash_ref {
  my ($replacement_hash_ref, @string_refs) = @_;
  my $new_hash_ref = {};
  foreach (keys %$replacement_hash_ref) {
    my $key = $_;
    #$key =~ s/([\?\*\+\[\]\\\.])/\\$1/g;
    $new_hash_ref->{$key} = $replacement_hash_ref->{$_};
    #&shazam::p($_);
  }
  $replacement_hash_ref = $new_hash_ref;
  #&shazam::cgi_print_hash($replacement_hash_ref) if ($replacement_hash_ref->{'foo'});
  

  my $index;
  foreach (@string_refs) {
    if (! ( ref($_) ne 'SCALAR' || $$_ eq '' || ref($replacement_hash_ref) ne 'HASH' || keys(%$replacement_hash_ref) < 1 )) {
      foreach my $replace (keys %$replacement_hash_ref) {
        $$_ =~ s/\Q$replace\E/$replacement_hash_ref->{$replace}/g;
      }
    }
    #$$_ =~ s/\+/./g;
    $index++;
  }

}
1;
