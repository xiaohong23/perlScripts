package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# base-columns   integer   base image width (before transformations)
# base-filename  string    base image filename (before transformations)
# base-rows      integer   base image height (before transformations)
# class          {Direct, Pseudo} image class
# colors         integer   number of unique colors in the image
# comment        string    get the image comment
# columns        integer   image width
# depth          integer   image depth
# directory      string    tile names from within an image montage
# elapsed-time   double    elapsed time in seconds since the image was created
# error          double    the mean error per pixel computed with methods Compare() or Quantize()
# filesize       integer   number of bytes of the image on disk
# format         string    get the descriptive image format
# geometry       string    image geometry
# height         integer   the number of rows or height of an image
# id             integer   ImageMagick registry id
# label          string    image label
# maximum-error  double    the normalized max error per pixel computed with methods Compare() or Quantize()
# mean-error     double    the normalized mean error per pixel computed with methods Compare() or Quantize()
# montage        geometry  tile size and offset within an image montage
# rows           integer   the number of rows or height of an image
# signature      string    SHA-256 message digest associated with the image pixel stream
# taint          {True, False} True if the image has been modified
# user-time      double    user time in seconds since the image was created
# width          integer   the number of columns or width of an image
# x-resolution   integer   x resolution of the image
# y-resolution   integer   y resolution of the image
#
#-----------------------------------------------------------------------------#
sub image_get_image_info {
  my ($path_to_image, @info) = @_;
  my (@return_info, $image, $file_name, $path);

  use Image::Magick;

  ($file_name, $path) = &shazam::io_split_path_and_file($_);

  $image = new Image::Magick;
  $image->Read($path_to_image);

  foreach (@info) {
    push(@return_info, $image->Get($_));
  }

  undef $image;

  return @return_info;
}
1;
