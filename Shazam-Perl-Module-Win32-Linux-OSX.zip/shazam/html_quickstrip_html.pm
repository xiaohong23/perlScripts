package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Strips HTML tags from a string
#-----------------------------------------------------------------------------#
sub html_quickstrip_html{
  my $process = shift;
  
  #$process =~ s/<[^>]*>//gs; # sloppy get rid of any html tags
  my $old_length = length($process) + 1;
  while (length($process) < $old_length) {
    $old_length = length($process);
    $process =~ s/<[^+][^<>]*>//gs;
  }
  
  return $process;
}
1;
