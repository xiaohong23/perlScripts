package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub net_sendmail_simple {
  my($mail_server, $auth_user, $auth_pass, $html_or_text, $from, $to, $subject, $body, $from_display, $to_display, @attachments) = @_;

  my %header_info;

  $header_info{'From'} = ($from_display eq '') ? $from : $from_display;
  $header_info{'To'} = ($to_display eq '') ? $_ : $to_display;
  $header_info{'Subject'} = $subject;
  $header_info{'Content-Type'} = ($html_or_text eq 'html') ? 'text/html' : 'text/plain';
  
  #####################################
  ##                                 ##
  ##  ATTACHMENT STUFF WILL GO HERE  ##
  ##                                 ##
  #####################################

  foreach ( split(/;/, $to) ) {
    &shazam::net_sendmail_advanced($mail_server, $auth_user, $auth_pass, $from, $_, \%header_info, $body);
  }
}

1;
