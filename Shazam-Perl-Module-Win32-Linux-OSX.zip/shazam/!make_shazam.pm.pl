
use strict;

#-----------------------------------------------------------------------------#
require 'io_get_file_list.pm';
require 'io_save_file_text.pm';
require 'io_open_file.pm';

my (@files, $build_interface, $build_single_module); 


unlink('./shazam-complete.pm') if (-e './shazam-complete.pm');
unlink('./shazam.pm') if (-e './shazam.pm');


# Get the list of subs
@files = &shazam::io_get_file_list('./', 'none');

#-----------------------------------------------------------------------------#
$build_interface = "package shazam;\n\nuse strict;\nno strict 'refs';\n\n";
$build_single_module = "package shazam;\n\nuse strict;\nno strict 'refs';\n\n";

foreach (sort @files) {
  next if ($_ eq 'shazam.pm');
  next if ($_ eq 'zblank.pm');
  next if ($_ !~ /\.pm$/);
  print $_ . "\n";
  my ($filename, $ext) = split(/\./, $_);
  $build_interface .= qq|sub $filename { require '$filename.pm'; &shazam::$filename(\@_) }\n|;
  $build_single_module .= &extract_and_process_current_sub($filename);
}
$build_interface .= "\n1;";
$build_single_module .= "\n1;";



#-----------------------------------------------------------------------------#
sub extract_and_process_current_sub {
 my($filename) = @_;
 my ($work);
 
 $work = &shazam::io_open_file('./' . $filename . '.pm');
 $work =~ s/^\s*//;
 $work =~ s/\s*$//;
 
 $work =~ s/1;$//;
 $work =~ s/^package shazam;//;
 
 $work =~ s/^\s*//;
 $work =~ s/\s*$//;

 $work .= "\n\n\n\n\n";  
 
 return $work;
}


#-----------------------------------------------------------------------------#
print $build_interface;
&shazam::io_save_file_text('./shazam.pm', $build_interface);
&shazam::io_save_file_text('./shazam-complete.pm', $build_single_module);

