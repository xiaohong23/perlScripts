package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Returns an array of files recursivly pulled from specified directory.
# @example = &shazam::io_get_recursive_file_list( $path, "path option" );
#
# Path Options: (virtual, full)
#
# 'virtual' returns a list of filenames with path starting at path specified
#    'full' returns a list of files with the full preceeding path
#
# Note: If Path Option is not defined default is FULL
#
#-----------------------------------------------------------------------------#
sub io_get_recursive_file_list {

  my ($path, $path_options) = @_;
  my (@master_list, @to_be_processed);

  @to_be_processed = &shazam::io_get_recursive_directory_list($path);
  @master_list = &shazam::io_get_file_list($path, "full");

  while (@to_be_processed){
    push( @master_list, &shazam::io_get_file_list(pop(@to_be_processed), "full") );
  }

  if ($path_options eq "virtual"){
    foreach(@master_list){$_ =~ s/$path//;}
    return @master_list;
  } else {
    return @master_list;
  }
}
1;
