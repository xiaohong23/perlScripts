package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Default permission is 0711
# Only fires if the path does not exist
#-----------------------------------------------------------------------------#
sub io_smart_force_path {
  my ($path, $permissions) = @_;

  if (!-d $path) {
    $permissions = 0704 if ($permissions eq '');
    use File::Path;
    mkpath([$path], 0, $permissions);
  }
}
1;
