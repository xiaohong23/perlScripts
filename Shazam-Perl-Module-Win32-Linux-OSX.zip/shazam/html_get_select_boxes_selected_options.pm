package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub html_get_select_boxes_selected_options{
  my($data) = @_;
  my($tmp, %values, $select_box, $name_found, $option_found, $name, $option);

  $tmp = $data;

  while ($tmp =~ m,<select (.*?)/select>,sgi){

    $select_box = $1;

    $name_found = 'false';
    $option_found = 'false';

    # Get select name
    if ($select_box =~ m/name=['"](.*?)['"]/i){
      $name = $1;
      $name_found = 'true';
    }

     # &shazam::cgi_print($name);

    # Get select option
    if ($select_box =~ m/option value="(.*?)" selected/i){
      $option = $1;
      $option_found = 'true';
    }

    $values{$name} = $option if ($name_found && $option_found);
  }

  return %values;
}
1;
