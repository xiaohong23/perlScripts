package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# example: &shazam::cgi_checkboxes_from_csv_to_html($csv, $cb_params, @items);
#  $csv = 'Item 1;Item 2;Item 3';
#  $cb_params = 'class="" etc...';
#  @items = array of check boxes
#-----------------------------------------------------------------------------#
sub cgi_checkboxes_from_csv_to_html {
  my ($csv, $cb_params, @items) = @_;
  my (@build, $underscored, @split, %csv_hash);

  $cb_params = ' ' . $cb_params if ($cb_params);

  @split = split(/;/, $csv);
  foreach (@split) { $csv_hash{$_} = ' checked'; }

  foreach (@items){
    $underscored = $_;
    $underscored =~ s/ /_/g;
    push(@build, qq|<input$cb_params type="checkbox" name="cb_$underscored" value="$underscored"$csv_hash{$_}> $_|);
  }

  return @build;
}
1;
