package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# @deleted_files = &shazam::io_expire_files( $path, 7200 );
# The second parm is options and if not passed will default to 2 hours (7200 seconds)
#########---------------------------------------------------------
## 011 ##                    Expire Files
#########---------------------------------------------------------
#
#  0 dev      device number of filesystem
#  1 ino      inode number
#  2 mode     file mode  (type and permissions)
#  3 nlink    number of (hard) links to the file
#  4 uid      numeric user ID of file's owner
#  5 gid      numeric group ID of file's owner
#  6 rdev     the device identifier (special files only)
#  7 size     total size of file, in bytes
#  8 atime    last access time since the epoch
#  9 mtime    last modify time since the epoch
# 10 ctime    inode change time (NOT creation time!) since the epoch
# 11 blksize  preferred block size for file system I/O
# 12 blocks   actual number of blocks allocated
#-----------------------------------------------------------------------------#
sub io_expire_files {

  my $path = $_[0];
  my $seconds_old = $_[1];
  my @files = &shazam::io_get_file_list( $path, "none" );
  my $file;
  my @deleted_files;

  # If no expire time is passed set to default of 2 hours (7200 seconds)
  if (!$seconds_old) { $seconds_old = 7200; }

  FILE: foreach $file (@files) {
    if (  ( stat("$path$file") )[9] + $seconds_old < time  ) {
      unlink ("$path$file") or &shazam::cgi_error("$!", "[proio_expire_files]: $!");  # Delete the file if it is too old.
      push(@deleted_files, $file);
    }
  }
  return @deleted_files;
}
1;
