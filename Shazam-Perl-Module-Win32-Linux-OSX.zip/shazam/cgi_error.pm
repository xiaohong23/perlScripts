package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub cgi_error{

  print "Content-type: text/html\n\n";
  print qq|

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
        <title>$_[0]</title>
</head>

<body bgcolor="#E2E2DC">
<p>&nbsp;</p>

<center><font size="+2" color="maroon"><b><blink>Critical Error in Shazam Library!</blink></b></font></center>
<center>
<table width="65%" border="3" bordercolor="black" cellpadding="15">
<tr>
        <td bgcolor="#DAD9B8">
    <b>$_[0]:</b>
    <br><br>
    $_[1]  <p>Please contact the system administrator and report this problem. If you could make a note of your browser, browser version, and what you were doing when this error occurred it will be helpful. We are sorry for any inconvenience this error may have caused you, and once we have been notified our engineers will look into it immediately.
    </td>
</tr>
</table>

</center>

</body>
</html>
|;
exit;
}

1;
