package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_write_file {
  my($path, $data, $bin_mode) = @_;
  my($file, $pathonly) = &shazam::io_split_path_and_file($path);
  
  &shazam::io_smart_force_path($pathonly) if (!-e $pathonly);
  
  # Save the new blank file
  open(FILE, ">$path") or &shazam::library_cgi_error("$!", "[io_write_file]: The specified file could not be written on this machine at the specified name and path.<br><br>$path");
  binmode(FILE) if ($bin_mode eq 'true');
  print FILE $data;
  close(FILE);
}
1;
