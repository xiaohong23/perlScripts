package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Given a query as entered by the user, return a perl expression
# which does a "next" if the search record (to be in $_) is not matched by
# the user's input search string.
#
# If the query looks like a perl regexp (if it has a backslash)
# then match as a perl regexp.
#
# Otherwise assume it is a word or set of words, possibly joined
# by `and', `or' and `not' (the default is `and'). In this mode, words
#  are assumed to be complete; partial matching can be forced with *
# at any point (eg work* to match work, workers, working).
#
# Can also set tag boolean=yes or no to override automatic choice.
#-----------------------------------------------------------------------------#
sub string_search_expression_builder {

  my($query) = @_;

  # Sanity check: query must not contain unescaped "/"!
  $query =~ s|^/|\\/|;
  $query =~ s|([^\\])/|\\/|g;

  my $caseSensitivity   = 'i'; # normally "i" (insensitive)


  # boolean expression support
  #if ( ($tags{'boolean'} eq "no")
  #|| (($tags{'boolean'} ne "yes") && $query =~ /\\/)) {
  ## perl expression, return as is.
  # return "($query)";
  #}
  # boolean expression (or single word)

  my($not, $join);
  my($qrycmd) = "("; # Beginning of expression
  # $query =~ tr/A-Z/a-z/;
  $query =~ s/\(/ ( /g; # make sure brackets are separate "words"
  $query =~ s/\)/ ) /g;
  $query =~ s/['"`]//g;   # quotes don't work (yet?)   I changed the order
  # for (split(/[+ \t]+/, $query)) {
  # Splitting on "+" is bad for queries like "C++"!
  $query =~ s/\+/\\+/g;
  for (split(/[ \t]+/, $query)) {
  # for each "word", do ...
    next if /^$/;
    if ($_ eq ")") { $qrycmd .= $_; next; }
    if ($_ eq "(") { $qrycmd .= "$join$_"; $join = ""; next; }
    if ($_ eq "not") { $not = "!"; next; }
    if ($_ eq "or")  { $join = " || "; next; }
    if ($_ eq "and") { $join = " && "; next; }
    if (/\*/) { s/\*/\\w*/g; }
    # match word boundaries only if fully alphanumeric
    # (for queries like "C++")
    elsif (/^\w+$/) { s/(.*)/\\b\1\\b/; }
    $qrycmd .= "$join$not/$_/$caseSensitivity" . "o";
    $join = " && ";     # default to AND joins
    $not = "";
    }
  $qrycmd .= ")"; # End of expression
}
1;
