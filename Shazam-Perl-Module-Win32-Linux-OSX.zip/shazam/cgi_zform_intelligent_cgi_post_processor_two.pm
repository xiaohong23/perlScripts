package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Warn Only (Passive)
# req            Required Field
# alpha          Text Only
# num            Numeric Only
# alphanum       Must contain both Alpha & Num
# low25          Lowest 25
# high120        Highest 120
# phone          phone number
# zip            zip code
# email          Valid Email
# visa?
# ssn
# ip


# Actions (Active)
# trim           Trim Whitespace
# lc             Lower Case
# uc             Upper Case
# tc             Title Case
# sc             Sentence Case
# striphtml      Strip All Html
#
#
#  $cgi_hash_ref       This is your CGI Hash
#  $return             What to return? (Leave blank)
#  $pre_warning        What to place before individual warning Placements
#  $warning_marker     Markers to indicate items that need attention (<+zf__title_mark+>)
#  $bulk_warn_header
#  $bulk_warn_footer
#  $form               The Form to be checked
#
#-----------------------------------------------------------------------------#
sub cgi_zform_intelligent_cgi_post_processor_two {
  my ($cgi_hash_ref, $return, $pre_warning, $warning_marker, $bulk_warn_header, $bulk_warn_footer, $confirm_template, $collected_template, $form) = @_;
  my (%new_data, %instructions, %messages, %warnings, %form_data, $key,
      $uncleaned_key, $cleaned_key, $instruct, $title, $msg, %titles, %bulk_warnings);

  # Checkbox Parser and maintainer
   my ($cbs_current_box, @cbs_split_group_from_items, $cbs_group, @cbs_items,
       $cbs_cleaned_group, $cbs_inc, $cbs_current_item, $cbs_checked, $cbs_build_cb,
       @cbs_checkboxes_build_array,$cbs_final_group_production, $cbs_cols, $cbs_td_width,
       $cbs_current_item_name, $cbs_group_no_sort_numbers);

   while ($form =~ s,\[checkboxes(\d) (.*?)\],83jshs4403kdsue83jdd983ks9,si){
     $cbs_cols = $1;
     $cbs_current_box = $2;
     $cbs_current_box =~ s/\n//g;

     $cbs_cols = 6 if ($cbs_cols > 6);

     @cbs_split_group_from_items = split(/:/, $cbs_current_box);
     $cbs_group = &shazam::string_trim_ws($cbs_split_group_from_items[0]);
     @cbs_items = split(/,/, $cbs_split_group_from_items[1]);

    # $titles{$cleaned_key}

     $cbs_cleaned_group = lc($cbs_group);
     $cbs_cleaned_group =~ s/ /_/g;

     $cbs_inc = 0;
     $cbs_build_cb = '';
     @cbs_checkboxes_build_array = ();

     foreach (@cbs_items){
       $cbs_current_item = &shazam::string_trim_ws($_);
       $cbs_current_item_name = 'zf__' . $cbs_cleaned_group . '_cb' . $cbs_inc;

       $cbs_checked = '';
       $cbs_checked = ' checked' if ($$cgi_hash_ref{"$cbs_current_item_name"} ne '');

       $cbs_build_cb = qq|<input type="checkbox" name="$cbs_current_item_name" value="$cbs_current_item"$cbs_checked> $cbs_current_item|;
       push(@cbs_checkboxes_build_array, $cbs_build_cb);

       # If this form is being posted and not just constructed
       if ($$cgi_hash_ref{'zf__general_form_processor'} eq 'run') {
         $$cgi_hash_ref{"zf__$cbs_cleaned_group"} = $$cgi_hash_ref{"zf__$cbs_cleaned_group"} . ', ' if ($$cgi_hash_ref{"zf__$cbs_cleaned_group"} ne '' && $$cgi_hash_ref{$cbs_current_item_name} ne '');
         $$cgi_hash_ref{"zf__$cbs_cleaned_group"} = $$cgi_hash_ref{"zf__$cbs_cleaned_group"} . $cbs_current_item if ($$cgi_hash_ref{$cbs_current_item_name} ne '');
         $cbs_group_no_sort_numbers = substr($cbs_group, 4);
         $titles{"zf__$cbs_cleaned_group"} = $cbs_group_no_sort_numbers;
         delete($$cgi_hash_ref{"$cbs_current_item_name"});
       }

       $cbs_inc++;
     }


     $cbs_td_width = '100%' if ($cbs_cols == 1);
     $cbs_td_width = '50%' if ($cbs_cols == 2);
     $cbs_td_width = '33%' if ($cbs_cols == 3);
     $cbs_td_width = '25%' if ($cbs_cols == 4);
     $cbs_td_width = '20%' if ($cbs_cols == 5);
     $cbs_td_width = '16%' if ($cbs_cols == 6);

     $cbs_final_group_production = &shazam::html_build_table($cbs_cols, 'cellpadding="10" border="0"', '', "width=$cbs_td_width nowrap", @cbs_checkboxes_build_array);
     $form =~ s/83jshs4403kdsue83jdd983ks9/$cbs_final_group_production/;
   }







  # First process the instrucstions and the messages
  foreach (keys %$cgi_hash_ref) {
    if ($_ =~ m/^zf__zinst_/) {
      ($title, $instruct, $msg) = split(/::/, $$cgi_hash_ref{$_});
      $uncleaned_key = $_;
      $cleaned_key = $uncleaned_key;
      $cleaned_key =~ s/zf__zinst_//;
      $cleaned_key = 'zf__' . $cleaned_key;

      $instructions{$cleaned_key} = $instruct;
      $messages{$cleaned_key} = $msg;
      $titles{$cleaned_key} = $title;

      #$bulk_messages($cleaned_key) = "$title|$msg";

      delete($$cgi_hash_ref{$_});
    }

  }

  # Next process the actual data
  foreach (keys %$cgi_hash_ref) {
    if ($_ =~ m/^zf__/) {
      $uncleaned_key = $_;
      $cleaned_key = $uncleaned_key;
      $cleaned_key =~ s/zf__//;
      $cleaned_key = 'zf__' . $cleaned_key;
      $form_data{$cleaned_key} = $$cgi_hash_ref{$_};
    }
  }


  # Now do tests on retrieved data in the %form_data hash to see
  # if the data complies to passive instructions (if any) and to
  # apply any Active instructions (if any)
  my($current_object, $inst, %inst_hash, @split_inst);
  foreach (keys %instructions){
    $current_object = $_;
    @split_inst = split(/\|/, $instructions{$current_object});
    foreach $inst (@split_inst){ $inst_hash{$inst} = ''; }

    if (1 < 2){
   # if (exists($form_data{$current_object})){
    #  &shazam::cgi_print_hash(\%inst_hash);

      #First take care of Actions
      foreach $inst (@split_inst){
        if ($inst eq 'lc') { $form_data{$current_object} = lc($form_data{$current_object}); delete($inst_hash{$inst});} # Lower Case
        if ($inst eq 'uc') { $form_data{$current_object} = uc($form_data{$current_object}); delete($inst_hash{$inst});} # Upper Case
      }


      # Next see if it is required and check complience
      if (exists($inst_hash{'req'})){
        if ($form_data{$current_object} eq '' || !exists($form_data{$current_object})){
          $warnings{$current_object} = 'This is a required field. Please complete this field and resubmit your form.';
          $warnings{$current_object} = $messages{$current_object} if (exists($messages{$current_object}) && $messages{$current_object} ne '');
          $bulk_warnings{$titles{$current_object}} = $warnings{$current_object};
        }
        delete($inst_hash{'req'});
      }


      # Now Remaining elements in %inst_hash should be ckecked for
      # complience and warnings ONLY IF A WARNING DOES NOT ALREADY
      # EXIST FOR IT. Once a warning exists then stop testing because we
      # only give the user one warning at a time per field.
      my ($current_inst_key, $test_data);
      foreach (keys %inst_hash){
        $current_inst_key = $_;
        $test_data = $form_data{$current_object};


        # &shazam::cgi_print($test_data);

        if (!exists($warnings{$current_object})){
        ###############################################

          # numeric only
          if (($current_inst_key eq 'num') && ($test_data =~ /.*\D/g)) {
            $warnings{$current_object} = 'This field requires a NUMERIC only response. NUMERIC only would be 0-9 characters only.';
            $bulk_warnings{$titles{$current_object}} = $warnings{$current_object};
          }

          # email only
          if (($current_inst_key eq 'email') && ($test_data ne '' && &shazam::string_is_valid_email_address($test_data) ne 'true')) {
            $warnings{$current_object} = 'This field requires a valid email address. The address you have entered does not seem to conform to the RFC 822 standards. It is suspected that this may not be a valid E-mail address. Please try again.';
            $bulk_warnings{$titles{$current_object}} = $warnings{$current_object};
          }



        ###############################################
        }

      }




    }
    %inst_hash = ();
  }




  delete($form_data{'zf__general_form_processor'});



  # Build Bulk Warnnings
  my $bulk;
  foreach (sort keys %bulk_warnings){ $bulk .= "<li><b>$_</b><br>" . $bulk_warnings{$_} . "<br><br>\n"; }
  $bulk = $bulk_warn_header . "\n<ol>\n" . $bulk . "</ol>\n" . $bulk_warn_footer . "\n" if ($bulk ne '');


  # Insert any and all warnings
  my($nkey, $nvalue, $nraw);
  foreach (keys %warnings){
    $nkey = '<+' . $_ . '_help+>';
    $nkey = quotemeta($nkey);
    $nvalue = $pre_warning . $warnings{$_};
    $form =~ s/$nkey/$nvalue/g;
  }


  # Insert any Warning Notice Markers
  foreach (keys %warnings){
    $nkey = '<+' . $_ . '_mark+>';
    $nkey = quotemeta($nkey);
    $nvalue = $warning_marker;
    $form =~ s/$nkey/$nvalue/g;
  }


  # Replace all insert form value tags
  foreach (keys %form_data){
    $nraw = $_;
    $nkey = '<+' . $_ . '+>';
    $nkey = quotemeta($nkey);
    $nvalue = &shazam::html_escape_html($form_data{$nraw});
    $form =~ s/$nkey/$nvalue/g;
    $confirm_template =~ s/$nkey/$nvalue/g;
    $collected_template =~ s/$nkey/$nvalue/g;
  }

  # Stuff the origional cgi hash with keys and values
  # without sort number prefix
  my($key, $cleaned_key);
  foreach (keys %form_data){
    $key = substr($_, 8);
    $key =~ s/_/ /g;
    $key = 'zf ' . $key;
    $$cgi_hash_ref{$key} = $form_data{$_};
  }





  # Build Confirmation Stuff
  my $default_collected_data = "\n\n";
  foreach (sort keys %form_data){
    $default_collected_data .=  '[' . uc($titles{$_}) . "]\n" . $form_data{$_} . "\n\n\n" if ($form_data{$_} ne '');
  }

  # Enforce select box State
  my %select_box_hash = &shazam::html_get_select_boxes_selected_options($form);
  foreach (keys %select_box_hash) { $select_box_hash{$_} = $$cgi_hash_ref{$_} if (exists($$cgi_hash_ref{$_})); }
  $form = &shazam::html_reset_select_boxes_with_selected_options_from_hash($form, %select_box_hash);


  # remove any leftover zf tags such as warning insert tags not used
  $form =~ s/<\+zf__[^+>]*\+>//gs;

  # Do bulk warning placement
  $form =~ s/<\+bulk warnings\+>/$bulk/gs;


  my $approved = 'false';
  $approved = 'true' if ($bulk eq '' && $$cgi_hash_ref{'zf__general_form_processor'} eq 'run');


#  &shazam::cgi_print('<pre>'. $default_collected_data . '</pre>');


  return ($approved, $form, $confirm_template, $collected_template, $default_collected_data);
}
1;
