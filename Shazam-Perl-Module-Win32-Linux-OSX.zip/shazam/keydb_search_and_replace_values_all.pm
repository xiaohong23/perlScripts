package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Will search all values for token and replace it with specified value
#-----------------------------------------------------------------------------#
sub keydb_search_and_replace_values_all {

  my ($path, $find, $replacement) = @_;
  my %existing_data_file;
  my ($new_file, @split);

  #&shazam::keydb_create_file($path) if (!-e $path);    

  use Fcntl qw(:DEFAULT :flock);
  use strict;

  # If the data file exists load in its values 
  if (-e $path) {
    sysopen(DB, $path, O_RDWR|O_CREAT) or &shazam::keydb_cgi_error("$!", "[keydb_search_and_replace_values_all]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
    eval qq^flock(DB, LOCK_EX)^;
    while (<DB>) {
      chomp($_); # Remove LF 
      chop($_) if (substr($_, -1, 1) eq "\015"); # Remove windows CR if it exists
      @split = split(/\|/, $_);
      if ($split[0]) { $existing_data_file{$split[0]} = $split[1]; }
    }    
  } else {
    &shazam::keydb_cgi_error("$!", "[keydb_search_and_replace_values_all]: $path - The data file requested could not be located on this machine at the specified name and path.<br><br>$path");
  }
 

  # Build the official new data file  
  foreach ( sort keys %existing_data_file ) { 
    if ($_) {
      $existing_data_file{$_} =~ s/$find/$replacement/g;
      $new_file .= "$_|$existing_data_file{$_}\012";
    }
  }
  chop($new_file); # remove the last \n
  
  # Save the new file
  seek(DB, 0, 0) or die "can't rewind: $!";
  truncate(DB, 0) or die "can't truncate: $!";
  print DB $new_file;
  eval qq^flock(DB, LOCK_UN)^;
  close(DB);
}
1;
