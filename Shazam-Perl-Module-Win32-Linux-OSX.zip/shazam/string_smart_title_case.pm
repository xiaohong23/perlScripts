package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Attention - Needs work in word boundries so it does not do partial matches
# Works like &shazam::string_title_case() in that it will Capitalize the first
# letter of EACH word in a string except that it does not capitalize words
# such as it, is, in, the, etc... unless it is the first word.
#-----------------------------------------------------------------------------#
sub string_smart_title_case{
  my($string) = @_;
  my @exception_words = ('A', 'The', 'If', 'Is', 'It', 'Of', 'Our', 'An',
                         'On', 'In', 'But', 'With', 'Has', 'Had', 'Have');
  lc($string);
  $string =~ s/([\w']+)/\u\L$1/g;
  foreach(@exception_words){
    $string =~ s/\b$_\b/lc($_)/ge;
  }
  # Uppercase the first letter
  $string =~ s/(.)/\u$1/;
  return $string;
}
1;
