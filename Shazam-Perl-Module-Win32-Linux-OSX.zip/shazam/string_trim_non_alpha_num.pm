package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Trim Non Alpha Num Chars from front and rear of sting
#-----------------------------------------------------------------------------#
sub string_trim_non_alpha_num {
  my ($data) = @_;

  $data =~ s/^\W*//;
  $data =~ s/\W*$//;

  return $data;
}
1;
