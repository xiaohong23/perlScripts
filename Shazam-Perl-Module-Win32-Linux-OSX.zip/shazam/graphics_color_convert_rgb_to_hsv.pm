package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub graphics_color_convert_rgb_to_hsv {
  my ($r, $g, $b2) = @_;
  my ($h, $s, $v, $delta, $min);

  $min = [sort {$a <=> $b} ($r, $g, $b2)] -> [0];
  $v   = [sort {$b <=> $a} ($r, $g, $b2)] -> [0];
  $delta = $v - $min;

  if ($v == 0 || $delta == 0) { $s = 0; $h = 0; }
  else {
    if    ($r == $v)  { $h =       60 * ($g  - $b2) / $delta; }
    elsif ($g == $v)  { $h = 120 + 60 * ($b2 - $r ) / $delta; }
    else              { $h = 240 + 60 * ($r  - $g ) / $delta; }
    $h = $h + 360 if ($h < 0);
  }
  
  return ($h, $s, $v);
}
1;
