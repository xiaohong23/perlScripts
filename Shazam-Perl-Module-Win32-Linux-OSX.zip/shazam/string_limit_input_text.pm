package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub string_limit_input_text {
  my($max_chars, $trim, $append_text_if_greater_than_max, $chop_at_last_whitespace, $text) = @_;
  my($work);


  # if it is passed in then Inc it bacause it is 0 based
  $max_chars++ if ($max_chars);
  $work = substr($text, 0, $max_chars) if ($max_chars); # Return a max ov 25 chars
  $work = &shazam::string_trim_ws($work) if ($trim eq 'true');
  $work =~ s/\s\S+$// if ($chop_at_last_whitespace eq 'true' && length($text) > $max_chars);
  $work .= $append_text_if_greater_than_max if (length($text) > $max_chars);
  return $work;
}
1;
