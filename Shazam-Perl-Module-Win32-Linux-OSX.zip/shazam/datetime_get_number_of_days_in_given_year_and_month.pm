package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# eg. print &shazam::datetime_get_number_of_days_in_given_year_and_month($month, $year);
#-----------------------------------------------------------------------------#
sub datetime_get_number_of_days_in_given_year_and_month {
  my ($month, $year) = @_;
  my ($next_year, $next_month, $days);

  use Time::Local;

  if ($month <= 12 or $month >= 1){
    $next_year = ($month == 12) ? $year + 1 : $year;
    $next_month = timelocal(0, 0, 0, 1, $month % 12, $next_year);
    $days = (localtime($next_month - 86_400))[3];
    return $days;
  }
}
1;
