package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_get_uploaded_imagename_from_mac_or_pc_path {
  my ($path, $max_chars) = @_;
  my ($name, $extension);

  ($name, $extension) = split(/\./, lc($path));

  if ($name && $extension) {
    $name =~ s/\s/_/g; # Replace whitespace with _
    $name =~ s/-/_/g; # Replace - with _
    $name =~ s/\W//g;  # Delete all non AlphaNum Chars
    $name =~ s/_+/_/g; # Replace more than one _ with one _

    $name = substr($name, 0, $max_chars) if ($max_chars && length($name) > $max_chars); # Return a max ov 25 chars

    $name =~ s/^_*//; # Trim Leading _
    $name =~ s/_*$//; # Trim Trailing _

    $extension =~ s/jpeg/jpg/;
    if ($extension =~ m/(jpg|jpeg|gif|png)/) { $extension = $extension } else { $extension = '' }
  }



  if ($extension && $name) {
    return ($name . '.' . $extension, 'true');
  } else {
    return ('', 'false');
  }

}
1;
