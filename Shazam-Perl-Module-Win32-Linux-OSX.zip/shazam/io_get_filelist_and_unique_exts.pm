package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Returns a list of all files and a list unique extions
#-----------------------------------------------------------------------------#
sub io_get_filelist_and_unique_exts {
  my ($path) = @_;
  my @files = &shazam::io_get_file_list($path, 'none') if (-d $path);
  my(%ext_hash, @all_filenames, @unique_ext);

  foreach (@files){
    my ($ext, $filename) = &shazam::io_split_filename_and_exsension($_);
     push(@all_filenames, $_);
     $ext = lc($ext);
     $ext_hash{$ext} = '';
  }

  foreach (keys %ext_hash) { push(@unique_ext, $_) }

  return (\@all_filenames, \@unique_ext);
}
1;
