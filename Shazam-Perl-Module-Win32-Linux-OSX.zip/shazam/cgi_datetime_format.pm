package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# Date/Time Format for Header/Cookie
# This internal routine creates date strings suitable for use in
# cookies and HTTP headers.  (They differ, unfortunately.)
#-----------------------------------------------------------------------------#
sub cgi_datetime_format {

  my($time,$format) = @_;
  $format ||= 'http';

  my(@MON)=qw/Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec/;
  my(@WDAY) = qw/Sun Mon Tue Wed Thu Fri Sat/;

  # pass through preformatted dates for the sake of datetime_adjust_epoch_time()
  $time = &shazam::datetime_adjust_epoch_time($time);
  return $time unless $time =~ /^\d+$/;

  # make HTTP/cookie date string from GMT'ed time
  # (cookies use '-' as date separator, HTTP uses ' ')
  my($sc) = ' ';
  $sc = '-' if $format eq "cookie";
  my($sec,$min,$hour,$mday,$mon,$year,$wday) = gmtime($time);
  $year += 1900;
  return sprintf("%s, %02d$sc%s$sc%04d %02d:%02d:%02d GMT",
    $WDAY[$wday],$mday,$MON[$mon],$year,$hour,$min,$sec);
}
1;
