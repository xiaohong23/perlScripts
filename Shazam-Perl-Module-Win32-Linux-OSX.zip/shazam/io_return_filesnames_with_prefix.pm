package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
sub io_return_filesnames_with_prefix {
  my($prefix, $array_ref) = @_;
  my ($file_name, $path, @new_array);

  foreach (@$array_ref) {
    ($file_name, $path) = &shazam::io_split_path_and_file($_);
    push(@new_array, $path . $file_name) if ($file_name =~ /^$prefix/);
  }
  return @new_array;
}
1;
