package shazam;
#-----------------------------------------------------------------------------#
#     Version: 1.0
#   Copyright: Bryant H. McGill - 11c Lower Dorset Street, Dublin 1, Ireland
# Web Address: http://www.bryantmcgill.com/Shazam_Perl_Module/
#   Use Terms: Free for non-commercial use, commercial use with notification.
#
#       Legal: This code is provided "as is" without warranty of any kind.
#              The entire risk of use remains with the recipient. 
#              In no event shall Bryant McGill be liable for any direct,
#              consequential, incidental, special, punitive or other damages.
#-----------------------------------------------------------------------------#
# ($prior_tag, $next_tag, $num_through, $through_num, $count, $num_through_num_of_count, @array) =
# &structure_generic_page_display_from_array_ref('10', '200', '|', \@array);
#-----------------------------------------------------------------------------#
sub struct_generic_page_display_from_array_ref{
  my ($results_returned, $current_position, $recno_delineator, $data_array_ref) = @_;

  my (@new_array, $count, $list_position, $end_list_position, $current_result,
       $list_pos, $prior_position, $prior_tag, $nexttag, $num_through, $next_tag,
       $through_num, $num_through_num_of_count);

  $count = @$data_array_ref;

  $current_position = 1 if (($current_position < 1) || ($current_position eq ''));
  $list_position = $current_position - 1;

  $results_returned = 1 if (($results_returned < 1) || ($results_returned eq ''));

  # Set number of records to be displayed
  if ( $count >= ($list_position + $results_returned) ) {
    $end_list_position = $list_position + $results_returned;
  } else {
    $end_list_position = $count;
  }

  while ($list_position < $end_list_position) {
    $current_result = $$data_array_ref[$list_position];
    $list_pos = ($list_position + 1);
    push(@new_array, $list_pos . $recno_delineator . $current_result);
    $list_position++;
  }

  # Determine if the Prior and Next tags will be shown and what their values will be.
  $prior_position = ($list_position - ($results_returned * 2));
  $prior_position = 0 if($prior_position < 0);

  if ($end_list_position > $results_returned) { $prior_tag = $prior_position + 1; } else { $prior_tag = ''; }
  if ($end_list_position < $count) { $next_tag = $end_list_position + 1; } else { $next_tag = ''; }

  $num_through = $current_position;
  $through_num = $end_list_position;

  # Build 1 - 10 of 800
  if ($count > 0) {
    $num_through_num_of_count = $num_through . '-' . $through_num . ' of ' . $count;
  } else {
    $num_through_num_of_count = '';
  }

  # $previous, $next, $num_of, $of_num, @records
  return ($prior_tag, $next_tag, $num_through, $through_num, $count, $num_through_num_of_count, @new_array);

}
1;
